/* eslint-disable @typescript-eslint/ban-ts-comment */

// @ts-ignore `terser` may not be installed
export type * as Terser from 'terser'
// @ts-ignore `terser` may not be installed
import type * as Terser from 'terser'

/* eslint-enable @typescript-eslint/ban-ts-comment */

export type TerserMinifyOptions = Terser.MinifyOptions
export type TerserMinifyOutput = Terser.MinifyOutput
