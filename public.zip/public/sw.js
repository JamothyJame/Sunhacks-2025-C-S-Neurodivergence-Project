/**
 * MedTracker Service Worker
 * Handles background notifications and basic caching
 */

const CACHE_NAME = 'medtracker-v1';
const urlsToCache = [
  '/',
  '/static/css/main.css',
  '/static/js/main.js',
  '/manifest.json'
];

// Install event - cache resources
self.addEventListener('install', event => {
  console.log('[SW] Install event');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[SW] Opened cache');
        return cache.addAll(urlsToCache);
      })
      .catch(error => {
        console.error('[SW] Cache addAll failed:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('[SW] Activate event');
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event - serve from cache when offline
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        return fetch(event.request).catch(() => {
          // If both cache and network fail, show offline page for navigation requests
          if (event.request.mode === 'navigate') {
            return new Response(
              `
              <!DOCTYPE html>
              <html>
                <head>
                  <title>MedTracker - Offline</title>
                  <meta charset="utf-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1">
                  <style>
                    body {
                      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      min-height: 100vh;
                      margin: 0;
                      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                      color: white;
                      text-align: center;
                      padding: 20px;
                    }
                    .container {
                      max-width: 400px;
                    }
                    .icon {
                      font-size: 64px;
                      margin-bottom: 20px;
                    }
                    h1 {
                      margin-bottom: 10px;
                    }
                    p {
                      opacity: 0.8;
                      line-height: 1.5;
                    }
                    button {
                      background: rgba(255, 255, 255, 0.2);
                      border: 1px solid rgba(255, 255, 255, 0.3);
                      color: white;
                      padding: 12px 24px;
                      border-radius: 8px;
                      margin-top: 20px;
                      cursor: pointer;
                    }
                    button:hover {
                      background: rgba(255, 255, 255, 0.3);
                    }
                  </style>
                </head>
                <body>
                  <div class="container">
                    <div class="icon">📱</div>
                    <h1>You're Offline</h1>
                    <p>MedTracker needs an internet connection. Your medication data is safely stored locally and will sync when you're back online.</p>
                    <button onclick="window.location.reload()">Try Again</button>
                  </div>
                </body>
              </html>
              `,
              {
                headers: { 'Content-Type': 'text/html' }
              }
            );
          }
        });
      })
  );
});

// Handle background sync for medication reminders
self.addEventListener('sync', event => {
  console.log('[SW] Background sync:', event.tag);
  
  if (event.tag === 'medication-reminder') {
    event.waitUntil(handleMedicationReminder());
  }
});

// Handle push notifications
self.addEventListener('push', event => {
  console.log('[SW] Push received');
  
  let notificationData = {};
  
  if (event.data) {
    try {
      notificationData = event.data.json();
    } catch (e) {
      notificationData = {
        title: 'MedTracker Reminder',
        body: event.data.text() || 'Time to take your medication!',
        icon: '/icon-192x192.png',
        badge: '/badge-72x72.png'
      };
    }
  }
  
  const options = {
    body: notificationData.body || 'Time to take your medication!',
    icon: notificationData.icon || '/icon-192x192.png',
    badge: notificationData.badge || '/badge-72x72.png',
    vibrate: [200, 100, 200],
    data: notificationData.data || {},
    actions: [
      {
        action: 'mark-taken',
        title: '✅ Mark as Taken'
      },
      {
        action: 'snooze',
        title: '⏰ Snooze 10 min'
      }
    ],
    requireInteraction: true,
    tag: notificationData.tag || 'medication-reminder'
  };
  
  event.waitUntil(
    self.registration.showNotification(
      notificationData.title || 'MedTracker Reminder',
      options
    )
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  console.log('[SW] Notification click:', event.action);
  
  event.notification.close();
  
  if (event.action === 'mark-taken') {
    // Handle marking medication as taken
    event.waitUntil(handleMarkAsTaken(event.notification.data));
  } else if (event.action === 'snooze') {
    // Schedule a new notification in 10 minutes
    event.waitUntil(handleSnooze(event.notification.data));
  } else {
    // Default action - open the app
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Handle background medication reminder
async function handleMedicationReminder() {
  console.log('[SW] Handling medication reminder');
  
  // This would typically fetch pending reminders from IndexedDB
  // and show notifications for medications that are due
  
  try {
    // Basic implementation - in a real app this would query the database
    const notification = await self.registration.showNotification(
      'Medication Reminder',
      {
        body: 'Time to take your medication!',
        icon: '/icon-192x192.png',
        badge: '/badge-72x72.png',
        vibrate: [200, 100, 200],
        tag: 'medication-reminder',
        requireInteraction: true
      }
    );
    
    console.log('[SW] Notification shown');
  } catch (error) {
    console.error('[SW] Failed to show notification:', error);
  }
}

// Handle marking medication as taken from notification
async function handleMarkAsTaken(data) {
  console.log('[SW] Marking medication as taken:', data);
  
  // In a real implementation, this would:
  // 1. Update the medication log in IndexedDB
  // 2. Update inventory if applicable
  // 3. Send data to server when online
  
  // For now, just log the action
  try {
    // Show confirmation notification
    await self.registration.showNotification(
      'Medication Logged',
      {
        body: 'Great job! Your medication has been marked as taken.',
        icon: '/icon-192x192.png',
        tag: 'medication-taken',
        requireInteraction: false
      }
    );
    
    // Close notification after 3 seconds
    setTimeout(() => {
      self.registration.getNotifications({ tag: 'medication-taken' })
        .then(notifications => {
          notifications.forEach(notification => notification.close());
        });
    }, 3000);
    
  } catch (error) {
    console.error('[SW] Failed to handle mark as taken:', error);
  }
}

// Handle snoozing medication reminder
async function handleSnooze(data) {
  console.log('[SW] Snoozing medication reminder:', data);
  
  try {
    // Schedule new notification in 10 minutes (600000 milliseconds)
    setTimeout(async () => {
      await self.registration.showNotification(
        'Medication Reminder (Snoozed)',
        {
          body: 'Time to take your medication! (Reminder was snoozed)',
          icon: '/icon-192x192.png',
          badge: '/badge-72x72.png',
          vibrate: [200, 100, 200],
          tag: 'medication-reminder-snoozed',
          requireInteraction: true,
          actions: [
            {
              action: 'mark-taken',
              title: '✅ Mark as Taken'
            }
          ]
        }
      );
    }, 600000); // 10 minutes
    
    // Show snooze confirmation
    await self.registration.showNotification(
      'Reminder Snoozed',
      {
        body: 'Your medication reminder has been snoozed for 10 minutes.',
        icon: '/icon-192x192.png',
        tag: 'reminder-snoozed',
        requireInteraction: false
      }
    );
    
    // Auto-close snooze confirmation
    setTimeout(() => {
      self.registration.getNotifications({ tag: 'reminder-snoozed' })
        .then(notifications => {
          notifications.forEach(notification => notification.close());
        });
    }, 3000);
    
  } catch (error) {
    console.error('[SW] Failed to handle snooze:', error);
  }
}

// Listen for messages from the main thread
self.addEventListener('message', event => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

console.log('[SW] Service Worker loaded');