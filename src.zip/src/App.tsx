import { useState, useEffect } from 'react';
import './App.css';
import { UserService } from '@/services/UserService';
import { MedicationService } from '@/services/MedicationService';
import { IndexedDBService } from '@/services/IndexedDBService';
import { UserModel, UserProfileModel, UserPreferencesModel } from '@/models/UserModel';
import { MedicationModel } from '@/models/Medication';
import { AuthenticationForm } from '@/components/AuthenticationForm';
import { UserProfile } from '@/components/UserProfile';
import { AddMedicationForm } from '@/components/AddMedicationForm';
import { EditMedicationForm } from '@/components/EditMedicationForm';
import { DueMedicationsCard } from '@/components/DueMedicationsCard';
import { MedicationCard } from '@/components/MedicationCard';
import { MedicationRepository } from '@/repositories/MedicationRepository';
import { NotificationService } from '@/services/NotificationService';
import { GamificationService } from '@/services/GamificationService';
import { InventoryService } from '@/services/InventoryService';
import { MedicationSkeleton, ProfileSkeleton, LoadingOverlay } from '@/components/LoadingStates';
import { createLogger } from '@/services/LoggingService';
import { SessionMonitor, useSessionMonitor } from '@/components/SessionMonitor';
import { requestDeduplicator } from '@/utils/requestDeduplicator';

function App() {
  const logger = createLogger('App');
  const { handleSessionExpired, handleSessionWarning } = useSessionMonitor();
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'profile'>('dashboard');
  const [user, setUser] = useState<UserModel | null>(null);
  const [profile, setProfile] = useState<UserProfileModel | null>(null);
  const [, setPreferences] = useState<UserPreferencesModel | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [showAddMedication, setShowAddMedication] = useState(false);
  const [editingMedication, setEditingMedication] = useState<MedicationModel | null>(null);
  const [medications, setMedications] = useState<MedicationModel[]>([]);
  const [medicationsLoading, setMedicationsLoading] = useState(false);
  const [addingMedication, setAddingMedication] = useState(false);
  const [updatingMedication, setUpdatingMedication] = useState<string | null>(null);
  const [deletingMedication, setDeletingMedication] = useState<string | null>(null);
  const [userProgress, setUserProgress] = useState<{
    taken: number;
    scheduled: number;
    percentage: number;
    streak: number;
    level: number;
    experience: number;
    nextLevelExp: number;
  } | null>(null);

  const userService = UserService.getInstance();
  const medicationService = MedicationService.getInstance();
  const medicationRepository = new MedicationRepository();
  const notificationService = NotificationService.getInstance();
  const gamificationService = GamificationService.getInstance();
  const inventoryService = InventoryService.getInstance();

  useEffect(() => {
    initializeApp();
  }, []);

  const loadUserMedications = async (userId: string) => {
    return requestDeduplicator.run(`load-medications-${userId}`, async () => {
      try {
        setMedicationsLoading(true);
        const userMedications = await medicationService.getUserMedications(userId);
        setMedications(userMedications);
      } catch (error) {
        logger.error('Failed to load medications', error as Error, { userId });
      } finally {
        setMedicationsLoading(false);
      }
    });
  };

  // Setup notifications when medications change
  useEffect(() => {
    if (medications.length > 0) {
      setupNotifications();
    }
  }, [medications]);

  // Update user progress when medications change
  useEffect(() => {
    if (user && medications.length >= 0) { // Allow for 0 medications case
      updateUserProgress();
    }
  }, [user, medications]);

  const initializeApp = async () => {
    try {
      // Initialize IndexedDB
      const dbService = IndexedDBService.getInstance();
      await dbService.initialize();

      // Try to restore user session
      const restored = await userService.initializeFromStorage();
      if (restored) {
        const currentUser = await userService.getCurrentUser();
        if (currentUser) {
          setUser(currentUser.user);
          setProfile(currentUser.profile);
          setPreferences(currentUser.preferences);
          setIsAuthenticated(true);
          await loadUserMedications(currentUser.user.id);
        }
      }
    } catch (error) {
      logger.error('Failed to initialize app', error as Error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (userData: {
    email: string;
    firstName: string;
    lastName: string;
    dateOfBirth?: Date;
  }) => {
    setAuthLoading(true);
    try {
      const result = await userService.signUpUser(userData);
      if (result.success && result.user && result.profile && result.preferences) {
        setUser(result.user);
        setProfile(result.profile);
        setPreferences(result.preferences);
        setIsAuthenticated(true);
        userService.saveSessionToStorage();
        await loadUserMedications(result.user.id);
        return { success: true };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to create account' 
      };
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignIn = async (email: string) => {
    setAuthLoading(true);
    try {
      const result = await userService.signInUser(email);
      if (result.success && result.user && result.profile && result.preferences) {
        setUser(result.user);
        setProfile(result.profile);
        setPreferences(result.preferences);
        setIsAuthenticated(true);
        userService.saveSessionToStorage();
        await loadUserMedications(result.user.id);
        return { success: true };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to sign in' 
      };
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    await userService.signOutUser();
    setUser(null);
    setProfile(null);
    setPreferences(null);
    setMedications([]);
    setIsAuthenticated(false);
    setCurrentView('dashboard');
    setShowAddMedication(false);
    setEditingMedication(null);
  };

  const handleUpdateProfile = async (updates: Partial<Parameters<UserProfileModel['update']>[0]>) => {
    const updatedProfile = await userService.updateUserProfile(updates);
    if (updatedProfile) {
      setProfile(updatedProfile);
    }
  };

  const handleAddMedication = async (medication: MedicationModel) => {
    try {
      setAddingMedication(true);
      await medicationService.addMedication(medication);
      // Wait for operation to complete before updating UI (non-optimistic)
      setMedications(prev => [...prev, medication]);
      setShowAddMedication(false);
    } catch (error) {
      logger.error('Failed to add medication', error as Error, { medicationName: medication.name });
      throw error;
    } finally {
      setAddingMedication(false);
    }
  };

  const handleEditMedication = (medicationId: string) => {
    const medication = medications.find(med => med.id === medicationId);
    if (medication) {
      setEditingMedication(medication);
    }
  };

  const handleUpdateMedication = async (updatedMedication: MedicationModel) => {
    try {
      setUpdatingMedication(updatedMedication.id);
      await medicationService.updateMedication(updatedMedication);
      // Wait for operation to complete before updating UI (non-optimistic)
      setMedications(prev => prev.map(med => 
        med.id === updatedMedication.id ? updatedMedication : med
      ));
      setEditingMedication(null);
    } catch (error) {
      logger.error('Failed to update medication', error as Error, { 
        medicationId: updatedMedication.id,
        medicationName: updatedMedication.name 
      });
      throw error;
    } finally {
      setUpdatingMedication(null);
    }
  };

  const updateUserProgress = async () => {
    if (!user) return;
    
    try {
      // Get user stats from database
      const userStats = await gamificationService.getUserStats(user.id);
      
      // Calculate today's medication adherence
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date();
      todayEnd.setHours(23, 59, 59, 999);
      
      let todayTaken = 0;
      let todayScheduled = 0;
      
      // Get all today's logs in one query for better performance
      const todayLogs = await medicationRepository.getTodaysLogs();
      const userTodayLogs = todayLogs.filter(log => log.status === 'taken');
      
      for (const medication of medications.filter(med => med.isActive)) {
        const medicationModel = new MedicationModel(medication);
        const todayDoses = medicationModel.getScheduledDosesForDate(new Date());
        todayScheduled += todayDoses.length;
        
        // Count taken doses from the pre-fetched logs
        for (const dose of todayDoses) {
          const isTaken = userTodayLogs.some(log => 
            log.medicationId === medication.id &&
            Math.abs(log.scheduledTime.getTime() - dose.getTime()) < 60000 // Within 1 minute
          );
          if (isTaken) {
            todayTaken++;
          }
        }
      }
      
      const adherencePercentage = todayScheduled > 0 ? Math.round((todayTaken / todayScheduled) * 100) : 100;
      
      // Update progress state
      setUserProgress({
        taken: todayTaken,
        scheduled: todayScheduled,
        percentage: adherencePercentage,
        streak: userStats?.currentStreak || 0,
        level: userStats?.level || 1,
        experience: userStats?.experience || 0,
        nextLevelExp: gamificationService.getExperienceForLevel((userStats?.level || 1) + 1)
      });
    } catch (error) {
      logger.error('Failed to update user progress', error as Error, { userId: user?.id });
    }
  };

  const handleMedicationTaken = async (medicationId: string, scheduledTime: Date) => {
    if (!user) {
      logger.warn('Medication taken attempt with no user logged in', { medicationId });
      return;
    }
    
    try {
      // Log the medication as taken
      await medicationRepository.logMedicationTaken(medicationId, scheduledTime, user.id);
      
      // Process inventory update (deduct from supply)
      const updatedMedication = await inventoryService.processDoseTaken(medicationId);
      if (updatedMedication) {
        // Update the medication in our state
        setMedications(prev => prev.map(med => 
          med.id === medicationId ? updatedMedication : med
        ));
      }
      
      // Process gamification updates
      if (user) {
        const gamificationUpdate = await gamificationService.processMedicationTaken(user.id, medicationId);
        
        // Update progress display
        await updateUserProgress();
        
        // Show achievement notifications
        if (gamificationUpdate.leveledUp) {
          logger.info('Level up!', { newLevel: gamificationUpdate.newLevel });
        }
        
        if (gamificationUpdate.newlyUnlockedAchievements.length > 0) {
          logger.info('New achievements unlocked', { count: gamificationUpdate.newlyUnlockedAchievements.length });
        }
      }
      
      // Show a success notification
      const medication = medications.find(med => med.id === medicationId);
      if (medication) {
        notificationService.showNotification(
          '✅ Medication Taken',
          {
            body: `${medication.name} logged successfully! +10 XP earned!`,
            icon: '💊'
          }
        );
      }
    } catch (error) {
      logger.error('Failed to log medication as taken', error as Error, { 
        medicationId, 
        scheduledTime: scheduledTime.toISOString(),
        userId: user?.id 
      });
      throw error;
    }
  };

  const setupNotifications = async () => {
    const hasPermission = await notificationService.requestPermission();
    if (hasPermission && medications.length > 0) {
      const notificationSettings = NotificationService.getDefaultSettings();
      notificationService.scheduleMedicationReminders(medications, notificationSettings);
    }
  };

  const handleToggleMedicationActive = async (medicationId: string) => {
    try {
      const updatedMedication = await medicationService.toggleMedicationActive(medicationId);
      if (updatedMedication) {
        setMedications(prev => prev.map(med => 
          med.id === medicationId ? updatedMedication : med
        ));
      }
    } catch (error) {
      logger.error('Failed to toggle medication active state', error as Error, { medicationId });
    }
  };

  const handleToggleMedicationReminder = async (medicationId: string) => {
    try {
      const updatedMedication = await medicationService.toggleMedicationReminder(medicationId);
      if (updatedMedication) {
        setMedications(prev => prev.map(med => 
          med.id === medicationId ? updatedMedication : med
        ));
      }
    } catch (error) {
      logger.error('Failed to toggle medication reminder', error as Error, { medicationId });
    }
  };

  const handleDeleteMedication = async (medicationId: string) => {
    if (window.confirm('Are you sure you want to delete this medication? This action cannot be undone.')) {
      try {
        setDeletingMedication(medicationId);
        await medicationService.deleteMedication(medicationId);
        // Wait for operation to complete before updating UI (non-optimistic)
        setMedications(prev => prev.filter(med => med.id !== medicationId));
      } catch (error) {
        logger.error('Failed to delete medication', error as Error, { medicationId });
      } finally {
        setDeletingMedication(null);
      }
    }
  };

  // Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="relative mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto shadow-lg">
              <span className="text-white text-3xl">💊</span>
            </div>
            <div className="absolute inset-0 w-20 h-20 border-4 border-primary-200 border-t-primary-600 rounded-3xl animate-spin mx-auto"></div>
          </div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent mb-2">
            Loading MedTracker
          </h2>
          <p className="text-gray-500 text-lg">Preparing your personalized health dashboard... ✨</p>
          <div className="mt-6 flex justify-center space-x-1">
            <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
            <div className="w-2 h-2 bg-primary-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
          </div>
        </div>
      </div>
    );
  }

  // Authentication screen
  if (!isAuthenticated) {
    return (
      <AuthenticationForm
        onSignUp={handleSignUp}
        onSignIn={handleSignIn}
        isLoading={authLoading}
      />
    );
  }

  // Main application (authenticated)
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Session Monitor */}
      <SessionMonitor 
        onSessionExpired={handleSessionExpired}
        onSessionWarning={handleSessionWarning}
      />
      
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">💊</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">MedTracker</h1>
                <p className="text-gray-500 text-sm">Hello, {user?.firstName}! 👋</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              {/* Navigation */}
              <nav className="hidden md:flex space-x-2">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`px-6 py-2 rounded-xl font-medium transition-all duration-200 ${
                    currentView === 'dashboard'
                      ? 'bg-primary-100 text-primary-700 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <span className="flex items-center space-x-2">
                    <span>📊</span>
                    <span>Dashboard</span>
                  </span>
                </button>
                <button
                  onClick={() => setCurrentView('profile')}
                  className={`px-6 py-2 rounded-xl font-medium transition-all duration-200 ${
                    currentView === 'profile'
                      ? 'bg-primary-100 text-primary-700 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <span className="flex items-center space-x-2">
                    <span>👤</span>
                    <span>Profile</span>
                  </span>
                </button>
              </nav>
              
              {/* User Menu */}
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl flex items-center justify-center shadow-sm">
                  <span className="text-sm font-bold text-white">{user?.initials}</span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="text-gray-500 hover:text-red-600 text-sm font-medium transition-colors duration-200"
                >
                  Sign Out
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        {currentView === 'profile' ? (
          user && profile ? (
            <UserProfile 
              user={user} 
              profile={profile} 
              onUpdateProfile={handleUpdateProfile}
            />
          ) : (
            <ProfileSkeleton />
          )
        ) : (
          // Dashboard content
          <>
            {/* Welcome Section */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}! 🌟
              </h2>
              <p className="text-gray-600 text-lg">Ready to take charge of your health today?</p>
            </div>

            {/* Due Medications Section */}
            {medications.length > 0 && (
              <div className="mb-8">
                <DueMedicationsCard
                  medications={medications}
                  onMedicationTaken={handleMedicationTaken}
                />
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {/* Quick Stats Card */}
              <div className="card bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Today's Progress</h3>
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                    <span className="text-blue-600 text-xl">📈</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Medications taken:</span>
                    <span className="font-bold text-lg text-blue-600">
                      {userProgress?.taken || 0}/{userProgress?.scheduled || medications.filter(med => med.isActive).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Current streak:</span>
                    <div className="flex items-center space-x-1">
                      <span className="font-bold text-lg text-blue-600">{userProgress?.streak || 0}</span>
                      <span className="text-sm text-gray-500">days</span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Progress</span>
                      <span>{userProgress?.percentage || 0}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-3 rounded-full transition-all duration-500" style={{ width: `${userProgress?.percentage || 0}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Add Medication Card */}
              <div 
                onClick={() => setShowAddMedication(true)}
                className="card bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-white text-2xl font-bold">+</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">Add Medication</h3>
                  <p className="text-gray-600 text-sm">Start tracking a new medication and build healthy habits</p>
                  <div className="mt-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Quick Setup ⚡
                    </span>
                  </div>
                </div>
              </div>

              {/* Level Progress Card */}
              <div className="card bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Your Level</h3>
                  <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                    <span className="text-purple-600 text-xl">🏆</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
                    Level {userProgress?.level || 1}
                  </div>
                  <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800 mb-4">
                    {userProgress?.level === 1 ? '🌱 Beginner' : 
                     userProgress?.level === 2 ? '🌿 Novice' :
                     userProgress?.level === 3 ? '🌳 Expert' : 
                     userProgress?.level && userProgress.level >= 4 ? '🏆 Master' : '🌱 Beginner'}
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-2">
                      <span>Experience</span>
                      <span>{userProgress?.experience || 0} / {userProgress?.nextLevelExp || 100} XP</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all duration-500" 
                           style={{ 
                             width: `${userProgress?.nextLevelExp ? 
                               ((userProgress.experience || 0) / userProgress.nextLevelExp) * 100 : 0}%` 
                           }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Medications List */}
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">💊 Your Medications</h2>
                <div className="flex items-center space-x-3">
                  <span className="badge badge-primary">
                    {medications.filter(med => med.isActive).length} active
                  </span>
                  <button 
                    onClick={() => setShowAddMedication(true)}
                    className="btn btn-primary text-sm px-4 py-2"
                  >
                    <span className="flex items-center space-x-1">
                      <span>+</span>
                      <span>Add Medication</span>
                    </span>
                  </button>
                </div>
              </div>
              
              {medicationsLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {Array(6).fill(0).map((_, i) => (
                    <MedicationSkeleton key={i} />
                  ))}
                </div>
              ) : medications.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {medications.map((medication) => (
                    <div key={medication.id} className="relative">
                      <MedicationCard
                        medication={medication}
                        onToggleActive={handleToggleMedicationActive}
                        onToggleReminder={handleToggleMedicationReminder}
                        onEdit={handleEditMedication}
                        onDelete={handleDeleteMedication}
                      />
                      {(updatingMedication === medication.id || deletingMedication === medication.id) && (
                        <LoadingOverlay
                          isVisible={true}
                          title={updatingMedication === medication.id ? "Updating..." : "Deleting..."}
                          message={updatingMedication === medication.id ? "Saving changes" : "Removing medication"}
                          variant="modal"
                        />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="card-elevated bg-gradient-to-br from-gray-50 to-white text-center py-12">
                  <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <span className="text-4xl">💊</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-700 mb-2">Ready to start your health journey?</h3>
                  <p className="text-gray-500 mb-8 max-w-md mx-auto">Add your first medication to begin tracking doses, building streaks, and earning achievements!</p>
                  <button 
                    onClick={() => setShowAddMedication(true)}
                    className="btn btn-primary text-lg px-8 py-3"
                  >
                    ✨ Add Your First Medication
                  </button>
                  <div className="mt-6 flex justify-center space-x-8 text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <span>🔔</span>
                      <span>Smart reminders</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span>🏆</span>
                      <span>Earn rewards</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span>📈</span>
                      <span>Track progress</span>
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* Achievements Section */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">🏆 Achievements</h2>
                <span className="badge badge-warning">0 / 10 unlocked</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="card bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 text-center group hover:scale-105 transition-all duration-300">
                  <div className="w-12 h-12 bg-blue-200 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-300 transition-colors">
                    <span className="text-2xl opacity-50">🎯</span>
                  </div>
                  <div className="text-sm font-semibold text-gray-600 mb-1">First Dose</div>
                  <div className="text-xs text-gray-500">Take your first medication</div>
                  <div className="mt-3">
                    <span className="inline-block w-8 h-1 bg-gray-300 rounded-full"></span>
                  </div>
                </div>
                <div className="card bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200 text-center group hover:scale-105 transition-all duration-300">
                  <div className="w-12 h-12 bg-yellow-200 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-yellow-300 transition-colors">
                    <span className="text-2xl opacity-50">⚡</span>
                  </div>
                  <div className="text-sm font-semibold text-gray-600 mb-1">7 Day Streak</div>
                  <div className="text-xs text-gray-500">Build a weekly habit</div>
                  <div className="mt-3">
                    <span className="inline-block w-8 h-1 bg-gray-300 rounded-full"></span>
                  </div>
                </div>
                <div className="card bg-gradient-to-br from-green-50 to-green-100 border-green-200 text-center group hover:scale-105 transition-all duration-300">
                  <div className="w-12 h-12 bg-green-200 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-green-300 transition-colors">
                    <span className="text-2xl opacity-50">🏆</span>
                  </div>
                  <div className="text-sm font-semibold text-gray-600 mb-1">Perfect Week</div>
                  <div className="text-xs text-gray-500">100% adherence for 7 days</div>
                  <div className="mt-3">
                    <span className="inline-block w-8 h-1 bg-gray-300 rounded-full"></span>
                  </div>
                </div>
                <div className="card bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 text-center group hover:scale-105 transition-all duration-300">
                  <div className="w-12 h-12 bg-purple-200 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-purple-300 transition-colors">
                    <span className="text-2xl opacity-50">💎</span>
                  </div>
                  <div className="text-sm font-semibold text-gray-600 mb-1">30 Day Master</div>
                  <div className="text-xs text-gray-500">Monthly consistency</div>
                  <div className="mt-3">
                    <span className="inline-block w-8 h-1 bg-gray-300 rounded-full"></span>
                  </div>
                </div>
              </div>
              <div className="text-center mt-6">
                <p className="text-gray-500 text-sm">✨ Start tracking medications to unlock your first achievements!</p>
              </div>
            </section>
          </>
        )}
      </main>
      
      {/* Add Medication Modal */}
      {showAddMedication && user && (
        <div className="relative">
          <AddMedicationForm
            userId={user.id}
            onSave={handleAddMedication}
            onCancel={() => setShowAddMedication(false)}
          />
          <LoadingOverlay
            isVisible={addingMedication}
            title="Adding Medication..."
            message="Setting up your medication tracking"
            variant="modal"
          />
        </div>
      )}
      
      {/* Edit Medication Modal */}
      {editingMedication && (
        <div className="relative">
          <EditMedicationForm
            medication={editingMedication}
            onSave={handleUpdateMedication}
            onCancel={() => setEditingMedication(null)}
          />
          <LoadingOverlay
            isVisible={updatingMedication === editingMedication.id}
            title="Updating Medication..."
            message="Saving your changes"
            variant="modal"
          />
        </div>
      )}
    </div>
  );
}

export default App;
