import React from 'react';
import { NotificationService } from './NotificationService';

// Custom error types for different parts of the application
export class MedTrackerError extends Error {
  public readonly code: string;
  public readonly category: 'USER' | 'SYSTEM' | 'NETWORK' | 'DATABASE' | 'VALIDATION';
  public readonly severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  public readonly userMessage: string;
  public readonly context?: Record<string, any>;

  constructor(
    message: string, 
    code: string, 
    category: MedTrackerError['category'],
    severity: MedTrackerError['severity'] = 'MEDIUM',
    userMessage?: string,
    context?: Record<string, any>
  ) {
    super(message);
    this.name = 'MedTrackerError';
    this.code = code;
    this.category = category;
    this.severity = severity;
    this.userMessage = userMessage || this.getDefaultUserMessage();
    this.context = context;
  }

  private getDefaultUserMessage(): string {
    switch (this.category) {
      case 'USER':
        return 'Please check your input and try again.';
      case 'NETWORK':
        return 'Network error. Please check your connection and try again.';
      case 'DATABASE':
        return 'Unable to save data. Please try again.';
      case 'VALIDATION':
        return 'Invalid data provided. Please correct the errors and try again.';
      default:
        return 'Something went wrong. Please try again.';
    }
  }
}

// Specific error types
export class ValidationError extends MedTrackerError {
  constructor(message: string, field?: string, value?: any) {
    super(
      message,
      'VALIDATION_ERROR',
      'VALIDATION',
      'MEDIUM',
      message,
      { field, value }
    );
  }
}

export class DatabaseError extends MedTrackerError {
  constructor(message: string, operation?: string, context?: Record<string, any>) {
    super(
      message,
      'DATABASE_ERROR', 
      'DATABASE',
      'HIGH',
      'Unable to save your data. Please try again.',
      { operation, ...context }
    );
  }
}

export class NetworkError extends MedTrackerError {
  constructor(message: string, url?: string, status?: number) {
    super(
      message,
      'NETWORK_ERROR',
      'NETWORK', 
      'MEDIUM',
      'Network connection issue. Please check your internet and try again.',
      { url, status }
    );
  }
}

export class UserInputError extends MedTrackerError {
  constructor(message: string, field?: string) {
    super(
      message,
      'USER_INPUT_ERROR',
      'USER',
      'LOW',
      message,
      { field }
    );
  }
}

// Error logging and analytics
interface ErrorLog {
  id: string;
  timestamp: Date;
  error: MedTrackerError;
  userAgent: string;
  url: string;
  userId?: string;
}

export class ErrorService {
  private static instance: ErrorService;
  private notificationService = NotificationService.getInstance();
  private errorLogs: ErrorLog[] = [];
  private readonly maxLogs = 100;

  private constructor() {}

  static getInstance(): ErrorService {
    if (!ErrorService.instance) {
      ErrorService.instance = new ErrorService();
    }
    return ErrorService.instance;
  }

  /**
   * Handle any error that occurs in the application
   */
  handleError(error: Error | MedTrackerError, context?: Record<string, any>): void {
    let medTrackerError: MedTrackerError;

    if (error instanceof MedTrackerError) {
      medTrackerError = error;
    } else {
      // Convert regular errors to MedTrackerError
      medTrackerError = new MedTrackerError(
        error.message,
        'UNKNOWN_ERROR',
        'SYSTEM',
        'MEDIUM',
        'An unexpected error occurred. Please try again.',
        { originalError: error.name, context }
      );
    }

    // Log the error
    this.logError(medTrackerError);

    // Show user notification based on severity
    this.showErrorNotification(medTrackerError);

    // Console log for development
    if (process.env.NODE_ENV === 'development') {
      console.error('MedTracker Error:', {
        message: medTrackerError.message,
        code: medTrackerError.code,
        category: medTrackerError.category,
        severity: medTrackerError.severity,
        context: medTrackerError.context
      });
    }
  }

  /**
   * Validate input data and throw appropriate errors
   */
  validateInput(data: any, rules: ValidationRule[]): void {
    for (const rule of rules) {
      const value = this.getNestedValue(data, rule.field);
      
      if (rule.required && (value === undefined || value === null || value === '')) {
        throw new ValidationError(`${rule.label} is required`, rule.field, value);
      }

      if (value !== undefined && value !== null && value !== '') {
        if (rule.type && !this.validateType(value, rule.type)) {
          throw new ValidationError(
            `${rule.label} must be a ${rule.type}`, 
            rule.field, 
            value
          );
        }

        if (rule.min !== undefined && value < rule.min) {
          throw new ValidationError(
            `${rule.label} must be at least ${rule.min}`,
            rule.field,
            value
          );
        }

        if (rule.max !== undefined && value > rule.max) {
          throw new ValidationError(
            `${rule.label} must be no more than ${rule.max}`,
            rule.field,
            value
          );
        }

        if (rule.pattern && !rule.pattern.test(String(value))) {
          throw new ValidationError(
            rule.patternMessage || `${rule.label} format is invalid`,
            rule.field,
            value
          );
        }

        if (rule.custom && !rule.custom(value)) {
          throw new ValidationError(
            rule.customMessage || `${rule.label} is invalid`,
            rule.field,
            value
          );
        }
      }
    }
  }

  /**
   * Sanitize user input to prevent common issues
   */
  sanitizeInput(input: string): string {
    if (typeof input !== 'string') return input;
    
    return input
      .trim()
      .replace(/[<>]/g, '') // Remove potential HTML tags
      .slice(0, 1000); // Limit length to prevent extremely long inputs
  }

  /**
   * Wrap async operations with error handling and retry logic
   */
  async withRetry<T>(
    operation: () => Promise<T>,
    maxRetries: number = 2,
    delay: number = 1000
  ): Promise<T> {
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt < maxRetries) {
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, delay * (attempt + 1)));
        }
      }
    }

    // All retries failed
    throw new MedTrackerError(
      `Operation failed after ${maxRetries + 1} attempts: ${lastError?.message || 'Unknown error'}`,
      'RETRY_EXHAUSTED',
      'SYSTEM',
      'HIGH',
      'Unable to complete the operation. Please try again later.',
      { originalError: lastError?.message || 'Unknown error', attempts: maxRetries + 1 }
    );
  }

  /**
   * Get error statistics for monitoring
   */
  getErrorStatistics(): {
    totalErrors: number;
    errorsByCategory: Record<string, number>;
    errorsBySeverity: Record<string, number>;
    recentErrors: ErrorLog[];
  } {
    const errorsByCategory: Record<string, number> = {};
    const errorsBySeverity: Record<string, number> = {};

    this.errorLogs.forEach(log => {
      errorsByCategory[log.error.category] = (errorsByCategory[log.error.category] || 0) + 1;
      errorsBySeverity[log.error.severity] = (errorsBySeverity[log.error.severity] || 0) + 1;
    });

    return {
      totalErrors: this.errorLogs.length,
      errorsByCategory,
      errorsBySeverity,
      recentErrors: this.errorLogs.slice(-10)
    };
  }

  /**
   * Clear error logs (useful for testing or maintenance)
   */
  clearErrorLogs(): void {
    this.errorLogs = [];
  }

  // Private methods

  public logError(error: MedTrackerError): void {
    const errorLog: ErrorLog = {
      id: crypto.randomUUID(),
      timestamp: new Date(),
      error,
      userAgent: navigator.userAgent,
      url: window.location.href,
      userId: this.getCurrentUserId()
    };

    this.errorLogs.push(errorLog);

    // Keep only the last N logs to prevent memory issues
    if (this.errorLogs.length > this.maxLogs) {
      this.errorLogs = this.errorLogs.slice(-this.maxLogs);
    }
  }

  private async showErrorNotification(error: MedTrackerError): Promise<void> {
    const getIcon = (severity: string): string => {
      switch (severity) {
        case 'CRITICAL': return '🚨';
        case 'HIGH': return '⚠️';
        case 'MEDIUM': return '⚠️';
        default: return 'ℹ️';
      }
    };

    // Don't spam user with low severity errors
    if (error.severity === 'LOW') return;

    try {
      await this.notificationService.showNotification(
        `${getIcon(error.severity)} Error`,
        {
          body: error.userMessage,
          icon: '💊',
          tag: `error-${error.category.toLowerCase()}`,
          requireInteraction: error.severity === 'CRITICAL'
        }
      );
    } catch (notificationError) {
      // If notifications fail, just log it
      console.warn('Failed to show error notification:', notificationError);
    }
  }

  private validateType(value: any, type: string): boolean {
    switch (type) {
      case 'string': return typeof value === 'string';
      case 'number': return typeof value === 'number' && !isNaN(value);
      case 'integer': return Number.isInteger(value);
      case 'email': return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value));
      case 'url': return /^https?:\/\/.+/.test(String(value));
      case 'date': return value instanceof Date || !isNaN(Date.parse(value));
      default: return true;
    }
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private getCurrentUserId(): string | undefined {
    // This would integrate with your UserService
    try {
      const userService = (window as any).userService;
      return userService?.getCurrentUser()?.id;
    } catch {
      return undefined;
    }
  }
}

// Validation rule interface
export interface ValidationRule {
  field: string;
  label: string;
  required?: boolean;
  type?: 'string' | 'number' | 'integer' | 'email' | 'url' | 'date';
  min?: number;
  max?: number;
  pattern?: RegExp;
  patternMessage?: string;
  custom?: (value: any) => boolean;
  customMessage?: string;
}

// Utility function for async error handling
export const handleAsync = async <T>(
  promise: Promise<T>
): Promise<[Error | null, T | null]> => {
  try {
    const result = await promise;
    return [null, result];
  } catch (error) {
    return [error as Error, null];
  }
};

// React Error Boundary Component
export const createErrorBoundary = (fallbackComponent: React.ComponentType<{ error?: Error }>) => {
  return class ErrorBoundary extends React.Component<
    { children: React.ReactNode },
    { hasError: boolean; error?: Error }
  > {
    constructor(props: { children: React.ReactNode }) {
      super(props);
      this.state = { hasError: false };
    }

    static getDerivedStateFromError(error: Error) {
      return { hasError: true, error };
    }

    componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
      ErrorService.getInstance().handleError(error, { 
        errorInfo,
        componentStack: errorInfo.componentStack 
      });
    }

    render() {
      if (this.state.hasError) {
        return React.createElement(fallbackComponent, { error: this.state.error });
      }

      return this.props.children;
    }
  };
};