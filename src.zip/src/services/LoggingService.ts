/**
 * Logging Service
 * Provides conditional and structured logging for the MedTracker application
 * Replaces console.log statements with proper logging that can be disabled in production
 */

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  FATAL = 4
}

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: Date;
  source?: string;
  context?: Record<string, any>;
  error?: Error;
}

export class LoggingService {
  private static instance: LoggingService;
  private logLevel: LogLevel;
  private isDevelopment: boolean;
  private logBuffer: LogEntry[] = [];
  private maxBufferSize: number = 1000;

  private constructor() {
    // Determine if we're in development
    this.isDevelopment = 
      process.env.NODE_ENV === 'development' || 
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1';

    // Set log level based on environment
    this.logLevel = this.isDevelopment ? LogLevel.DEBUG : LogLevel.WARN;
  }

  static getInstance(): LoggingService {
    if (!LoggingService.instance) {
      LoggingService.instance = new LoggingService();
    }
    return LoggingService.instance;
  }

  /**
   * Set the minimum log level
   */
  setLogLevel(level: LogLevel): void {
    this.logLevel = level;
  }

  /**
   * Get current log level
   */
  getLogLevel(): LogLevel {
    return this.logLevel;
  }

  /**
   * Check if logging is enabled for development
   */
  isDevelopmentMode(): boolean {
    return this.isDevelopment;
  }

  /**
   * Log a debug message (only in development)
   */
  debug(message: string, context?: Record<string, any>, source?: string): void {
    if (this.shouldLog(LogLevel.DEBUG)) {
      this.writeLog(LogLevel.DEBUG, message, source, context);
    }
  }

  /**
   * Log an info message
   */
  info(message: string, context?: Record<string, any>, source?: string): void {
    if (this.shouldLog(LogLevel.INFO)) {
      this.writeLog(LogLevel.INFO, message, source, context);
    }
  }

  /**
   * Log a warning message
   */
  warn(message: string, context?: Record<string, any>, source?: string): void {
    if (this.shouldLog(LogLevel.WARN)) {
      this.writeLog(LogLevel.WARN, message, source, context);
    }
  }

  /**
   * Log an error message
   */
  error(message: string, error?: Error, context?: Record<string, any>, source?: string): void {
    if (this.shouldLog(LogLevel.ERROR)) {
      this.writeLog(LogLevel.ERROR, message, source, context, error);
    }
  }

  /**
   * Log a fatal error message
   */
  fatal(message: string, error?: Error, context?: Record<string, any>, source?: string): void {
    if (this.shouldLog(LogLevel.FATAL)) {
      this.writeLog(LogLevel.FATAL, message, source, context, error);
    }
  }

  /**
   * Log medication-specific events
   */
  medicationEvent(event: string, medicationId: string, context?: Record<string, any>): void {
    this.info(`Medication Event: ${event}`, {
      medicationId,
      ...context
    }, 'MedicationService');
  }

  /**
   * Log user interaction events
   */
  userEvent(event: string, userId: string, context?: Record<string, any>): void {
    this.info(`User Event: ${event}`, {
      userId,
      ...context
    }, 'UserInteraction');
  }

  /**
   * Log performance metrics
   */
  performance(operation: string, duration: number, context?: Record<string, any>): void {
    this.debug(`Performance: ${operation} took ${duration}ms`, context, 'Performance');
  }

  /**
   * Log API calls and responses
   */
  api(method: string, endpoint: string, status: number, duration?: number): void {
    this.debug(`API: ${method} ${endpoint} - ${status}`, {
      method,
      endpoint,
      status,
      duration
    }, 'API');
  }

  /**
   * Log database operations
   */
  database(operation: string, table?: string, context?: Record<string, any>): void {
    this.debug(`Database: ${operation}${table ? ` on ${table}` : ''}`, context, 'Database');
  }

  /**
   * Log notification events
   */
  notification(event: string, context?: Record<string, any>): void {
    this.info(`Notification: ${event}`, context, 'NotificationService');
  }

  /**
   * Get recent log entries
   */
  getRecentLogs(count: number = 100): LogEntry[] {
    return this.logBuffer.slice(-count);
  }

  /**
   * Get logs by level
   */
  getLogsByLevel(level: LogLevel): LogEntry[] {
    return this.logBuffer.filter(entry => entry.level === level);
  }

  /**
   * Get error logs
   */
  getErrorLogs(): LogEntry[] {
    return this.logBuffer.filter(entry => entry.level >= LogLevel.ERROR);
  }

  /**
   * Clear log buffer
   */
  clearLogs(): void {
    this.logBuffer = [];
  }

  /**
   * Export logs as JSON string
   */
  exportLogs(): string {
    return JSON.stringify(this.logBuffer, null, 2);
  }

  /**
   * Check if we should log at this level
   */
  private shouldLog(level: LogLevel): boolean {
    return level >= this.logLevel;
  }

  /**
   * Write log entry to console and buffer
   */
  private writeLog(
    level: LogLevel, 
    message: string, 
    source?: string, 
    context?: Record<string, any>, 
    error?: Error
  ): void {
    const entry: LogEntry = {
      level,
      message,
      timestamp: new Date(),
      source,
      context,
      error
    };

    // Add to buffer
    this.logBuffer.push(entry);

    // Trim buffer if it gets too large
    if (this.logBuffer.length > this.maxBufferSize) {
      this.logBuffer = this.logBuffer.slice(-this.maxBufferSize * 0.8); // Keep 80% when trimming
    }

    // Only write to console in development or for warnings and above
    if (this.isDevelopment || level >= LogLevel.WARN) {
      this.writeToConsole(entry);
    }
  }

  /**
   * Write to browser console with appropriate styling
   */
  private writeToConsole(entry: LogEntry): void {
    const timestamp = entry.timestamp.toISOString();
    const prefix = entry.source ? `[${entry.source}]` : '';
    const fullMessage = `${timestamp} ${prefix} ${entry.message}`;

    switch (entry.level) {
      case LogLevel.DEBUG:
        if (entry.context) {
          console.debug(fullMessage, entry.context);
        } else {
          console.debug(fullMessage);
        }
        break;

      case LogLevel.INFO:
        if (entry.context) {
          console.info(`ℹ️ ${fullMessage}`, entry.context);
        } else {
          console.info(`ℹ️ ${fullMessage}`);
        }
        break;

      case LogLevel.WARN:
        if (entry.context) {
          console.warn(`⚠️ ${fullMessage}`, entry.context);
        } else {
          console.warn(`⚠️ ${fullMessage}`);
        }
        break;

      case LogLevel.ERROR:
        if (entry.error) {
          console.error(`❌ ${fullMessage}`, entry.error);
          if (entry.context) {
            console.error('Context:', entry.context);
          }
        } else if (entry.context) {
          console.error(`❌ ${fullMessage}`, entry.context);
        } else {
          console.error(`❌ ${fullMessage}`);
        }
        break;

      case LogLevel.FATAL:
        if (entry.error) {
          console.error(`💀 FATAL: ${fullMessage}`, entry.error);
          if (entry.context) {
            console.error('Context:', entry.context);
          }
        } else if (entry.context) {
          console.error(`💀 FATAL: ${fullMessage}`, entry.context);
        } else {
          console.error(`💀 FATAL: ${fullMessage}`);
        }
        break;
    }
  }

  /**
   * Create a logger for a specific component or service
   */
  createLogger(source: string) {
    return {
      debug: (message: string, context?: Record<string, any>) => this.debug(message, context, source),
      info: (message: string, context?: Record<string, any>) => this.info(message, context, source),
      warn: (message: string, context?: Record<string, any>) => this.warn(message, context, source),
      error: (message: string, error?: Error, context?: Record<string, any>) => this.error(message, error, context, source),
      fatal: (message: string, error?: Error, context?: Record<string, any>) => this.fatal(message, error, context, source)
    };
  }
}

// Export singleton instance for easy access
export const logger = LoggingService.getInstance();

// Export convenience functions
export const createLogger = (source: string) => logger.createLogger(source);

// Export specific loggers for common use cases
export const medicationLogger = logger.createLogger('Medication');
export const userLogger = logger.createLogger('User');
export const databaseLogger = logger.createLogger('Database');
export const notificationLogger = logger.createLogger('Notification');
export const performanceLogger = logger.createLogger('Performance');

/**
 * Performance timing decorator
 */
export function logPerformance<T extends (...args: any[]) => any>(
  fn: T,
  operationName?: string
): T {
  return ((...args: any[]) => {
    const start = performance.now();
    const name = operationName || fn.name || 'Anonymous Operation';
    
    try {
      const result = fn(...args);
      
      // Handle both sync and async functions
      if (result instanceof Promise) {
        return result.finally(() => {
          const duration = performance.now() - start;
          logger.performance(name, duration);
        });
      } else {
        const duration = performance.now() - start;
        logger.performance(name, duration);
        return result;
      }
    } catch (error) {
      const duration = performance.now() - start;
      logger.error(`${name} failed after ${duration}ms`, error as Error);
      throw error;
    }
  }) as T;
}