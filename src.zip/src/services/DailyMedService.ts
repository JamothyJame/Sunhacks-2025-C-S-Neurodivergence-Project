import { DrugSearchResult, DrugDetails } from '@/types';

export class DailyMedService {
  private readonly baseUrl = 'https://api.fda.gov/drug';
  private readonly searchUrl = `${this.baseUrl}/label.json`;
  private readonly detailsUrl = `${this.baseUrl}/label.json`;

  // Cache for recent searches to improve performance
  private searchCache = new Map<string, { results: DrugSearchResult[]; timestamp: number }>();
  private readonly cacheTimeout = 5 * 60 * 1000; // 5 minutes

  // Fallback medication database for when DailyMed API is unavailable
  private readonly fallbackMedications: Array<{
    name: string;
    generic: string;
    brand?: string;
    aliases: string[];
    class: string;
  }> = [
    { name: 'Aspirin', generic: 'Aspirin', brand: 'Bayer', aliases: ['acetylsalicylic acid', 'ASA'], class: 'Analgesic, Anti-inflammatory' },
    { name: 'Acetaminophen', generic: 'Acetaminophen', brand: 'Tylenol', aliases: ['paracetamol', 'APAP'], class: 'Analgesic, Antipyretic' },
    { name: 'Ibuprofen', generic: 'Ibuprofen', brand: 'Advil', aliases: ['motrin'], class: 'NSAID' },
    { name: 'Naproxen', generic: 'Naproxen', brand: 'Aleve', aliases: ['naprosyn'], class: 'NSAID' },
    { name: 'Diphenhydramine', generic: 'Diphenhydramine', brand: 'Benadryl', aliases: ['DPH'], class: 'Antihistamine' },
    { name: 'Loratadine', generic: 'Loratadine', brand: 'Claritin', aliases: [], class: 'Antihistamine' },
    { name: 'Cetirizine', generic: 'Cetirizine', brand: 'Zyrtec', aliases: [], class: 'Antihistamine' },
    { name: 'Omeprazole', generic: 'Omeprazole', brand: 'Prilosec', aliases: [], class: 'Proton Pump Inhibitor' },
    { name: 'Ranitidine', generic: 'Ranitidine', brand: 'Zantac', aliases: [], class: 'H2 Receptor Blocker' },
    { name: 'Simvastatin', generic: 'Simvastatin', brand: 'Zocor', aliases: [], class: 'Statin' },
    { name: 'Atorvastatin', generic: 'Atorvastatin', brand: 'Lipitor', aliases: [], class: 'Statin' },
    { name: 'Metformin', generic: 'Metformin', brand: 'Glucophage', aliases: [], class: 'Antidiabetic' },
    { name: 'Lisinopril', generic: 'Lisinopril', brand: 'Prinivil', aliases: [], class: 'ACE Inhibitor' },
    { name: 'Amlodipine', generic: 'Amlodipine', brand: 'Norvasc', aliases: [], class: 'Calcium Channel Blocker' },
    { name: 'Metoprolol', generic: 'Metoprolol', brand: 'Lopressor', aliases: [], class: 'Beta Blocker' },
    { name: 'Hydrochlorothiazide', generic: 'Hydrochlorothiazide', brand: 'Microzide', aliases: ['HCTZ'], class: 'Diuretic' },
    { name: 'Prednisone', generic: 'Prednisone', brand: 'Deltasone', aliases: [], class: 'Corticosteroid' },
    { name: 'Albuterol', generic: 'Albuterol', brand: 'ProAir', aliases: ['salbutamol'], class: 'Bronchodilator' },
    { name: 'Fluoxetine', generic: 'Fluoxetine', brand: 'Prozac', aliases: [], class: 'SSRI Antidepressant' },
    { name: 'Sertraline', generic: 'Sertraline', brand: 'Zoloft', aliases: [], class: 'SSRI Antidepressant' },
    { name: 'Escitalopram', generic: 'Escitalopram', brand: 'Lexapro', aliases: [], class: 'SSRI Antidepressant' },
    { name: 'Alprazolam', generic: 'Alprazolam', brand: 'Xanax', aliases: [], class: 'Benzodiazepine' },
    { name: 'Lorazepam', generic: 'Lorazepam', brand: 'Ativan', aliases: [], class: 'Benzodiazepine' },
    { name: 'Zolpidem', generic: 'Zolpidem', brand: 'Ambien', aliases: [], class: 'Sleep Aid' },
    { name: 'Gabapentin', generic: 'Gabapentin', brand: 'Neurontin', aliases: [], class: 'Anticonvulsant' },
    { name: 'Tramadol', generic: 'Tramadol', brand: 'Ultram', aliases: [], class: 'Opioid Analgesic' },
    { name: 'Cyclobenzaprine', generic: 'Cyclobenzaprine', brand: 'Flexeril', aliases: [], class: 'Muscle Relaxant' },
    { name: 'Warfarin', generic: 'Warfarin', brand: 'Coumadin', aliases: [], class: 'Anticoagulant' },
    { name: 'Clopidogrel', generic: 'Clopidogrel', brand: 'Plavix', aliases: [], class: 'Antiplatelet' },
    { name: 'Pantoprazole', generic: 'Pantoprazole', brand: 'Protonix', aliases: [], class: 'Proton Pump Inhibitor' },
    { name: 'Levothyroxine', generic: 'Levothyroxine', brand: 'Synthroid', aliases: ['T4'], class: 'Thyroid Hormone' },
    { name: 'Furosemide', generic: 'Furosemide', brand: 'Lasix', aliases: [], class: 'Loop Diuretic' },
    { name: 'Spironolactone', generic: 'Spironolactone', brand: 'Aldactone', aliases: [], class: 'Potassium-Sparing Diuretic' },
    { name: 'Trazodone', generic: 'Trazodone', brand: 'Desyrel', aliases: [], class: 'Antidepressant' },
    { name: 'Clonazepam', generic: 'Clonazepam', brand: 'Klonopin', aliases: [], class: 'Benzodiazepine' }
  ];

  // Generate synthetic DrugSearchResult from fallback medication
  private createFallbackResult(med: typeof this.fallbackMedications[0]): DrugSearchResult {
    return {
      setid: `fallback-${med.name.toLowerCase().replace(/\s+/g, '-')}`,
      title: med.name,
      generic_medicine: [med.generic],
      brand_name: med.brand ? [med.brand] : [],
      pharm_classes: [med.class],
      application_number: []
    };
  }

  // Search fallback medications
  private searchFallbackMedications(query: string, limit: number = 20): DrugSearchResult[] {
    const normalizedQuery = query.toLowerCase().trim();
    const results: DrugSearchResult[] = [];
    
    for (const med of this.fallbackMedications) {
      let match = false;
      
      // Check if query matches medication name
      if (med.name.toLowerCase().includes(normalizedQuery) ||
          med.generic.toLowerCase().includes(normalizedQuery) ||
          (med.brand && med.brand.toLowerCase().includes(normalizedQuery))) {
        match = true;
      }
      
      // Check aliases
      for (const alias of med.aliases) {
        if (alias.toLowerCase().includes(normalizedQuery)) {
          match = true;
          break;
        }
      }
      
      if (match) {
        results.push(this.createFallbackResult(med));
      }
      
      if (results.length >= limit) {
        break;
      }
    }
    
    // Sort by relevance (exact matches first, then partial matches)
    return results.sort((a, b) => {
      const aExact = a.title.toLowerCase() === normalizedQuery ||
                    (a.generic_medicine[0] && a.generic_medicine[0].toLowerCase() === normalizedQuery) ||
                    (a.brand_name[0] && a.brand_name[0].toLowerCase() === normalizedQuery);
      const bExact = b.title.toLowerCase() === normalizedQuery ||
                    (b.generic_medicine[0] && b.generic_medicine[0].toLowerCase() === normalizedQuery) ||
                    (b.brand_name[0] && b.brand_name[0].toLowerCase() === normalizedQuery);
      
      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;
      return 0;
    });
  }

  async searchDrugs(query: string, limit: number = 20): Promise<DrugSearchResult[]> {
    if (!query || query.trim().length < 2) {
      return [];
    }

    const normalizedQuery = query.toLowerCase().trim();

    // Check cache first
    const cached = this.searchCache.get(normalizedQuery);
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      return cached.results.slice(0, limit);
    }

    try {
      // Try multiple search strategies with OpenFDA API
      const searchQueries = [
        `openfda.brand_name:${query}*`,
        `openfda.generic_name:${query}*`,
        `openfda.substance_name:${query}*`
      ];
      
      let allResults: any[] = [];
      
      for (const searchQuery of searchQueries) {
        try {
          const params = new URLSearchParams({
            search: searchQuery,
            limit: Math.ceil(limit / searchQueries.length).toString()
          });

          const response = await fetch(`${this.searchUrl}?${params}`);
          
          if (response.ok) {
            const data = await response.json();
            if (data.results && Array.isArray(data.results)) {
              allResults = allResults.concat(data.results);
            }
          }
        } catch (error) {
          // Continue with other search strategies if one fails
          console.log(`Search strategy failed for ${searchQuery}:`, error);
        }
        
        // Break early if we have enough results
        if (allResults.length >= limit) {
          break;
        }
      }
      
      if (allResults.length === 0) {
        throw new Error('No results from OpenFDA API');
      }

      // Remove duplicates and convert to our format
      const uniqueResults = new Map();
      allResults.forEach(item => {
        if (item.openfda) {
          const key = item.openfda.spl_set_id?.[0] || item.set_id || Math.random().toString();
          if (!uniqueResults.has(key)) {
            uniqueResults.set(key, item);
          }
        }
      });
      
      const results: DrugSearchResult[] = Array.from(uniqueResults.values())
        .slice(0, limit)
        .map((item: any) => {
          const openfda = item.openfda || {};
          return {
            setid: openfda.spl_set_id?.[0] || item.set_id || '',
            title: openfda.brand_name?.[0] || openfda.generic_name?.[0] || 'Unknown',
            generic_medicine: openfda.generic_name || [],
            brand_name: openfda.brand_name || [],
            pharm_classes: [
              ...(openfda.pharm_class_epc || []),
              ...(openfda.pharm_class_moa || []),
              ...(openfda.pharm_class_pe || [])
            ].slice(0, 3), // Limit to first 3 classes
            application_number: openfda.application_number || []
          };
        });

      // Cache the results
      this.searchCache.set(normalizedQuery, {
        results,
        timestamp: Date.now()
      });

      return results;
    } catch (error) {
      console.warn('OpenFDA API unavailable, using fallback medication database:', error);
      
      // Try fallback from cache first
      const cached = this.searchCache.get(normalizedQuery);
      if (cached) {
        return cached.results.slice(0, limit);
      }
      
      // Use fallback medication database
      const fallbackResults = this.searchFallbackMedications(query, limit);
      
      // Cache fallback results
      this.searchCache.set(normalizedQuery, {
        results: fallbackResults,
        timestamp: Date.now()
      });
      
      return fallbackResults;
    }
  }

  async getDrugDetails(setid: string): Promise<DrugDetails | null> {
    if (!setid || setid.startsWith('fallback-')) {
      return null;
    }

    try {
      const params = new URLSearchParams({
        search: `set_id:"${setid}"`,
        limit: '1'
      });

      const response = await fetch(`${this.detailsUrl}?${params}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.results || !Array.isArray(data.results) || data.results.length === 0) {
        return null;
      }

      const item = data.results[0];
      const openfda = item.openfda || {};
      
      const details: DrugDetails = {
        setid: item.set_id || setid,
        title: openfda.brand_name?.[0] || openfda.generic_name?.[0] || 'Unknown',
        generic_name: openfda.generic_name?.[0] || '',
        brand_names: openfda.brand_name || [],
        active_ingredients: item.active_ingredient || [],
        dosage_forms: item.dosage_and_administration || [],
        routes: openfda.route || [],
        marketing_start_date: '',
        labeler_name: openfda.manufacturer_name?.[0] || '',
        ndc_numbers: openfda.product_ndc || []
      };

      return details;
    } catch (error) {
      console.error('Error fetching drug details:', error);
      return null;
    }
  }

  // Advanced search with multiple criteria
  async advancedSearch(options: {
    name?: string;
    brand_name?: string;
    generic_name?: string;
    substance_name?: string;
    route?: string;
    dosage_form?: string;
    limit?: number;
  }): Promise<DrugSearchResult[]> {
    const { limit = 20, ...searchParams } = options;
    
    // Build OpenFDA search query
    const searchTerms: string[] = [];
    
    if (searchParams.brand_name) {
      searchTerms.push(`openfda.brand_name:${searchParams.brand_name}*`);
    }
    if (searchParams.generic_name) {
      searchTerms.push(`openfda.generic_name:${searchParams.generic_name}*`);
    }
    if (searchParams.substance_name) {
      searchTerms.push(`openfda.substance_name:${searchParams.substance_name}*`);
    }
    if (searchParams.route) {
      searchTerms.push(`openfda.route:${searchParams.route}`);
    }
    if (searchParams.name) {
      // Search across multiple fields for general name
      searchTerms.push(`(openfda.brand_name:${searchParams.name}* OR openfda.generic_name:${searchParams.name}*)`);
    }

    if (searchTerms.length === 0) {
      return [];
    }

    const searchQuery = searchTerms.join(' AND ');

    try {
      const params = new URLSearchParams({
        search: searchQuery,
        limit: limit.toString()
      });

      const response = await fetch(`${this.searchUrl}?${params}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.results || !Array.isArray(data.results)) {
        return [];
      }

      return data.results.map((item: any) => {
        const openfda = item.openfda || {};
        return {
          setid: openfda.spl_set_id?.[0] || item.set_id || '',
          title: openfda.brand_name?.[0] || openfda.generic_name?.[0] || 'Unknown',
          generic_medicine: openfda.generic_name || [],
          brand_name: openfda.brand_name || [],
          pharm_classes: [
            ...(openfda.pharm_class_epc || []),
            ...(openfda.pharm_class_moa || []),
            ...(openfda.pharm_class_pe || [])
          ].slice(0, 3),
          application_number: openfda.application_number || []
        };
      });
    } catch (error) {
      console.error('Error in advanced search:', error);
      return [];
    }
  }

  // Get suggestions for autocomplete
  async getSuggestions(query: string, maxSuggestions: number = 5): Promise<string[]> {
    if (!query || query.trim().length < 2) {
      return [];
    }

    try {
      const results = await this.searchDrugs(query, maxSuggestions * 2);
      const suggestions = new Set<string>();

      results.forEach(result => {
        // Add brand names
        result.brand_name.forEach(brand => {
          if (brand.toLowerCase().includes(query.toLowerCase())) {
            suggestions.add(brand);
          }
        });

        // Add generic names
        result.generic_medicine.forEach(generic => {
          if (generic.toLowerCase().includes(query.toLowerCase())) {
            suggestions.add(generic);
          }
        });

        // Add title if it matches
        if (result.title.toLowerCase().includes(query.toLowerCase())) {
          suggestions.add(result.title);
        }
      });

      return Array.from(suggestions).slice(0, maxSuggestions);
    } catch (error) {
      console.error('Error getting suggestions:', error);
      return [];
    }
  }

  // Clear cache (useful for memory management)
  clearCache(): void {
    this.searchCache.clear();
  }

  // Clean expired cache entries
  cleanCache(): void {
    const now = Date.now();
    for (const [key, value] of this.searchCache.entries()) {
      if (now - value.timestamp > this.cacheTimeout) {
        this.searchCache.delete(key);
      }
    }
  }

  // Utility method to extract medication name from search result
  getMedicationName(result: DrugSearchResult): string {
    if (result.brand_name.length > 0) {
      return result.brand_name[0];
    }
    if (result.generic_medicine.length > 0) {
      return result.generic_medicine[0];
    }
    return result.title;
  }

  // Utility method to get display name with both brand and generic
  getDisplayName(result: DrugSearchResult): string {
    const brandName = result.brand_name.length > 0 ? result.brand_name[0] : '';
    const genericName = result.generic_medicine.length > 0 ? result.generic_medicine[0] : '';

    if (brandName && genericName && brandName.toLowerCase() !== genericName.toLowerCase()) {
      return `${brandName} (${genericName})`;
    }
    
    return brandName || genericName || result.title;
  }
}