import { Achievement } from '@/types';
import { UserStatsModel } from '@/models/UserStats';

export class AchievementService {
  private static readonly defaultAchievements: Omit<Achievement, 'userId' | 'isUnlocked' | 'unlockedAt'>[] = [
    {
      id: 'first-dose',
      name: 'First Dose',
      description: 'Take your first medication',
      icon: '🎯',
      points: 10,
      requirements: { type: 'total_taken', value: 1 }
    },
    {
      id: 'early-bird',
      name: 'Early Bird',
      description: 'Take 5 medications in total',
      icon: '🌅',
      points: 25,
      requirements: { type: 'total_taken', value: 5 }
    },
    {
      id: 'week-warrior',
      name: 'Week Warrior',
      description: 'Maintain a 7-day streak',
      icon: '⚡',
      points: 50,
      requirements: { type: 'streak', value: 7 }
    },
    {
      id: 'perfect-week',
      name: 'Perfect Week',
      description: 'Achieve 100% adherence for 7 days',
      icon: '🏆',
      points: 75,
      requirements: { type: 'adherence_rate', value: 100 }
    },
    {
      id: 'consistency-king',
      name: 'Consistency King',
      description: 'Take 25 medications in total',
      icon: '👑',
      points: 100,
      requirements: { type: 'total_taken', value: 25 }
    },
    {
      id: 'streak-master',
      name: 'Streak Master',
      description: 'Maintain a 30-day streak',
      icon: '🔥',
      points: 150,
      requirements: { type: 'streak', value: 30 }
    },
    {
      id: 'diamond-dedication',
      name: 'Diamond Dedication',
      description: 'Take 100 medications in total',
      icon: '💎',
      points: 200,
      requirements: { type: 'total_taken', value: 100 }
    },
    {
      id: 'legendary-streak',
      name: 'Legendary Streak',
      description: 'Maintain a 100-day streak',
      icon: '🌟',
      points: 500,
      requirements: { type: 'streak', value: 100 }
    },
    {
      id: 'health-hero',
      name: 'Health Hero',
      description: 'Take 365 medications in total',
      icon: '🦸‍♂️',
      points: 1000,
      requirements: { type: 'total_taken', value: 365 }
    },
    {
      id: 'commitment-champion',
      name: 'Commitment Champion',
      description: 'Use the app for 30 days',
      icon: '🏅',
      points: 250,
      requirements: { type: 'days_active', value: 30 }
    }
  ];

  static initializeAchievements(): Omit<Achievement, 'userId'>[] {
    return this.defaultAchievements.map(achievement => ({
      ...achievement,
      isUnlocked: false
    }));
  }

  static checkAchievements(userStats: UserStatsModel, existingAchievements: Achievement[]): {
    newlyUnlocked: Achievement[];
    updatedAchievements: Achievement[];
  } {
    const newlyUnlocked: Achievement[] = [];
    const updatedAchievements = existingAchievements.map(achievement => {
      if (achievement.isUnlocked) {
        return achievement;
      }

      const meetsRequirement = this.checkRequirement(achievement, userStats);
      
      if (meetsRequirement) {
        const unlockedAchievement: Achievement = {
          ...achievement,
          isUnlocked: true,
          unlockedAt: new Date()
        };
        newlyUnlocked.push(unlockedAchievement);
        return unlockedAchievement;
      }

      return achievement;
    });

    return { newlyUnlocked, updatedAchievements };
  }

  private static checkRequirement(achievement: Achievement, userStats: UserStatsModel): boolean {
    switch (achievement.requirements.type) {
      case 'streak':
        return userStats.meetsStreakRequirement(achievement.requirements.value);
      case 'total_taken':
        return userStats.meetsTotalTakenRequirement(achievement.requirements.value);
      case 'adherence_rate':
        return userStats.meetsAdherenceRequirement(achievement.requirements.value);
      case 'days_active':
        return userStats.meetsDaysActiveRequirement(achievement.requirements.value);
      default:
        return false;
    }
  }

  static calculateTotalAchievementPoints(achievements: Achievement[]): number {
    return achievements
      .filter(achievement => achievement.isUnlocked)
      .reduce((total, achievement) => total + achievement.points, 0);
  }

  static getProgressTowardsAchievement(achievement: Achievement, userStats: UserStatsModel): {
    current: number;
    target: number;
    percentage: number;
  } {
    let current = 0;
    const target = achievement.requirements.value;

    switch (achievement.requirements.type) {
      case 'streak':
        current = userStats.currentStreak;
        break;
      case 'total_taken':
        current = userStats.totalMedicationsTaken;
        break;
      case 'adherence_rate':
        current = userStats.adherenceRate;
        break;
      case 'days_active':
        // Calculate days since first use (simplified)
        current = Math.floor(
          (new Date().getTime() - userStats.updatedAt.getTime()) / (1000 * 60 * 60 * 24)
        );
        break;
    }

    const percentage = Math.min((current / target) * 100, 100);

    return { current, target, percentage };
  }
}