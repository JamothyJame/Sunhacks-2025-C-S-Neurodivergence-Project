import { MedicationModel } from '@/models/Medication';
import { MedicationService } from '@/services/MedicationService';
import { NotificationService } from '@/services/NotificationService';
import { withMutex, withRetry } from '@/utils/atomicOperations';

export interface InventoryAlert {
  medicationId: string;
  medicationName: string;
  type: 'refill_needed' | 'prescription_needed' | 'out_of_stock';
  daysRemaining: number;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface InventorySummary {
  totalMedications: number;
  medicationsWithSupplyInfo: number;
  lowStockCount: number;
  outOfStockCount: number;
  needRefillCount: number;
  needPrescriptionCount: number;
  alerts: InventoryAlert[];
}

export class InventoryService {
  private static instance: InventoryService;
  private medicationService = MedicationService.getInstance();
  private notificationService = NotificationService.getInstance();

  private constructor() {}

  static getInstance(): InventoryService {
    if (!InventoryService.instance) {
      InventoryService.instance = new InventoryService();
    }
    return InventoryService.instance;
  }

  /**
   * Process inventory update when a medication dose is taken
   * Uses atomic operations to prevent race conditions
   */
  async processDoseTaken(medicationId: string): Promise<MedicationModel | null> {
    // Use mutex to ensure only one inventory update per medication at a time
    return withMutex(`medication-inventory-${medicationId}`, async () => {
      return withRetry(async () => {
        const medication = await this.medicationService.getMedication(medicationId);
        if (!medication) {
          console.error('Medication not found:', medicationId);
          return null;
        }

        // Only process inventory if supply tracking is enabled
        if (medication.currentSupply === undefined) {
          // No supply tracking - just return the original medication
          return medication;
        }

        // Validate medication configuration before processing
        const pillsPerDay = medication.frequency * medication.pillsPerDose;
        if (pillsPerDay <= 0) {
          console.warn('Invalid medication configuration, skipping inventory update:', {
            medicationId,
            frequency: medication.frequency,
            pillsPerDose: medication.pillsPerDose
          });
          return medication;
        }

        // Get fresh medication data to avoid working with stale data
        const freshMedication = await this.medicationService.getMedication(medicationId);
        if (!freshMedication || freshMedication.currentSupply === undefined) {
          console.warn('Medication data changed during processing');
          return medication;
        }

        // Check if we have enough supply
        if (freshMedication.currentSupply < freshMedication.pillsPerDose) {
          console.warn('Insufficient supply to consume dose:', {
            medicationId,
            currentSupply: freshMedication.currentSupply,
            pillsPerDose: freshMedication.pillsPerDose
          });
          // Still return the medication but don't update supply
          return freshMedication;
        }

        // Consume dose and update supply
        const updatedMedication = freshMedication.consumeDose();
        
        // Save the updated medication
        const savedMedication = await this.medicationService.updateMedication(updatedMedication);

        // Check if we need to show supply alerts (non-blocking)
        try {
          await this.checkAndSendSupplyAlerts([savedMedication]);
        } catch (alertError) {
          console.warn('Failed to send supply alerts:', alertError);
          // Continue anyway - the main operation succeeded
        }

        return savedMedication;
      }, 3, 100); // Retry up to 3 times with 100ms base delay
    });
  }

  /**
   * Get inventory summary for a user's medications
   */
  async getInventorySummary(userId: string): Promise<InventorySummary> {
    try {
      const medications = await this.medicationService.getUserMedications(userId);
      const activeMedications = medications.filter(med => med.isActive);
      
      let lowStockCount = 0;
      let outOfStockCount = 0;
      let needRefillCount = 0;
      let needPrescriptionCount = 0;
      const alerts: InventoryAlert[] = [];

      const medicationsWithSupplyInfo = activeMedications.filter(
        med => med.currentSupply !== undefined
      ).length;

      for (const medication of activeMedications) {
        const status = medication.getSupplyStatus();
        
        if (status.status === 'out') {
          outOfStockCount++;
          alerts.push({
            medicationId: medication.id,
            medicationName: medication.name,
            type: 'out_of_stock',
            daysRemaining: status.daysRemaining || 0,
            message: status.message,
            priority: 'critical'
          });
        } else if (status.status === 'critical') {
          if (medication.needsNewPrescriptionReminder()) {
            needPrescriptionCount++;
            alerts.push({
              medicationId: medication.id,
              medicationName: medication.name,
              type: 'prescription_needed',
              daysRemaining: status.daysRemaining || 0,
              message: 'Contact doctor for new prescription',
              priority: 'high'
            });
          } else {
            needRefillCount++;
            alerts.push({
              medicationId: medication.id,
              medicationName: medication.name,
              type: 'refill_needed',
              daysRemaining: status.daysRemaining || 0,
              message: 'Time to refill prescription',
              priority: 'high'
            });
          }
        } else if (status.status === 'low') {
          lowStockCount++;
          if (medication.needsRefillReminder(7)) {
            alerts.push({
              medicationId: medication.id,
              medicationName: medication.name,
              type: 'refill_needed',
              daysRemaining: status.daysRemaining || 0,
              message: status.message,
              priority: 'medium'
            });
          }
        }
      }

      // Sort alerts by priority and days remaining
      alerts.sort((a, b) => {
        const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
        if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        }
        return a.daysRemaining - b.daysRemaining;
      });

      return {
        totalMedications: activeMedications.length,
        medicationsWithSupplyInfo,
        lowStockCount,
        outOfStockCount,
        needRefillCount,
        needPrescriptionCount,
        alerts
      };
    } catch (error) {
      console.error('Error getting inventory summary:', error);
      return {
        totalMedications: 0,
        medicationsWithSupplyInfo: 0,
        lowStockCount: 0,
        outOfStockCount: 0,
        needRefillCount: 0,
        needPrescriptionCount: 0,
        alerts: []
      };
    }
  }

  /**
   * Check for supply alerts and send notifications
   */
  async checkAndSendSupplyAlerts(medications: MedicationModel[]): Promise<void> {
    for (const medication of medications) {
      const status = medication.getSupplyStatus();
      
      if (status.status === 'critical' || status.status === 'out') {
        const shouldNotify = await this.shouldSendSupplyNotification(medication);
        
        if (shouldNotify) {
          if (medication.needsNewPrescriptionReminder()) {
            await this.notificationService.showNotification(
              '🩺 New Prescription Needed',
              {
                body: `${medication.name}: Contact your doctor - ${status.message}`,
                icon: '💊',
                tag: `prescription-${medication.id}`,
                requireInteraction: true
              }
            );
          } else {
            await this.notificationService.showNotification(
              '💊 Refill Reminder',
              {
                body: `${medication.name}: ${status.message}`,
                icon: '💊',
                tag: `refill-${medication.id}`,
                requireInteraction: true
              }
            );
          }
          
          // Mark that we've sent this notification
          await this.recordSupplyNotification(medication.id);
        }
      }
    }
  }

  /**
   * Run daily inventory check for all active medications
   */
  async runDailyInventoryCheck(userId: string): Promise<InventorySummary> {
    try {
      const medications = await this.medicationService.getUserMedications(userId);
      const activeMedications = medications.filter(med => med.isActive);
      
      // Check for supply alerts
      await this.checkAndSendSupplyAlerts(activeMedications);
      
      // Return summary
      return await this.getInventorySummary(userId);
    } catch (error) {
      console.error('Error running daily inventory check:', error);
      throw error;
    }
  }

  /**
   * Update medication supply (e.g., after refill)
   */
  async updateMedicationSupply(
    medicationId: string, 
    newSupply: number, 
    refillsUsed: number = 0
  ): Promise<MedicationModel | null> {
    try {
      const medication = await this.medicationService.getMedication(medicationId);
      if (!medication) {
        return null;
      }

      const updatedMedication = medication.updateSupply(newSupply, refillsUsed);
      await this.medicationService.updateMedication(updatedMedication);
      
      // Clear any existing supply notifications for this medication
      await this.clearSupplyNotifications(medicationId);
      
      return updatedMedication;
    } catch (error) {
      console.error('Error updating medication supply:', error);
      return null;
    }
  }

  /**
   * Get medications that need attention (low/out of stock)
   */
  async getMedicationsNeedingAttention(userId: string): Promise<{
    medication: MedicationModel;
    alert: InventoryAlert;
  }[]> {
    const summary = await this.getInventorySummary(userId);
    const medications = await this.medicationService.getUserMedications(userId);
    
    return summary.alerts
      .filter(alert => alert.priority === 'high' || alert.priority === 'critical')
      .map(alert => ({
        medication: medications.find(med => med.id === alert.medicationId)!,
        alert
      }))
      .filter(item => item.medication);
  }

  // Private helper methods
  private async shouldSendSupplyNotification(medication: MedicationModel): Promise<boolean> {
    // Get user preferences for notification throttling
    const userRepository = new (await import('@/repositories/UserRepository')).UserRepository();
    const userPrefs = await userRepository.getUserPreferences(medication.userId);
    
    // Default to 24 hours if no preference set
    const throttleHours = userPrefs?.notifications?.throttleHours || 24;
    
    // Check if we've already sent a notification for this medication recently
    const lastNotificationKey = `supply-notification-${medication.id}`;
    const lastNotification = localStorage.getItem(lastNotificationKey);
    
    if (lastNotification) {
      const lastNotificationDate = new Date(lastNotification);
      const now = new Date();
      const hoursSinceLastNotification = (now.getTime() - lastNotificationDate.getTime()) / (1000 * 60 * 60);
      
      // Use configurable throttle hours
      return hoursSinceLastNotification >= throttleHours;
    }
    
    return true;
  }

  private async recordSupplyNotification(medicationId: string): Promise<void> {
    const notificationKey = `supply-notification-${medicationId}`;
    localStorage.setItem(notificationKey, new Date().toISOString());
  }

  private async clearSupplyNotifications(medicationId: string): Promise<void> {
    const notificationKey = `supply-notification-${medicationId}`;
    localStorage.removeItem(notificationKey);
  }
}