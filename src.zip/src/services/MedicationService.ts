import { MedicationModel } from '@/models/Medication';
import { IndexedDBService } from '@/services/IndexedDBService';

export class MedicationService {
  private static instance: MedicationService;
  private dbService: IndexedDBService;

  private constructor() {
    this.dbService = IndexedDBService.getInstance();
  }

  static getInstance(): MedicationService {
    if (!MedicationService.instance) {
      MedicationService.instance = new MedicationService();
    }
    return MedicationService.instance;
  }

  async addMedication(medication: MedicationModel): Promise<MedicationModel> {
    await this.dbService.saveMedication(medication.rawData);
    return medication;
  }

  async getUserMedications(userId: string): Promise<MedicationModel[]> {
    const medications = await this.dbService.getMedicationsByUserId(userId);
    return medications.map(med => new MedicationModel(med));
  }

  async getActiveMedications(userId: string): Promise<MedicationModel[]> {
    const medications = await this.dbService.getActiveMedicationsByUserId(userId);
    return medications.map(med => new MedicationModel(med));
  }

  async getMedication(medicationId: string): Promise<MedicationModel | null> {
    const medicationData = await this.dbService.getMedication(medicationId);
    return medicationData ? new MedicationModel(medicationData) : null;
  }

  async updateMedication(medication: MedicationModel): Promise<MedicationModel> {
    await this.dbService.saveMedication(medication.rawData);
    return medication;
  }

  async deleteMedication(medicationId: string): Promise<void> {
    await this.dbService.deleteMedication(medicationId);
  }

  async toggleMedicationActive(medicationId: string): Promise<MedicationModel | null> {
    const medicationData = await this.dbService.getMedication(medicationId);
    if (!medicationData) return null;

    const medication = new MedicationModel(medicationData);
    const updatedMedication = medication.toggleActive();
    await this.dbService.saveMedication(updatedMedication.rawData);
    return updatedMedication;
  }

  async toggleMedicationReminder(medicationId: string): Promise<MedicationModel | null> {
    const medicationData = await this.dbService.getMedication(medicationId);
    if (!medicationData) return null;

    const medication = new MedicationModel(medicationData);
    const updatedMedication = medication.toggleReminder();
    await this.dbService.saveMedication(updatedMedication.rawData);
    return updatedMedication;
  }
}