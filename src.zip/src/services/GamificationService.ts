import { UserStatsModel } from '@/models/UserStats';
import { AchievementService } from '@/services/AchievementService';
import { NotificationService } from '@/services/NotificationService';
import { UserRepository } from '@/repositories/UserRepository';
import { MedicationRepository } from '@/repositories/MedicationRepository';
import { IndexedDBService } from '@/services/IndexedDBService';
import { Achievement, MedicationLog } from '@/types';

export interface GamificationUpdate {
  userStats: UserStatsModel;
  newlyUnlockedAchievements: Achievement[];
  leveledUp: boolean;
  pointsEarned: number;
  previousLevel: number;
  newLevel: number;
  streakIncreased: boolean;
  previousStreak: number;
  newStreak: number;
}

export class GamificationService {
  private static instance: GamificationService;
  private userRepository = new UserRepository();
  private medicationRepository = new MedicationRepository();
  private dbService = IndexedDBService.getInstance();
  private notificationService = NotificationService.getInstance();

  private constructor() {}

  static getInstance(): GamificationService {
    if (!GamificationService.instance) {
      GamificationService.instance = new GamificationService();
    }
    return GamificationService.instance;
  }

  /**
   * Process all gamification updates when a medication is taken
   */
  async processMedicationTaken(userId: string, _medicationId: string): Promise<GamificationUpdate> {
    try {
      // Get current user stats
      let userStats = await this.getUserStats(userId);
      const previousLevel = userStats.level;
      const previousStreak = userStats.currentStreak;

      // Calculate points for taking medication
      const pointsEarned = this.calculatePointsForMedication();

      // Add points and potentially level up
      userStats = userStats.addPoints(pointsEarned);

      // Get all medication logs for streak and adherence calculations
      const allLogs = await this.medicationRepository.findAllLogs();
      const userLogs = allLogs.filter(log => log.userId === userId);
      
      // Update stats based on logs
      const totalScheduledDoses = await this.calculateTotalScheduledDoses(userId);
      userStats = userStats.updateFromLogs(userLogs, totalScheduledDoses);

      // Save updated stats
      await this.saveUserStats(userStats);

      // Check for new achievements
      const currentAchievements = await this.getUserAchievements(userId);
      const { newlyUnlocked, updatedAchievements } = AchievementService.checkAchievements(
        userStats,
        currentAchievements
      );

      // Save updated achievements
      await this.saveAchievements(updatedAchievements);

      // Award points for new achievements
      if (newlyUnlocked.length > 0) {
        const achievementPoints = newlyUnlocked.reduce((total, achievement) => total + achievement.points, 0);
        userStats = userStats.addPoints(achievementPoints);
        await this.saveUserStats(userStats);
      }

      // Show notifications for gamification events
      await this.showGamificationNotifications({
        userStats,
        newlyUnlockedAchievements: newlyUnlocked,
        leveledUp: userStats.level > previousLevel,
        pointsEarned: pointsEarned + newlyUnlocked.reduce((total, achievement) => total + achievement.points, 0),
        previousLevel,
        newLevel: userStats.level,
        streakIncreased: userStats.currentStreak > previousStreak,
        previousStreak,
        newStreak: userStats.currentStreak
      });

      return {
        userStats,
        newlyUnlockedAchievements: newlyUnlocked,
        leveledUp: userStats.level > previousLevel,
        pointsEarned: pointsEarned + newlyUnlocked.reduce((total, achievement) => total + achievement.points, 0),
        previousLevel,
        newLevel: userStats.level,
        streakIncreased: userStats.currentStreak > previousStreak,
        previousStreak,
        newStreak: userStats.currentStreak
      };

    } catch (error) {
      console.error('Error processing gamification updates:', error);
      throw error;
    }
  }

  /**
   * Initialize user stats and achievements for new users
   */
  async initializeUserGamification(userId: string): Promise<{
    userStats: UserStatsModel;
    achievements: Achievement[];
  }> {
    try {
      // Create initial user stats
      const userStats = UserStatsModel.create(userId);
      await this.saveUserStats(userStats);

      // Initialize achievements
      const achievements = AchievementService.initializeAchievements().map(achievement => ({
        ...achievement,
        userId,
        id: crypto.randomUUID()
      }));
      await this.saveAchievements(achievements);

      return { userStats, achievements };
    } catch (error) {
      console.error('Error initializing user gamification:', error);
      throw error;
    }
  }

  /**
   * Get current user stats, creating them if they don't exist
   */
  async getUserStats(userId: string): Promise<UserStatsModel> {
    const existingStats = await this.userRepository.getUserStats(userId);
    if (existingStats) {
      return new UserStatsModel(existingStats);
    }
    
    // Create new stats if they don't exist
    const newStats = UserStatsModel.create(userId);
    await this.saveUserStats(newStats);
    return newStats;
  }

  /**
   * Get user achievements, creating them if they don't exist
   */
  private async getUserAchievements(userId: string): Promise<Achievement[]> {
    const existingAchievements = await this.userRepository.getUserAchievements(userId);
    if (existingAchievements && existingAchievements.length > 0) {
      return existingAchievements;
    }

    // Create initial achievements if they don't exist
    const achievements = AchievementService.initializeAchievements().map(achievement => ({
      ...achievement,
      userId,
      id: crypto.randomUUID()
    }));
    await this.saveAchievements(achievements);
    return achievements;
  }

  /**
   * Calculate points earned for taking a medication
   */
  private calculatePointsForMedication(): number {
    const basePoints = 10;
    const bonusChance = Math.random();
    
    // 20% chance for bonus points
    if (bonusChance < 0.2) {
      return basePoints + Math.floor(Math.random() * 10) + 5; // 5-15 bonus points
    }
    
    return basePoints;
  }

  /**
   * Calculate total scheduled doses for adherence rate calculation
   */
  private async calculateTotalScheduledDoses(userId: string): Promise<number> {
    const medications = await this.userRepository.getUserActiveMedications(userId);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    let totalDoses = 0;
    const now = new Date();
    
    for (const medication of medications) {
      const startDate = new Date(medication.startDate);
      const endDate = medication.endDate ? new Date(medication.endDate) : now;
      
      // Calculate days the medication was active in the last 30 days
      const relevantStart = new Date(Math.max(startDate.getTime(), thirtyDaysAgo.getTime()));
      const relevantEnd = new Date(Math.min(endDate.getTime(), now.getTime()));
      
      if (relevantStart <= relevantEnd) {
        const daysDiff = Math.ceil((relevantEnd.getTime() - relevantStart.getTime()) / (1000 * 60 * 60 * 24));
        totalDoses += daysDiff * medication.frequency;
      }
    }
    
    return totalDoses;
  }

  /**
   * Save user stats to database
   */
  private async saveUserStats(userStats: UserStatsModel): Promise<void> {
    await this.dbService.saveUserStats(userStats.rawData);
  }

  /**
   * Save achievements to database
   */
  private async saveAchievements(achievements: Achievement[]): Promise<void> {
    for (const achievement of achievements) {
      await this.dbService.saveAchievement(achievement);
    }
  }

  /**
   * Show notifications for gamification events
   */
  private async showGamificationNotifications(update: GamificationUpdate): Promise<void> {
    // Level up notification (highest priority)
    if (update.leveledUp) {
      await this.notificationService.showNotification(
        '🎉 Level Up!',
        {
          body: `Congratulations! You've reached Level ${update.newLevel}!`,
          icon: '🏆',
          tag: 'level-up',
          requireInteraction: true
        }
      );
    }

    // Achievement notifications
    for (const achievement of update.newlyUnlockedAchievements) {
      await this.notificationService.showAchievementUnlocked(
        achievement.name,
        achievement.points,
        achievement.icon
      );
    }

    // Streak milestone notifications
    if (update.streakIncreased) {
      const milestones = [3, 7, 14, 30, 60, 100];
      if (milestones.includes(update.newStreak)) {
        await this.notificationService.showStreakMilestone(update.newStreak);
      }
    }
  }

  /**
   * Get comprehensive user progress data
   */
  async getUserProgress(userId: string): Promise<{
    userStats: UserStatsModel;
    achievements: Achievement[];
    recentLogs: MedicationLog[];
    todayProgress: {
      taken: number;
      scheduled: number;
      percentage: number;
    };
    weeklyProgress: {
      adherenceRate: number;
      daysActive: number;
    };
  }> {
    try {
      const userStats = await this.getUserStats(userId);
      const achievements = await this.getUserAchievements(userId);
      const recentLogs = await this.medicationRepository.getLogsForPeriod(7);
      const userRecentLogs = recentLogs.filter(log => log.userId === userId);

      // Today's progress
      const todayLogs = await this.medicationRepository.getTodaysLogs();
      const userTodayLogs = todayLogs.filter(log => log.userId === userId);
      const todayTaken = userTodayLogs.filter(log => log.status === 'taken').length;
      
      const activeMedications = await this.userRepository.getUserActiveMedications(userId);
      const todayScheduled = activeMedications.reduce((total, med) => total + med.frequency, 0);
      const todayPercentage = todayScheduled > 0 ? (todayTaken / todayScheduled) * 100 : 0;

      // Weekly progress
      const weeklyTaken = userRecentLogs.filter(log => log.status === 'taken').length;
      const weeklyScheduled = await this.calculateWeeklyScheduledDoses(userId);
      const weeklyAdherenceRate = weeklyScheduled > 0 ? (weeklyTaken / weeklyScheduled) * 100 : 0;
      
      // Days active in the last week
      const uniqueDays = new Set(
        userRecentLogs
          .filter(log => log.status === 'taken')
          .map(log => log.actualTime?.toDateString() || log.createdAt.toDateString())
      );
      const daysActive = uniqueDays.size;

      return {
        userStats,
        achievements,
        recentLogs: userRecentLogs,
        todayProgress: {
          taken: todayTaken,
          scheduled: todayScheduled,
          percentage: Math.round(todayPercentage)
        },
        weeklyProgress: {
          adherenceRate: Math.round(weeklyAdherenceRate),
          daysActive
        }
      };
    } catch (error) {
      console.error('Error getting user progress:', error);
      throw error;
    }
  }

  /**
   * Calculate weekly scheduled doses
   */
  private async calculateWeeklyScheduledDoses(userId: string): Promise<number> {
    const medications = await this.userRepository.getUserActiveMedications(userId);
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    let totalDoses = 0;
    const now = new Date();
    
    for (const medication of medications) {
      const startDate = new Date(medication.startDate);
      const endDate = medication.endDate ? new Date(medication.endDate) : now;
      
      const relevantStart = new Date(Math.max(startDate.getTime(), sevenDaysAgo.getTime()));
      const relevantEnd = new Date(Math.min(endDate.getTime(), now.getTime()));
      
      if (relevantStart <= relevantEnd) {
        const daysDiff = Math.ceil((relevantEnd.getTime() - relevantStart.getTime()) / (1000 * 60 * 60 * 24));
        totalDoses += daysDiff * medication.frequency;
      }
    }
    
    return totalDoses;
  }

  /**
   * Get experience required for a specific level
   */
  getExperienceForLevel(level: number): number {
    if (level <= 1) return 0;
    
    // Experience requirement grows exponentially: level^1.5 * 100
    return Math.floor(Math.pow(level, 1.5) * 100);
  }

  /**
   * Get next achievements the user can work towards
   */
  async getNextAchievements(userId: string): Promise<{
    achievement: Achievement;
    progress: {
      current: number;
      target: number;
      percentage: number;
    };
  }[]> {
    const userStats = await this.getUserStats(userId);
    const achievements = await this.getUserAchievements(userId);
    
    const unlockedAchievements = achievements
      .filter(achievement => !achievement.isUnlocked)
      .map(achievement => ({
        achievement,
        progress: AchievementService.getProgressTowardsAchievement(achievement, userStats)
      }))
      .sort((a, b) => b.progress.percentage - a.progress.percentage);

    return unlockedAchievements.slice(0, 5); // Return top 5 closest achievements
  }
}
