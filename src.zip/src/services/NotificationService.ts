import { MedicationModel } from '@/models/Medication';
import { NotificationSettings } from '@/types';

export class NotificationService {
  private static instance: NotificationService;
  private permission: NotificationPermission = 'default';
  private registeredNotifications = new Map<string, number>(); // notificationId -> timeoutId
  private cleanupInterval: NodeJS.Timeout | null = null;
  private readonly MAX_NOTIFICATIONS = 100; // Limit active notifications
  private readonly CLEANUP_INTERVAL = 5 * 60 * 1000; // 5 minutes

  private constructor() {
    this.permission = Notification.permission;
    this.startCleanupInterval();
  }

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return false;
    }

    if (this.permission === 'granted') {
      return true;
    }

    const permission = await Notification.requestPermission();
    this.permission = permission;
    return permission === 'granted';
  }

  canShowNotifications(): boolean {
    return 'Notification' in window && this.permission === 'granted';
  }

  showNotification(title: string, options: NotificationOptions = {}): Notification | null {
    if (!this.canShowNotifications()) {
      return null;
    }

    const notification = new Notification(title, {
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      ...options
    });

    // Auto-close after 10 seconds
    setTimeout(() => {
      notification.close();
    }, 10000);

    return notification;
  }

  showMedicationReminder(medication: MedicationModel, scheduledTime: Date): Notification | null {
    const timeString = scheduledTime.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });

    return this.showNotification(
      `Time for ${medication.name}`,
      {
        body: `It's ${timeString} - time to take your ${medication.name}${medication.dosage ? ` (${medication.dosage})` : ''}`,
        icon: '💊',
        tag: `medication-${medication.id}-${scheduledTime.getTime()}`,
        requireInteraction: true,
        vibrate: [200, 100, 200]
      } as NotificationOptions
    );
  }

  showAchievementUnlocked(achievementName: string, points: number, icon: string): Notification | null {
    return this.showNotification(
      '🎉 Achievement Unlocked!',
      {
        body: `${icon} ${achievementName} - You earned ${points} points!`,
        tag: `achievement-${achievementName}`,
        icon: '🏆'
      }
    );
  }

  showStreakMilestone(streakCount: number): Notification | null {
    const milestones = [7, 14, 30, 60, 100];
    if (!milestones.includes(streakCount)) {
      return null;
    }

    return this.showNotification(
      `🔥 ${streakCount}-Day Streak!`,
      {
        body: `Amazing! You've maintained your medication routine for ${streakCount} days in a row!`,
        tag: `streak-${streakCount}`,
        icon: '🔥'
      }
    );
  }

  scheduleMedicationReminders(
    medications: MedicationModel[], 
    settings: NotificationSettings
  ): void {
    if (!settings.enabled || !this.canShowNotifications()) {
      return;
    }

    // Clear existing notifications
    this.clearAllScheduledNotifications();

    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    medications.forEach(medication => {
      if (!medication.isActive || !medication.reminderEnabled) {
        return;
      }

      medication.times.forEach(timeString => {
        const [hours, minutes] = timeString.split(':').map(Number);
        
        // Schedule for today if time hasn't passed
        const todayTime = new Date(now);
        todayTime.setHours(hours, minutes, 0, 0);
        
        if (todayTime > now) {
          this.scheduleNotification(medication, todayTime, settings.reminderMinutesBefore);
        }

        // Schedule for tomorrow
        const tomorrowTime = new Date(tomorrow);
        tomorrowTime.setHours(hours, minutes, 0, 0);
        this.scheduleNotification(medication, tomorrowTime, settings.reminderMinutesBefore);
      });
    });
  }

  private scheduleNotification(
    medication: MedicationModel, 
    scheduledTime: Date, 
    minutesBefore: number
  ): void {
    const notificationTime = new Date(scheduledTime.getTime() - (minutesBefore * 60 * 1000));
    const delay = notificationTime.getTime() - Date.now();

    if (delay <= 0) {
      return; // Time has already passed
    }

    // Check if we've reached the notification limit
    if (this.registeredNotifications.size >= this.MAX_NOTIFICATIONS) {
      console.warn('Maximum notifications reached, cleaning up old ones');
      this.cleanupExpiredNotifications();
      
      // If still at limit after cleanup, skip this notification
      if (this.registeredNotifications.size >= this.MAX_NOTIFICATIONS) {
        console.warn('Skipping notification due to memory limits');
        return;
      }
    }

    const notificationId = `${medication.id}-${scheduledTime.getTime()}`;
    
    // Cancel existing notification for the same ID if it exists
    if (this.registeredNotifications.has(notificationId)) {
      const existingTimeoutId = this.registeredNotifications.get(notificationId)!;
      clearTimeout(existingTimeoutId);
    }
    
    const timeoutId = window.setTimeout(() => {
      this.showMedicationReminder(medication, scheduledTime);
      this.registeredNotifications.delete(notificationId);
    }, delay);

    this.registeredNotifications.set(notificationId, timeoutId);
  }

  clearAllScheduledNotifications(): void {
    this.registeredNotifications.forEach(timeoutId => {
      clearTimeout(timeoutId);
    });
    this.registeredNotifications.clear();
  }

  clearNotificationsForMedication(medicationId: string): void {
    const keysToDelete: string[] = [];
    
    this.registeredNotifications.forEach((timeoutId, notificationId) => {
      if (notificationId.startsWith(medicationId)) {
        clearTimeout(timeoutId);
        keysToDelete.push(notificationId);
      }
    });

    keysToDelete.forEach(key => {
      this.registeredNotifications.delete(key);
    });
  }

  // Service Worker registration for background notifications
  async registerServiceWorker(): Promise<boolean> {
    if (!('serviceWorker' in navigator)) {
      console.warn('Service Workers not supported');
      return false;
    }

    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered:', registration);
      return true;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
      return false;
    }
  }

  // Check if the app is running in the background
  setupVisibilityChangeListener(): void {
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        // App became visible, could refresh notifications
        console.log('App became visible');
      }
    });
  }

  // Test notification for settings
  showTestNotification(): Notification | null {
    return this.showNotification(
      'Test Notification',
      {
        body: 'If you can see this, notifications are working correctly!',
        icon: '✅'
      }
    );
  }

  // Get notification settings defaults
  static getDefaultSettings(): NotificationSettings {
    return {
      enabled: true,
      reminderMinutesBefore: 15,
      soundEnabled: true,
      vibrationEnabled: true
    };
  }

  // Start periodic cleanup of expired notifications
  private startCleanupInterval(): void {
    this.cleanupInterval = setInterval(() => {
      this.cleanupExpiredNotifications();
    }, this.CLEANUP_INTERVAL);
  }

  // Stop the cleanup interval
  private stopCleanupInterval(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  // Clean up expired or invalid notifications
  private cleanupExpiredNotifications(): void {
    const now = Date.now();
    const expiredNotifications: string[] = [];
    
    // Check each registered notification
    this.registeredNotifications.forEach((timeoutId, notificationId) => {
      // Extract scheduled time from notification ID
      const parts = notificationId.split('-');
      if (parts.length >= 2) {
        const scheduledTime = parseInt(parts[parts.length - 1]);
        
        // If the scheduled time has passed by more than 1 hour, consider it expired
        if (!isNaN(scheduledTime) && (scheduledTime + 3600000) < now) {
          expiredNotifications.push(notificationId);
          clearTimeout(timeoutId);
        }
      }
    });

    // Remove expired notifications
    expiredNotifications.forEach(notificationId => {
      this.registeredNotifications.delete(notificationId);
    });

    if (expiredNotifications.length > 0) {
      console.log(`Cleaned up ${expiredNotifications.length} expired notifications`);
    }
  }

  // Get notification statistics for monitoring
  getNotificationStats(): {
    activeNotifications: number;
    maxNotifications: number;
    memoryUsage: string;
  } {
    const activeNotifications = this.registeredNotifications.size;
    const memoryUsage = activeNotifications < 50 ? 'Low' :
                       activeNotifications < 80 ? 'Medium' : 'High';
    
    return {
      activeNotifications,
      maxNotifications: this.MAX_NOTIFICATIONS,
      memoryUsage
    };
  }

  // Clean up all resources (call on app shutdown)
  cleanup(): void {
    this.stopCleanupInterval();
    this.clearAllScheduledNotifications();
  }
}
