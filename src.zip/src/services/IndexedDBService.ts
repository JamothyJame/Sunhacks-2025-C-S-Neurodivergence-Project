import { User, UserProfile, UserPreferences, UserSession, Medication, MedicationLog, UserStats, Achievement } from '@/types';
import { ChatMessage, MedicationConversation } from '@/types/chat';
import { ErrorService, DatabaseError } from './ErrorService';
import { sanitizeJSON, deepSanitizeObject } from '@/utils/sanitization';
import { isValidUUID } from '@/utils/uuid';
import { createLogger } from '@/services/LoggingService';

export class IndexedDBService {
  private static instance: IndexedDBService;
  private db: IDBDatabase | null = null;
  private readonly dbName = 'MedTrackerDB';
  private readonly dbVersion = 2;
  private errorService = ErrorService.getInstance();
  private logger = createLogger('IndexedDBService');
  private readonly maxRetries = 2;
  private readonly retryDelay = 1000;

  // Object store names
  private readonly stores = {
    users: 'users',
    userProfiles: 'user_profiles',
    userPreferences: 'user_preferences',
    userSessions: 'user_sessions',
    medications: 'medications',
    logs: 'medication_logs',
    userStats: 'user_stats',
    achievements: 'achievements',
    settings: 'settings',
    conversations: 'medication_conversations',
    chatMessages: 'chat_messages'
  };

  private constructor() {}

  static getInstance(): IndexedDBService {
    if (!IndexedDBService.instance) {
      IndexedDBService.instance = new IndexedDBService();
    }
    return IndexedDBService.instance;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async withRetry<T>(operation: () => Promise<T>, operationName: string): Promise<T> {
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        // Log the error with context
        this.errorService.logError(
          new DatabaseError(
            `${operationName} failed (attempt ${attempt + 1}/${this.maxRetries + 1})`,
            'DATABASE_OPERATION_FAILED',
            { originalError: error, attempt: attempt + 1, operationName }
          )
        );

        // If this was the last attempt, don't retry
        if (attempt === this.maxRetries) {
          break;
        }

        // Wait before retrying
        await this.sleep(this.retryDelay);
      }
    }

    // All retries failed, throw the last error wrapped in our custom error
    throw new DatabaseError(
      `${operationName} failed after ${this.maxRetries + 1} attempts`,
      'DATABASE_OPERATION_FAILED',
      { originalError: lastError, operationName }
    );
  }

  async initialize(): Promise<void> {
    return this.withRetry(async () => {
      return new Promise<void>((resolve, reject) => {
        const request = indexedDB.open(this.dbName, this.dbVersion);

        request.onerror = () => {
          const error = new DatabaseError(
            `Failed to open database: ${request.error?.message || 'Unknown error'}`,
            'DATABASE_OPEN_FAILED',
            { dbName: this.dbName, dbVersion: this.dbVersion }
          );
          this.errorService.logError(error);
          reject(error);
        };

        request.onsuccess = () => {
          this.db = request.result;
          resolve();
        };

        request.onupgradeneeded = (event) => {
          try {
            const db = (event.target as IDBOpenDBRequest).result;

            // Create users store
            if (!db.objectStoreNames.contains(this.stores.users)) {
              const usersStore = db.createObjectStore(this.stores.users, { keyPath: 'id' });
              usersStore.createIndex('email', 'email', { unique: true });
              usersStore.createIndex('isActive', 'isActive', { unique: false });
              usersStore.createIndex('createdAt', 'createdAt', { unique: false });
            }

            // Create user profiles store
            if (!db.objectStoreNames.contains(this.stores.userProfiles)) {
              const userProfilesStore = db.createObjectStore(this.stores.userProfiles, { keyPath: 'userId' });
              userProfilesStore.createIndex('updatedAt', 'updatedAt', { unique: false });
            }

            // Create user preferences store
            if (!db.objectStoreNames.contains(this.stores.userPreferences)) {
              const userPreferencesStore = db.createObjectStore(this.stores.userPreferences, { keyPath: 'userId' });
              userPreferencesStore.createIndex('theme', 'theme', { unique: false });
              userPreferencesStore.createIndex('updatedAt', 'updatedAt', { unique: false });
            }

            // Create user sessions store
            if (!db.objectStoreNames.contains(this.stores.userSessions)) {
              const userSessionsStore = db.createObjectStore(this.stores.userSessions, { keyPath: 'id' });
              userSessionsStore.createIndex('userId', 'userId', { unique: false });
              userSessionsStore.createIndex('expiresAt', 'expiresAt', { unique: false });
              userSessionsStore.createIndex('lastActiveAt', 'lastActiveAt', { unique: false });
            }

            // Create medications store
            if (!db.objectStoreNames.contains(this.stores.medications)) {
              const medicationsStore = db.createObjectStore(this.stores.medications, { keyPath: 'id' });
              medicationsStore.createIndex('userId', 'userId', { unique: false });
              medicationsStore.createIndex('name', 'name', { unique: false });
              medicationsStore.createIndex('isActive', 'isActive', { unique: false });
              medicationsStore.createIndex('createdAt', 'createdAt', { unique: false });
            }

            // Create medication logs store
            if (!db.objectStoreNames.contains(this.stores.logs)) {
              const logsStore = db.createObjectStore(this.stores.logs, { keyPath: 'id' });
              logsStore.createIndex('userId', 'userId', { unique: false });
              logsStore.createIndex('medicationId', 'medicationId', { unique: false });
              logsStore.createIndex('scheduledTime', 'scheduledTime', { unique: false });
              logsStore.createIndex('status', 'status', { unique: false });
              logsStore.createIndex('createdAt', 'createdAt', { unique: false });
            }

            // Create user stats store
            if (!db.objectStoreNames.contains(this.stores.userStats)) {
              const userStatsStore = db.createObjectStore(this.stores.userStats, { keyPath: 'id' });
              userStatsStore.createIndex('userId', 'userId', { unique: true });
              userStatsStore.createIndex('level', 'level', { unique: false });
              userStatsStore.createIndex('updatedAt', 'updatedAt', { unique: false });
            }

            // Create achievements store
            if (!db.objectStoreNames.contains(this.stores.achievements)) {
              const achievementsStore = db.createObjectStore(this.stores.achievements, { keyPath: 'id' });
              achievementsStore.createIndex('userId', 'userId', { unique: false });
              achievementsStore.createIndex('isUnlocked', 'isUnlocked', { unique: false });
              achievementsStore.createIndex('requirements.type', 'requirements.type', { unique: false });
            }

            // Create settings store
            if (!db.objectStoreNames.contains(this.stores.settings)) {
              db.createObjectStore(this.stores.settings, { keyPath: 'key' });
            }

            // Create medication conversations store
            if (!db.objectStoreNames.contains(this.stores.conversations)) {
              const conversationsStore = db.createObjectStore(this.stores.conversations, { keyPath: 'id' });
              conversationsStore.createIndex('userId', 'userId', { unique: false });
              conversationsStore.createIndex('medicationId', 'medicationId', { unique: false });
              conversationsStore.createIndex('isActive', 'isActive', { unique: false });
              conversationsStore.createIndex('createdAt', 'createdAt', { unique: false });
              conversationsStore.createIndex('updatedAt', 'updatedAt', { unique: false });
            }

            // Create chat messages store
            if (!db.objectStoreNames.contains(this.stores.chatMessages)) {
              const chatMessagesStore = db.createObjectStore(this.stores.chatMessages, { keyPath: 'id' });
              chatMessagesStore.createIndex('conversationId', 'conversationId', { unique: false });
              chatMessagesStore.createIndex('role', 'role', { unique: false });
              chatMessagesStore.createIndex('timestamp', 'timestamp', { unique: false });
            }
          } catch (upgradeError) {
            const error = new DatabaseError(
              `Database upgrade failed: ${(upgradeError as Error).message}`,
              'DATABASE_UPGRADE_FAILED',
              { dbName: this.dbName, dbVersion: this.dbVersion, originalError: upgradeError }
            );
            this.errorService.logError(error);
            reject(error);
          }
        };
      });
    }, 'initialize database');
  }

  private getTransaction(storeNames: string | string[], mode: IDBTransactionMode = 'readonly'): IDBTransaction {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    return this.db.transaction(storeNames, mode);
  }

  private getObjectStore(storeName: string, mode: IDBTransactionMode = 'readonly'): IDBObjectStore {
    const transaction = this.getTransaction(storeName, mode);
    return transaction.objectStore(storeName);
  }

  // User CRUD operations
  async saveUser(user: User): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.users, 'readwrite');
      await this.promisifyRequest(store.put(user));
    }, `save user (${user.email})`);
  }

  async getUser(id: string): Promise<User | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.users);
      const result = await this.promisifyRequest(store.get(id));
      return result || null;
    }, `get user by ID (${id})`);
  }

  async getUserByEmail(email: string): Promise<User | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.users);
      const index = store.index('email');
      const result = await this.promisifyRequest(index.get(email));
      return result || null;
    }, `get user by email (${email})`);
  }

  async getAllUsers(): Promise<User[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.users);
      const result = await this.promisifyRequest(store.getAll());
      return result || [];
    }, 'get all users');
  }

  async deleteUser(id: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.users, 'readwrite');
      await this.promisifyRequest(store.delete(id));
    }, `delete user (${id})`);
  }

  // User Profile CRUD operations
  async saveUserProfile(profile: UserProfile): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userProfiles, 'readwrite');
      await this.promisifyRequest(store.put(profile));
    }, `save user profile (${profile.userId})`);
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userProfiles);
      const result = await this.promisifyRequest(store.get(userId));
      return result || null;
    }, `get user profile (${userId})`);
  }

  async deleteUserProfile(userId: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userProfiles, 'readwrite');
      await this.promisifyRequest(store.delete(userId));
    }, `delete user profile (${userId})`);
  }

  // User Preferences CRUD operations
  async saveUserPreferences(preferences: UserPreferences): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userPreferences, 'readwrite');
      await this.promisifyRequest(store.put(preferences));
    }, `save user preferences (${preferences.userId})`);
  }

  async getUserPreferences(userId: string): Promise<UserPreferences | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userPreferences);
      const result = await this.promisifyRequest(store.get(userId));
      return result || null;
    }, `get user preferences (${userId})`);
  }

  async deleteUserPreferences(userId: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userPreferences, 'readwrite');
      await this.promisifyRequest(store.delete(userId));
    }, `delete user preferences (${userId})`);
  }

  // User Session CRUD operations
  async saveUserSession(session: UserSession): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userSessions, 'readwrite');
      await this.promisifyRequest(store.put(session));
    }, `save user session (${session.id})`);
  }

  async getUserSession(sessionId: string): Promise<UserSession | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userSessions);
      const result = await this.promisifyRequest(store.get(sessionId));
      return result || null;
    }, `get user session (${sessionId})`);
  }

  async getUserSessions(userId: string): Promise<UserSession[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userSessions);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.getAll(userId));
      return result || [];
    }, `get user sessions by user ID (${userId})`);
  }

  async deleteUserSession(sessionId: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userSessions, 'readwrite');
      await this.promisifyRequest(store.delete(sessionId));
    }, `delete user session (${sessionId})`);
  }

  async deleteExpiredSessions(): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userSessions, 'readwrite');
      const index = store.index('expiresAt');
      const now = new Date();
      const range = IDBKeyRange.upperBound(now);
      const expiredSessions = await this.promisifyRequest(index.getAll(range));
      
      for (const session of expiredSessions) {
        await this.promisifyRequest(store.delete(session.id));
      }
    }, 'delete expired sessions');
  }

  // Medication CRUD operations
  async saveMedication(medication: Medication): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications, 'readwrite');
      await this.promisifyRequest(store.put(medication));
    }, `save medication (${medication.name})`);
  }

  async getMedication(id: string): Promise<Medication | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications);
      const result = await this.promisifyRequest(store.get(id));
      return result || null;
    }, `get medication by ID (${id})`);
  }

  async getAllMedications(): Promise<Medication[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications);
      const result = await this.promisifyRequest(store.getAll());
      return result || [];
    }, 'get all medications');
  }

  async getActiveMedications(): Promise<Medication[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications);
      const index = store.index('isActive');
      const result = await this.promisifyRequest(index.getAll(IDBKeyRange.only(true)));
      return result || [];
    }, 'get active medications');
  }

  async getMedicationsByUserId(userId: string): Promise<Medication[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.getAll(userId));
      return result || [];
    }, `get medications by user ID (${userId})`);
  }

  async getActiveMedicationsByUserId(userId: string): Promise<Medication[]> {
    return this.withRetry(async () => {
      const medications = await this.getMedicationsByUserId(userId);
      return medications.filter(med => med.isActive);
    }, `get active medications by user ID (${userId})`);
  }

  async deleteMedication(id: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.medications, 'readwrite');
      await this.promisifyRequest(store.delete(id));
    }, `delete medication (${id})`);
  }

  // Medication Log CRUD operations
  async saveMedicationLog(log: MedicationLog): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs, 'readwrite');
      await this.promisifyRequest(store.put(log));
    }, `save medication log (${log.id})`);
  }

  async getMedicationLog(id: string): Promise<MedicationLog | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs);
      const result = await this.promisifyRequest(store.get(id));
      return result || null;
    }, `get medication log by ID (${id})`);
  }

  async getAllMedicationLogs(): Promise<MedicationLog[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs);
      const result = await this.promisifyRequest(store.getAll());
      return result || [];
    }, 'get all medication logs');
  }

  async getMedicationLogsByMedicationId(medicationId: string): Promise<MedicationLog[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs);
      const index = store.index('medicationId');
      const result = await this.promisifyRequest(index.getAll(medicationId));
      return result || [];
    }, `get medication logs by medication ID (${medicationId})`);
  }

  async getMedicationLogsByDateRange(startDate: Date, endDate: Date): Promise<MedicationLog[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs);
      const index = store.index('scheduledTime');
      const range = IDBKeyRange.bound(startDate, endDate);
      const result = await this.promisifyRequest(index.getAll(range));
      return result || [];
    }, `get medication logs by date range (${startDate.toISOString()} to ${endDate.toISOString()})`);
  }

  async getMedicationLogsByUserId(userId: string): Promise<MedicationLog[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.getAll(userId));
      return result || [];
    }, `get medication logs by user ID (${userId})`);
  }

  async getMedicationLogsByUserIdAndDateRange(userId: string, startDate: Date, endDate: Date): Promise<MedicationLog[]> {
    return this.withRetry(async () => {
      const logs = await this.getMedicationLogsByUserId(userId);
      return logs.filter(log => 
        log.scheduledTime >= startDate && log.scheduledTime <= endDate
      );
    }, `get medication logs by user ID and date range (${userId})`);
  }

  async deleteMedicationLog(id: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.logs, 'readwrite');
      await this.promisifyRequest(store.delete(id));
    }, `delete medication log (${id})`);
  }

  // User Stats operations
  async saveUserStats(stats: UserStats): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userStats, 'readwrite');
      await this.promisifyRequest(store.put(stats));
    }, `save user stats (${stats.userId})`);
  }

  async getUserStats(): Promise<UserStats | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userStats);
      const result = await this.promisifyRequest(store.getAll());
      return result.length > 0 ? result[0] : null;
    }, 'get user stats');
  }

  async getUserStatsByUserId(userId: string): Promise<UserStats | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.userStats);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.get(userId));
      return result || null;
    }, `get user stats by user ID (${userId})`);
  }

  // Achievement operations
  async saveAchievement(achievement: Achievement): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.achievements, 'readwrite');
      await this.promisifyRequest(store.put(achievement));
    }, `save achievement (${achievement.id})`);
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.achievements);
      const result = await this.promisifyRequest(store.getAll());
      return result || [];
    }, 'get all achievements');
  }

  async getUnlockedAchievements(): Promise<Achievement[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.achievements);
      const index = store.index('isUnlocked');
      const result = await this.promisifyRequest(index.getAll(IDBKeyRange.only(true)));
      return result || [];
    }, 'get unlocked achievements');
  }

  async getAchievementsByUserId(userId: string): Promise<Achievement[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.achievements);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.getAll(userId));
      return result || [];
    }, `get achievements by user ID (${userId})`);
  }

  async getUnlockedAchievementsByUserId(userId: string): Promise<Achievement[]> {
    return this.withRetry(async () => {
      const achievements = await this.getAchievementsByUserId(userId);
      return achievements.filter(achievement => achievement.isUnlocked);
    }, `get unlocked achievements by user ID (${userId})`);
  }

  // Settings operations
  async saveSetting(key: string, value: any): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.settings, 'readwrite');
      await this.promisifyRequest(store.put({ key, value }));
    }, `save setting (${key})`);
  }

  async getSetting(key: string): Promise<any> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.settings);
      const result = await this.promisifyRequest(store.get(key));
      return result?.value || null;
    }, `get setting (${key})`);
  }

  async getAllSettings(): Promise<Record<string, any>> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.settings);
      const result = await this.promisifyRequest(store.getAll());
      return result.reduce((acc: Record<string, any>, item: any) => {
        acc[item.key] = item.value;
        return acc;
      }, {});
    }, 'get all settings');
  }

  // Utility methods
  private promisifyRequest<T>(request: IDBRequest<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Data validation methods

  private validateMedication(medication: any): medication is Medication {
    return (
      medication &&
      typeof medication === 'object' &&
      typeof medication.id === 'string' &&
      isValidUUID(medication.id) &&
      typeof medication.userId === 'string' &&
      isValidUUID(medication.userId) &&
      typeof medication.name === 'string' &&
      medication.name.length > 0 &&
      typeof medication.frequency === 'number' &&
      medication.frequency > 0 &&
      Array.isArray(medication.times) &&
      medication.times.every((time: any) => typeof time === 'string' && /^\d{2}:\d{2}$/.test(time)) &&
      medication.startDate instanceof Date &&
      typeof medication.color === 'string' &&
      typeof medication.isActive === 'boolean' &&
      typeof medication.reminderEnabled === 'boolean' &&
      medication.createdAt instanceof Date &&
      medication.updatedAt instanceof Date &&
      (medication.currentSupply === undefined || (typeof medication.currentSupply === 'number' && medication.currentSupply >= 0)) &&
      (medication.refillsRemaining === undefined || (typeof medication.refillsRemaining === 'number' && medication.refillsRemaining >= 0)) &&
      (medication.pillsPerDose === undefined || (typeof medication.pillsPerDose === 'number' && medication.pillsPerDose > 0))
    );
  }

  private validateMedicationLog(log: any): log is MedicationLog {
    return (
      log &&
      typeof log === 'object' &&
      typeof log.id === 'string' &&
      isValidUUID(log.id) &&
      typeof log.userId === 'string' &&
      isValidUUID(log.userId) &&
      typeof log.medicationId === 'string' &&
      isValidUUID(log.medicationId) &&
      log.scheduledTime instanceof Date &&
      ['taken', 'missed', 'pending'].includes(log.status) &&
      log.createdAt instanceof Date
    );
  }

  private validateUserStats(stats: any): stats is UserStats {
    return (
      stats &&
      typeof stats === 'object' &&
      typeof stats.id === 'string' &&
      isValidUUID(stats.id) &&
      typeof stats.userId === 'string' &&
      isValidUUID(stats.userId) &&
      typeof stats.level === 'number' &&
      stats.level > 0 &&
      typeof stats.experience === 'number' &&
      stats.experience >= 0 &&
      typeof stats.totalPoints === 'number' &&
      stats.totalPoints >= 0 &&
      typeof stats.currentStreak === 'number' &&
      stats.currentStreak >= 0 &&
      typeof stats.longestStreak === 'number' &&
      stats.longestStreak >= 0 &&
      typeof stats.totalMedicationsTaken === 'number' &&
      stats.totalMedicationsTaken >= 0 &&
      typeof stats.adherenceRate === 'number' &&
      stats.adherenceRate >= 0 &&
      stats.adherenceRate <= 100 &&
      stats.updatedAt instanceof Date
    );
  }

  private validateAchievement(achievement: any): achievement is Achievement {
    return (
      achievement &&
      typeof achievement === 'object' &&
      typeof achievement.id === 'string' &&
      isValidUUID(achievement.id) &&
      typeof achievement.userId === 'string' &&
      isValidUUID(achievement.userId) &&
      typeof achievement.name === 'string' &&
      achievement.name.length > 0 &&
      typeof achievement.description === 'string' &&
      typeof achievement.icon === 'string' &&
      typeof achievement.points === 'number' &&
      achievement.points >= 0 &&
      typeof achievement.requirements === 'object' &&
      achievement.requirements.type &&
      typeof achievement.requirements.value === 'number' &&
      typeof achievement.isUnlocked === 'boolean'
    );
  }

  private sanitizeAndParseDate(dateValue: any): Date | null {
    if (dateValue instanceof Date) {
      return isNaN(dateValue.getTime()) ? null : dateValue;
    }
    
    if (typeof dateValue === 'string') {
      const parsed = new Date(dateValue);
      return isNaN(parsed.getTime()) ? null : parsed;
    }
    
    return null;
  }

  private sanitizeImportedRecord(record: any): any {
    if (!record || typeof record !== 'object') {
      return null;
    }

    // Deep sanitize the object
    const sanitized = deepSanitizeObject(record, 5);
    
    // Convert date strings to Date objects
    const dateFields = ['createdAt', 'updatedAt', 'startDate', 'endDate', 'scheduledTime', 'actualTime', 'expiresAt', 'lastActiveAt', 'unlockedAt', 'supplyLastUpdated'];
    
    for (const field of dateFields) {
      if (sanitized[field]) {
        const date = this.sanitizeAndParseDate(sanitized[field]);
        if (date) {
          sanitized[field] = date;
        } else {
          delete sanitized[field];
        }
      }
    }

    return sanitized;
  }

  async clearAllData(): Promise<void> {
    return this.withRetry(async () => {
      if (!this.db) throw new Error('Database not initialized');

      const storeNames = Object.values(this.stores);
      const transaction = this.getTransaction(storeNames, 'readwrite');

      const clearPromises = storeNames.map(storeName => {
        const store = transaction.objectStore(storeName);
        return this.promisifyRequest(store.clear());
      });

      await Promise.all(clearPromises);
    }, 'clear all data');
  }

  async exportData(): Promise<string> {
    return this.withRetry(async () => {
      const data = {
        medications: await this.getAllMedications(),
        logs: await this.getAllMedicationLogs(),
        userStats: await this.getUserStats(),
        achievements: await this.getAllAchievements(),
        settings: await this.getAllSettings(),
        exportDate: new Date().toISOString()
      };
      return JSON.stringify(data, null, 2);
    }, 'export data');
  }

  async importData(jsonData: string): Promise<void> {
    return this.withRetry(async () => {
      // Sanitize JSON input first
      const sanitizedJson = sanitizeJSON(jsonData);
      
      let data: any;
      try {
        data = JSON.parse(sanitizedJson);
      } catch (error) {
        throw new DatabaseError(
          'Invalid JSON format in import data',
          'IMPORT_INVALID_JSON',
          { originalError: (error as Error).message }
        );
      }

      if (!data || typeof data !== 'object') {
        throw new DatabaseError(
          'Import data must be a valid object',
          'IMPORT_INVALID_FORMAT'
        );
      }

      // Validate data structure
      const validationResults = {
        validMedications: 0,
        invalidMedications: 0,
        validLogs: 0,
        invalidLogs: 0,
        validStats: 0,
        invalidStats: 0,
        validAchievements: 0,
        invalidAchievements: 0,
        validSettings: 0,
        invalidSettings: 0
      };

      // Clear existing data only after validation passes
      await this.clearAllData();

      // Import and validate medications
      if (data.medications && Array.isArray(data.medications)) {
        for (const rawMedication of data.medications) {
          try {
            const sanitized = this.sanitizeImportedRecord(rawMedication);
            if (sanitized && this.validateMedication(sanitized)) {
              await this.saveMedication(sanitized);
              validationResults.validMedications++;
            } else {
              this.logger.warn('Invalid medication data during import', { medicationData: rawMedication });
              validationResults.invalidMedications++;
            }
          } catch (error) {
            this.logger.error('Error importing medication', error as Error);
            validationResults.invalidMedications++;
          }
        }
      }

      // Import and validate logs
      if (data.logs && Array.isArray(data.logs)) {
        for (const rawLog of data.logs) {
          try {
            const sanitized = this.sanitizeImportedRecord(rawLog);
            if (sanitized && this.validateMedicationLog(sanitized)) {
              await this.saveMedicationLog(sanitized);
              validationResults.validLogs++;
            } else {
              this.logger.warn('Invalid log data during import', { logData: rawLog });
              validationResults.invalidLogs++;
            }
          } catch (error) {
            this.logger.error('Error importing log', error as Error);
            validationResults.invalidLogs++;
          }
        }
      }

      // Import and validate user stats
      if (data.userStats) {
        try {
          const sanitized = this.sanitizeImportedRecord(data.userStats);
          if (sanitized && this.validateUserStats(sanitized)) {
            await this.saveUserStats(sanitized);
            validationResults.validStats++;
          } else {
            this.logger.warn('Invalid user stats data during import', { userStats: data.userStats });
            validationResults.invalidStats++;
          }
        } catch (error) {
          this.logger.error('Error importing user stats', error as Error);
          validationResults.invalidStats++;
        }
      }

      // Import and validate achievements
      if (data.achievements && Array.isArray(data.achievements)) {
        for (const rawAchievement of data.achievements) {
          try {
            const sanitized = this.sanitizeImportedRecord(rawAchievement);
            if (sanitized && this.validateAchievement(sanitized)) {
              await this.saveAchievement(sanitized);
              validationResults.validAchievements++;
            } else {
              this.logger.warn('Invalid achievement data during import', { achievementData: rawAchievement });
              validationResults.invalidAchievements++;
            }
          } catch (error) {
            this.logger.error('Error importing achievement', error as Error);
            validationResults.invalidAchievements++;
          }
        }
      }

      // Import and validate settings
      if (data.settings && typeof data.settings === 'object') {
        for (const [rawKey, rawValue] of Object.entries(data.settings)) {
          try {
            // Sanitize key and value
            const sanitizedKey = typeof rawKey === 'string' ? rawKey.slice(0, 100) : null;
            const sanitizedValue = deepSanitizeObject(rawValue, 3);
            
            if (sanitizedKey && sanitizedValue !== null) {
              await this.saveSetting(sanitizedKey, sanitizedValue);
              validationResults.validSettings++;
            } else {
              this.logger.warn('Invalid setting during import', { key: rawKey, value: rawValue });
              validationResults.invalidSettings++;
            }
          } catch (error) {
            this.logger.error('Error importing setting', error as Error);
            validationResults.invalidSettings++;
          }
        }
      }

      // Log import summary
      this.logger.info('Import completed', { validationResults });
      
      // Warn if there were validation failures
      const totalInvalid = Object.entries(validationResults)
        .filter(([key]) => key.startsWith('invalid'))
        .reduce((sum, [, value]) => sum + value, 0);
      
      if (totalInvalid > 0) {
        this.logger.warn('Import completed with validation failures', { 
          totalInvalid, 
          validationResults 
        });
      }
    }, 'import data');
  }

  // Chat operations
  async saveConversation(conversation: MedicationConversation): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.conversations, 'readwrite');
      await this.promisifyRequest(store.put(conversation));
    }, `save conversation (${conversation.id})`);
  }

  async getConversation(id: string): Promise<MedicationConversation | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.conversations);
      const result = await this.promisifyRequest(store.get(id));
      return result || null;
    }, `get conversation by ID (${id})`);
  }

  async getConversationsByMedicationId(medicationId: string): Promise<MedicationConversation[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.conversations);
      const index = store.index('medicationId');
      const result = await this.promisifyRequest(index.getAll(medicationId));
      return result || [];
    }, `get conversations by medication ID (${medicationId})`);
  }

  async getConversationsByUserId(userId: string): Promise<MedicationConversation[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.conversations);
      const index = store.index('userId');
      const result = await this.promisifyRequest(index.getAll(userId));
      return result || [];
    }, `get conversations by user ID (${userId})`);
  }

  async getActiveConversationsByUserId(userId: string): Promise<MedicationConversation[]> {
    return this.withRetry(async () => {
      const conversations = await this.getConversationsByUserId(userId);
      return conversations.filter(conv => conv.isActive);
    }, `get active conversations by user ID (${userId})`);
  }

  async saveChatMessage(message: ChatMessage): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.chatMessages, 'readwrite');
      await this.promisifyRequest(store.put(message));
    }, `save chat message (${message.id})`);
  }

  async getChatMessage(id: string): Promise<ChatMessage | null> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.chatMessages);
      const result = await this.promisifyRequest(store.get(id));
      return result || null;
    }, `get chat message by ID (${id})`);
  }

  async getChatMessagesByConversationId(conversationId: string): Promise<ChatMessage[]> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.chatMessages);
      const index = store.index('conversationId');
      const result = await this.promisifyRequest(index.getAll(conversationId));
      // Sort by timestamp
      return (result || []).sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    }, `get chat messages by conversation ID (${conversationId})`);
  }

  async deleteConversation(id: string): Promise<void> {
    return this.withRetry(async () => {
      // Delete all messages in this conversation first
      const messages = await this.getChatMessagesByConversationId(id);
      const messageStore = this.getObjectStore(this.stores.chatMessages, 'readwrite');
      
      for (const message of messages) {
        await this.promisifyRequest(messageStore.delete(message.id));
      }

      // Delete the conversation itself
      const conversationStore = this.getObjectStore(this.stores.conversations, 'readwrite');
      await this.promisifyRequest(conversationStore.delete(id));
    }, `delete conversation (${id})`);
  }

  async deleteChatMessage(id: string): Promise<void> {
    return this.withRetry(async () => {
      const store = this.getObjectStore(this.stores.chatMessages, 'readwrite');
      await this.promisifyRequest(store.delete(id));
    }, `delete chat message (${id})`);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}
