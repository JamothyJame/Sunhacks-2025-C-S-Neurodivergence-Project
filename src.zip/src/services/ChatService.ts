import { IndexedDBService } from './IndexedDBService';
import GeminiService, { ChatContext, GeminiMessage } from './GeminiService';
import { ChatMessage, MedicationConversation, ChatState, ChatError } from '@/types/chat';
import { Medication } from '@/types';
import { LoggingService } from './LoggingService';
import { generateUUID } from '@/utils/uuid';

class ChatService {
  private static instance: ChatService;
  private dbService: IndexedDBService;
  private geminiService: GeminiService;
  private chatStates: Map<string, ChatState> = new Map(); // conversation ID -> state
  private logger: LoggingService;

  private constructor() {
    this.dbService = IndexedDBService.getInstance();
    this.geminiService = GeminiService.getInstance();
    this.logger = LoggingService.getInstance();
  }

  public static getInstance(): ChatService {
    if (!ChatService.instance) {
      ChatService.instance = new ChatService();
    }
    return ChatService.instance;
  }

  /**
   * Get or create a conversation for a medication
   */
  async getOrCreateConversation(
    userId: string,
    medication: Medication,
    initialMessage?: string
  ): Promise<MedicationConversation> {
    try {
      // Check if there's already an active conversation for this medication
      const existing = await this.dbService.getConversationsByMedicationId(medication.id);
      const activeConversation = existing.find(conv => conv.isActive && conv.userId === userId);

      if (activeConversation) {
        this.logger.debug('ChatService: Found existing conversation', { 
          conversationId: activeConversation.id,
          medicationId: medication.id 
        });
        return activeConversation;
      }

      // Create new conversation
      const conversation: MedicationConversation = {
        id: generateUUID(),
        userId,
        medicationId: medication.id,
        medicationName: medication.name,
        title: initialMessage ? 
          initialMessage.slice(0, 50) + (initialMessage.length > 50 ? '...' : '') : 
          `Chat about ${medication.name}`,
        createdAt: new Date(),
        updatedAt: new Date(),
        messageCount: 0,
        isActive: true
      };

      await this.dbService.saveConversation(conversation);
      
      // Initialize chat state
      this.chatStates.set(conversation.id, {
        isLoading: false,
        error: null,
        isTyping: false,
        connectionStatus: 'connected'
      });

      this.logger.info('ChatService: Created new conversation', { 
        conversationId: conversation.id,
        medicationId: medication.id,
        medicationName: medication.name 
      });

      return conversation;
    } catch (error) {
      this.logger.error('ChatService: Error creating conversation', error as Error, { userId, medication });
      throw new Error('Failed to create conversation. Please try again.');
    }
  }

  /**
   * Send a message in a conversation
   */
  async sendMessage(
    conversationId: string,
    userMessage: string,
    medication: Medication
  ): Promise<ChatMessage> {
    try {
      // Validate message
      if (!userMessage.trim()) {
        throw new Error('Message cannot be empty');
      }

      // Set loading state
      this.updateChatState(conversationId, { isLoading: true, error: null, isTyping: false });

      // Save user message
      const userChatMessage: ChatMessage = {
        id: generateUUID(),
        conversationId,
        role: 'user',
        content: userMessage.trim(),
        timestamp: new Date()
      };

      await this.dbService.saveChatMessage(userChatMessage);

      // Get conversation history
      const history = await this.getConversationHistory(conversationId);
      const geminiHistory: GeminiMessage[] = history
        .slice(-10) // Last 10 messages for context
        .map(msg => ({
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp
        }));

      // Set typing state
      this.updateChatState(conversationId, { isTyping: true });

      // Build context
      const context: ChatContext = {
        type: 'medication',
        medicationId: medication.id,
        medicationName: medication.name,
        dosage: medication.dosage,
        frequency: `${medication.frequency}x daily`,
        notes: medication.notes
      };

      // Get AI response
      const aiResponse = await this.geminiService.sendMessage(
        userMessage,
        context,
        geminiHistory
      );

      // Save AI response
      const aiChatMessage: ChatMessage = {
        id: generateUUID(),
        conversationId,
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date()
      };

      await this.dbService.saveChatMessage(aiChatMessage);

      // Update conversation metadata
      const conversation = await this.dbService.getConversation(conversationId);
      if (conversation) {
        conversation.updatedAt = new Date();
        conversation.messageCount += 2; // user + AI message
        await this.dbService.saveConversation(conversation);
      }

      // Clear loading states
      this.updateChatState(conversationId, { 
        isLoading: false, 
        isTyping: false,
        connectionStatus: 'connected' 
      });

      this.logger.info('ChatService: Message sent successfully', {
        conversationId,
        messageLength: userMessage.length,
        responseLength: aiResponse.length
      });

      return aiChatMessage;
    } catch (error) {
      const chatError = this.handleChatError(error as Error);
      
      // Save error message
      const errorMessage: ChatMessage = {
        id: generateUUID(),
        conversationId,
        role: 'assistant',
        content: chatError.message,
        timestamp: new Date(),
        isError: true,
        errorMessage: chatError.message
      };

      await this.dbService.saveChatMessage(errorMessage);

      // Update state with error
      this.updateChatState(conversationId, {
        isLoading: false,
        isTyping: false,
        error: chatError.message,
        connectionStatus: chatError.type === 'network' ? 'disconnected' : 'connected'
      });

      this.logger.error('ChatService: Error sending message', error as Error, {
        conversationId,
        messageLength: userMessage.length
      });

      throw chatError;
    }
  }

  /**
   * Get conversation history
   */
  async getConversationHistory(conversationId: string): Promise<ChatMessage[]> {
    try {
      return await this.dbService.getChatMessagesByConversationId(conversationId);
    } catch (error) {
      this.logger.error('ChatService: Error getting conversation history', error as Error, { conversationId });
      throw new Error('Failed to load conversation history');
    }
  }

  /**
   * Get all conversations for a user
   */
  async getUserConversations(userId: string): Promise<MedicationConversation[]> {
    try {
      const conversations = await this.dbService.getActiveConversationsByUserId(userId);
      return conversations.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
    } catch (error) {
      this.logger.error('ChatService: Error getting user conversations', error as Error, { userId });
      throw new Error('Failed to load conversations');
    }
  }

  /**
   * Delete a conversation and all its messages
   */
  async deleteConversation(conversationId: string): Promise<void> {
    try {
      await this.dbService.deleteConversation(conversationId);
      this.chatStates.delete(conversationId);
      this.logger.info('ChatService: Conversation deleted', { conversationId });
    } catch (error) {
      this.logger.error('ChatService: Error deleting conversation', error as Error, { conversationId });
      throw new Error('Failed to delete conversation');
    }
  }

  /**
   * Get chat state for a conversation
   */
  getChatState(conversationId: string): ChatState {
    if (!this.chatStates.has(conversationId)) {
      this.chatStates.set(conversationId, {
        isLoading: false,
        error: null,
        isTyping: false,
        connectionStatus: 'connected'
      });
    }
    return this.chatStates.get(conversationId)!;
  }

  /**
   * Update chat state
   */
  updateChatState(conversationId: string, updates: Partial<ChatState>): void {
    const currentState = this.getChatState(conversationId);
    this.chatStates.set(conversationId, { ...currentState, ...updates });
  }

  /**
   * Test connection to Gemini API
   */
  async testConnection(): Promise<boolean> {
    try {
      return await this.geminiService.testConnection();
    } catch (error) {
      this.logger.error('ChatService: Connection test failed', error as Error);
      return false;
    }
  }

  /**
   * Handle and categorize chat errors
   */
  private handleChatError(error: Error): ChatError {
    const message = error.message.toLowerCase();

    if (message.includes('rate limit') || message.includes('too many requests')) {
      return {
        type: 'rate_limit',
        message: 'You\'re sending messages too quickly. Please wait a moment before trying again.',
        retryable: true
      };
    }

    if (message.includes('network') || message.includes('fetch') || message.includes('connection')) {
      return {
        type: 'network',
        message: 'Network connection issue. Please check your internet connection and try again.',
        retryable: true
      };
    }

    if (message.includes('api key') || message.includes('unauthorized') || message.includes('forbidden')) {
      return {
        type: 'api',
        message: 'There was an authentication issue. Please try again later.',
        retryable: false
      };
    }

    if (message.includes('empty') || message.includes('invalid')) {
      return {
        type: 'validation',
        message: 'Please enter a valid message and try again.',
        retryable: false
      };
    }

    return {
      type: 'api',
      message: 'Something went wrong. Please try again.',
      retryable: true
    };
  }
}

export default ChatService;
