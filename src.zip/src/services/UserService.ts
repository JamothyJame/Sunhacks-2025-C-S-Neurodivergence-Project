import { UserSession } from '@/types';
import { UserModel, UserProfileModel, UserPreferencesModel } from '@/models/UserModel';
import { UserRepository } from '@/repositories/UserRepository';
import { createLogger } from '@/services/LoggingService';

export interface AuthenticationResult {
  success: boolean;
  user?: UserModel;
  profile?: UserProfileModel;
  preferences?: UserPreferencesModel;
  session?: UserSession;
  error?: string;
}

export interface SessionValidationResult {
  valid: boolean;
  user?: UserModel;
  session?: UserSession;
  error?: string;
}

export class UserService {
  private static instance: UserService;
  private userRepository: UserRepository;
  private currentUser: UserModel | null = null;
  private currentSession: UserSession | null = null;
  private logger = createLogger('UserService');

  private constructor() {
    this.userRepository = new UserRepository();
  }

  static getInstance(): UserService {
    if (!UserService.instance) {
      UserService.instance = new UserService();
    }
    return UserService.instance;
  }

  // Authentication and session management
  async signUpUser(userData: {
    email: string;
    firstName: string;
    lastName: string;
    dateOfBirth?: Date;
    timezone?: string;
  }): Promise<AuthenticationResult> {
    try {
      // Check if user already exists
      const existingUser = await this.userRepository.getUserByEmail(userData.email);
      if (existingUser) {
        return {
          success: false,
          error: 'User already exists with this email'
        };
      }

      // Set default timezone if not provided
      const detectedTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const userDataWithDefaults = {
        ...userData,
        timezone: userData.timezone || detectedTimezone
      };

      // Create user with profile and preferences
      const { user, profile, preferences } = await this.userRepository.setupNewUser(userDataWithDefaults);

      // Create session
      const session = await this.createUserSession(user.id);

      // Set current user and session
      this.currentUser = user;
      this.currentSession = session;

      return {
        success: true,
        user,
        profile,
        preferences,
        session
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create user'
      };
    }
  }

  async signInUser(email: string): Promise<AuthenticationResult> {
    try {
      // Authenticate user
      const user = await this.userRepository.authenticateUser(email);
      if (!user) {
        return {
          success: false,
          error: 'User not found or inactive'
        };
      }

      // Get user profile and preferences
      const profile = await this.userRepository.getUserProfile(user.id);
      const preferences = await this.userRepository.getUserPreferences(user.id);

      // Create new session
      const session = await this.createUserSession(user.id);

      // Set current user and session
      this.currentUser = user;
      this.currentSession = session;

      return {
        success: true,
        user,
        profile: profile || undefined,
        preferences: preferences || undefined,
        session
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Authentication failed'
      };
    }
  }

  async signOutUser(): Promise<void> {
    if (this.currentSession) {
      await this.userRepository.deleteUserSession(this.currentSession.id);
    }
    
    this.currentUser = null;
    this.currentSession = null;
  }

  async validateSession(sessionId: string): Promise<SessionValidationResult> {
    try {
      const result = await this.userRepository.validateUserSession(sessionId);
      if (!result) {
        return {
          valid: false,
          error: 'Invalid or expired session'
        };
      }

      // Update current user and session
      this.currentUser = result.user;
      this.currentSession = result.session;

      return {
        valid: true,
        user: result.user,
        session: result.session
      };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof Error ? error.message : 'Session validation failed'
      };
    }
  }

  async refreshSession(sessionId: string): Promise<UserSession | null> {
    try {
      const validation = await this.validateSession(sessionId);
      if (!validation.valid || !validation.user) {
        return null;
      }

      // Create new session with extended expiry
      const newSession = await this.createUserSession(validation.user.id);
      
      // Delete old session
      await this.userRepository.deleteUserSession(sessionId);
      
      this.currentSession = newSession;
      return newSession;
    } catch (error) {
      this.logger.error('Failed to refresh session', error as Error, { sessionId });
      return null;
    }
  }

  private async createUserSession(userId: string): Promise<UserSession> {
    const deviceInfo = {
      platform: navigator.platform,
      browser: navigator.userAgent.includes('Chrome') ? 'Chrome' : 
               navigator.userAgent.includes('Firefox') ? 'Firefox' :
               navigator.userAgent.includes('Safari') ? 'Safari' : 'Unknown',
      isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    };

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30); // 30 days expiry

    return await this.userRepository.createUserSession({
      userId,
      deviceInfo,
      createdAt: new Date(),
      expiresAt,
      lastActiveAt: new Date()
    });
  }

  // User management
  async getCurrentUser(): Promise<{
    user: UserModel;
    profile: UserProfileModel;
    preferences: UserPreferencesModel;
  } | null> {
    if (!this.currentUser) {
      return null;
    }

    const profile = await this.userRepository.getUserProfile(this.currentUser.id);
    const preferences = await this.userRepository.getUserPreferences(this.currentUser.id);

    if (!profile || !preferences) {
      return null;
    }

    return {
      user: this.currentUser,
      profile,
      preferences
    };
  }

  async updateUserProfile(updates: Partial<Parameters<UserProfileModel['update']>[0]>): Promise<UserProfileModel | null> {
    if (!this.currentUser) {
      return null;
    }

    const profile = await this.userRepository.getUserProfile(this.currentUser.id);
    if (!profile) {
      return null;
    }

    const updatedProfile = profile.update(updates);
    return await this.userRepository.updateUserProfile(updatedProfile);
  }

  async updateUserPreferences(updates: Partial<Parameters<UserPreferencesModel['update']>[0]>): Promise<UserPreferencesModel | null> {
    if (!this.currentUser) {
      return null;
    }

    const preferences = await this.userRepository.getUserPreferences(this.currentUser.id);
    if (!preferences) {
      return null;
    }

    const updatedPreferences = preferences.update(updates);
    return await this.userRepository.updateUserPreferences(updatedPreferences);
  }

  async updateUser(updates: Partial<Parameters<UserModel['update']>[0]>): Promise<UserModel | null> {
    if (!this.currentUser) {
      return null;
    }

    const updatedUser = this.currentUser.update(updates);
    this.currentUser = await this.userRepository.updateUser(updatedUser);
    return this.currentUser;
  }

  async deleteUser(): Promise<boolean> {
    if (!this.currentUser) {
      return false;
    }

    try {
      await this.userRepository.deleteUser(this.currentUser.id);
      this.currentUser = null;
      this.currentSession = null;
      return true;
    } catch (error) {
      this.logger.error('Failed to delete user', error as Error, { userId: this.currentUser?.id });
      return false;
    }
  }

  // User data and insights
  async getUserInsights(): Promise<any> {
    if (!this.currentUser) {
      return null;
    }

    return await this.userRepository.getUserInsights(this.currentUser.id);
  }

  async exportUserData(): Promise<string | null> {
    if (!this.currentUser) {
      return null;
    }

    return await this.userRepository.exportUserData(this.currentUser.id);
  }

  // Session management utilities
  async cleanupExpiredSessions(): Promise<void> {
    await this.userRepository.deleteExpiredSessions();
  }

  async getUserSessions(): Promise<UserSession[]> {
    if (!this.currentUser) {
      return [];
    }

    return await this.userRepository.getUserSessions(this.currentUser.id);
  }

  async revokeSession(sessionId: string): Promise<boolean> {
    try {
      await this.userRepository.deleteUserSession(sessionId);
      
      // If it's the current session, sign out
      if (this.currentSession?.id === sessionId) {
        this.currentUser = null;
        this.currentSession = null;
      }
      
      return true;
    } catch (error) {
      this.logger.error('Failed to revoke session', error as Error, { sessionId });
      return false;
    }
  }

  async revokeAllOtherSessions(): Promise<boolean> {
    if (!this.currentUser || !this.currentSession) {
      return false;
    }

    try {
      const sessions = await this.getUserSessions();
      const otherSessions = sessions.filter(session => session.id !== this.currentSession?.id);
      
      for (const session of otherSessions) {
        await this.userRepository.deleteUserSession(session.id);
      }
      
      return true;
    } catch (error) {
      this.logger.error('Failed to revoke other sessions', error as Error, { userId: this.currentUser?.id });
      return false;
    }
  }

  // Utility methods
  isAuthenticated(): boolean {
    return this.currentUser !== null && this.currentSession !== null;
  }

  getCurrentUserId(): string | null {
    return this.currentUser?.id || null;
  }

  getCurrentSessionId(): string | null {
    return this.currentSession?.id || null;
  }

  // New: expose current session safely
  getCurrentSession(): UserSession | null {
    return this.currentSession ? { ...this.currentSession } : null;
  }

  // New: get session expiry
  getSessionExpiry(): Date | null {
    return this.currentSession ? new Date(this.currentSession.expiresAt) : null;
  }

  // New: get time left in ms
  getSessionTimeLeftMs(): number | null {
    const expiry = this.getSessionExpiry();
    if (!expiry) return null;
    return expiry.getTime() - Date.now();
  }

  // User preferences helpers
  async getUserTheme(): Promise<'light' | 'dark' | 'system'> {
    if (!this.currentUser) {
      return 'system';
    }

    const preferences = await this.userRepository.getUserPreferences(this.currentUser.id);
    return preferences?.theme || 'system';
  }

  async getUserTimeFormat(): Promise<'12h' | '24h'> {
    if (!this.currentUser) {
      return '12h';
    }

    const preferences = await this.userRepository.getUserPreferences(this.currentUser.id);
    return preferences?.timeFormat || '12h';
  }

  async getUserDateFormat(): Promise<'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD'> {
    if (!this.currentUser) {
      return 'MM/DD/YYYY';
    }

    const preferences = await this.userRepository.getUserPreferences(this.currentUser.id);
    return preferences?.dateFormat || 'MM/DD/YYYY';
  }

  // Initialize service (call when app starts)
  async initializeFromStorage(): Promise<boolean> {
    try {
      // Try to restore session from localStorage
      const sessionId = localStorage.getItem('medtracker_session_id');
      if (!sessionId) {
        return false;
      }

      const validation = await this.validateSession(sessionId);
      if (!validation.valid) {
        localStorage.removeItem('medtracker_session_id');
        return false;
      }

      return true;
    } catch (error) {
      this.logger.error('Failed to initialize user service from storage', error as Error);
      localStorage.removeItem('medtracker_session_id');
      return false;
    }
  }

  // Save session to localStorage
  saveSessionToStorage(): void {
    if (this.currentSession) {
      localStorage.setItem('medtracker_session_id', this.currentSession.id);
    } else {
      localStorage.removeItem('medtracker_session_id');
    }
  }
}