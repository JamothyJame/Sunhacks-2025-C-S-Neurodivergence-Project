import { LoggingService } from './LoggingService';

export interface GeminiMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface GeminiRequest {
  contents: Array<{
    parts: Array<{
      text: string;
    }>;
  }>;
}

export interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
    safetyRatings: Array<{
      category: string;
      probability: string;
    }>;
  }>;
}

export interface ChatContext {
  type: 'medication';
  medicationId: string;
  medicationName: string;
  dosage?: string;
  frequency?: string;
  notes?: string;
}

class GeminiService {
  private static instance: GeminiService;
  private apiKey: string;
  private baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
  private requestQueue: Map<string, Promise<string>> = new Map();
  private rateLimitDelay = 1000; // 1 second between requests
  private lastRequestTime = 0;
  private logger: LoggingService;

  private constructor() {
    this.apiKey = (import.meta as any).env?.VITE_GEMINI_API_KEY || 'AIzaSyClBED0PPH3_4v3mrqnlMpNdMm3d6ndag4';
    this.logger = LoggingService.getInstance();
  }

  public static getInstance(): GeminiService {
    if (!GeminiService.instance) {
      GeminiService.instance = new GeminiService();
    }
    return GeminiService.instance;
  }

  private async enforceRateLimit(): Promise<void> {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < this.rateLimitDelay) {
      const waitTime = this.rateLimitDelay - timeSinceLastRequest;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    this.lastRequestTime = Date.now();
  }

  private buildSystemPrompt(context: ChatContext): string {
    const basePrompt = `You are a helpful AI assistant for a medication tracking app called MedTracker. 
You specialize in providing helpful, accurate, and safe information about medications and medication adherence.

IMPORTANT DISCLAIMERS AND LIMITATIONS:
- You are NOT a replacement for professional medical advice
- Always encourage users to consult their healthcare providers for medical decisions
- Never provide specific dosage recommendations or dosage changes
- Focus on general medication information, adherence tips, and supportive guidance
- Be supportive and encouraging about medication adherence
- If asked about non-medication topics, politely redirect to medication-related discussions

Your responses should be:
- Informative but not prescriptive
- Supportive of medication adherence
- Encouraging users to work with their healthcare team
- Focused on the specific medication context provided

`;

    return basePrompt + `
MEDICATION CONTEXT: 
- Medication: "${context.medicationName}"${context.dosage ? `\n- Dosage: ${context.dosage}` : ''}${context.frequency ? `\n- Frequency: ${context.frequency}` : ''}${context.notes ? `\n- Notes: ${context.notes}` : ''}

Provide helpful information about this medication, adherence tips, or answer questions while maintaining the safety guidelines above.`;
  }

  public async sendMessage(
    message: string, 
    context: ChatContext,
    conversationHistory: GeminiMessage[] = []
  ): Promise<string> {
    try {
      // Implement request deduplication for medication-specific conversations
      const requestKey = `medication-${context.medicationId}-${message.slice(0, 50)}`;
      if (this.requestQueue.has(requestKey)) {
        this.logger.info('GeminiService: Returning cached request for duplicate message');
        return await this.requestQueue.get(requestKey)!;
      }

      const requestPromise = this._sendMessageInternal(message, context, conversationHistory);
      this.requestQueue.set(requestKey, requestPromise);

      const response = await requestPromise;
      
      // Clean up the request from queue after completion
      setTimeout(() => {
        this.requestQueue.delete(requestKey);
      }, 5000);

      return response;
    } catch (error) {
      this.logger.error('GeminiService: Error sending message', error as Error, { message, context });
      throw error;
    }
  }

  private async _sendMessageInternal(
    message: string,
    context: ChatContext,
    conversationHistory: GeminiMessage[] = []
  ): Promise<string> {
    await this.enforceRateLimit();

    const systemPrompt = this.buildSystemPrompt(context);
    
    // Build conversation context
    let fullPrompt = systemPrompt + '\n\n';
    
    // Add conversation history (last 10 messages to keep context manageable)
    const recentHistory = conversationHistory.slice(-10);
    if (recentHistory.length > 0) {
      fullPrompt += 'CONVERSATION HISTORY:\n';
      recentHistory.forEach((msg) => {
        const role = msg.role === 'user' ? 'User' : 'Assistant';
        fullPrompt += `${role}: ${msg.content}\n`;
      });
      fullPrompt += '\n';
    }
    
    fullPrompt += `User: ${message}`;

    const requestBody: GeminiRequest = {
      contents: [
        {
          parts: [
            {
              text: fullPrompt
            }
          ]
        }
      ]
    };

    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-goog-api-key': this.apiKey,
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      this.logger.error('GeminiService: API request failed', undefined, { 
        status: response.status, 
        statusText: response.statusText, 
        error: errorText 
      });
      
      if (response.status === 429) {
        throw new Error('Rate limit exceeded. Please wait a moment before sending another message.');
      } else if (response.status === 403) {
        throw new Error('API key is invalid or access denied.');
      } else if (response.status >= 500) {
        throw new Error('Gemini service is temporarily unavailable. Please try again later.');
      } else {
        throw new Error(`Failed to get response from AI assistant: ${response.statusText}`);
      }
    }

    const data: GeminiResponse = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      this.logger.warn('GeminiService: No candidates in response', { data });
      throw new Error('No response generated. Please try rephrasing your question.');
    }

    const candidate = data.candidates[0];
    
    if (candidate.finishReason === 'SAFETY') {
      this.logger.warn('GeminiService: Response blocked by safety filters', { candidate });
      throw new Error('Unable to provide a response due to safety guidelines. Please rephrase your question.');
    }

    if (!candidate.content || !candidate.content.parts || candidate.content.parts.length === 0) {
      this.logger.warn('GeminiService: No content in response', { candidate });
      throw new Error('Empty response received. Please try again.');
    }

    const responseText = candidate.content.parts[0].text;
    this.logger.debug('GeminiService: Successfully received response', { 
      messageLength: responseText.length,
      context: context.type 
    });

    return responseText;
  }

  public async testConnection(): Promise<boolean> {
    try {
      const response = await this.sendMessage(
        'What should I know about taking this medication consistently?',
        { 
          type: 'medication',
          medicationId: 'test-med-id',
          medicationName: 'Test Medication'
        }
      );
      return response.length > 0;
    } catch (error) {
      this.logger.error('GeminiService: Connection test failed', error as Error);
      return false;
    }
  }

}

export default GeminiService;