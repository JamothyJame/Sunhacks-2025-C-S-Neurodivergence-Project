import { User, UserProfile, UserSession, Medication, MedicationLog, UserStats, Achievement } from '@/types';
import { UserModel, UserProfileModel, UserPreferencesModel } from '@/models/UserModel';
import { IndexedDBService } from '@/services/IndexedDBService';

export class UserRepository {
  private dbService: IndexedDBService;

  constructor() {
    this.dbService = IndexedDBService.getInstance();
  }

  // User CRUD operations
  async createUser(userData: Omit<User, 'id' | 'createdAt' | 'updatedAt' | 'isActive'>): Promise<UserModel> {
    const userModel = UserModel.create(userData);
    await this.dbService.saveUser(userModel.rawData);
    return userModel;
  }

  async getUserById(id: string): Promise<UserModel | null> {
    const userData = await this.dbService.getUser(id);
    return userData ? new UserModel(userData) : null;
  }

  async getUserByEmail(email: string): Promise<UserModel | null> {
    const userData = await this.dbService.getUserByEmail(email);
    return userData ? new UserModel(userData) : null;
  }

  async updateUser(userModel: UserModel): Promise<UserModel> {
    await this.dbService.saveUser(userModel.rawData);
    return userModel;
  }

  async deleteUser(id: string): Promise<void> {
    // Also delete related data
    await this.deleteAllUserData(id);
    await this.dbService.deleteUser(id);
  }

  async getAllUsers(): Promise<UserModel[]> {
    const users = await this.dbService.getAllUsers();
    return users.map(user => new UserModel(user));
  }

  // User Profile operations
  async createUserProfile(userId: string, profileData: Partial<Omit<UserProfile, 'userId' | 'updatedAt'>> = {}): Promise<UserProfileModel> {
    const profileModel = UserProfileModel.create(userId, profileData);
    await this.dbService.saveUserProfile(profileModel.rawData);
    return profileModel;
  }

  async getUserProfile(userId: string): Promise<UserProfileModel | null> {
    const profileData = await this.dbService.getUserProfile(userId);
    return profileData ? new UserProfileModel(profileData) : null;
  }

  async updateUserProfile(profileModel: UserProfileModel): Promise<UserProfileModel> {
    await this.dbService.saveUserProfile(profileModel.rawData);
    return profileModel;
  }

  async deleteUserProfile(userId: string): Promise<void> {
    await this.dbService.deleteUserProfile(userId);
  }

  // User Preferences operations
  async createUserPreferences(userId: string): Promise<UserPreferencesModel> {
    const preferencesModel = UserPreferencesModel.createDefault(userId);
    await this.dbService.saveUserPreferences(preferencesModel.rawData);
    return preferencesModel;
  }

  async getUserPreferences(userId: string): Promise<UserPreferencesModel | null> {
    const preferencesData = await this.dbService.getUserPreferences(userId);
    return preferencesData ? new UserPreferencesModel(preferencesData) : null;
  }

  async updateUserPreferences(preferencesModel: UserPreferencesModel): Promise<UserPreferencesModel> {
    await this.dbService.saveUserPreferences(preferencesModel.rawData);
    return preferencesModel;
  }

  async deleteUserPreferences(userId: string): Promise<void> {
    await this.dbService.deleteUserPreferences(userId);
  }

  // User Session operations
  async createUserSession(sessionData: Omit<UserSession, 'id'>): Promise<UserSession> {
    const session: UserSession = {
      ...sessionData,
      id: crypto.randomUUID()
    };
    await this.dbService.saveUserSession(session);
    return session;
  }

  async getUserSession(sessionId: string): Promise<UserSession | null> {
    return await this.dbService.getUserSession(sessionId);
  }

  async getUserSessions(userId: string): Promise<UserSession[]> {
    return await this.dbService.getUserSessions(userId);
  }

  async updateUserSession(session: UserSession): Promise<UserSession> {
    await this.dbService.saveUserSession(session);
    return session;
  }

  async deleteUserSession(sessionId: string): Promise<void> {
    await this.dbService.deleteUserSession(sessionId);
  }

  async deleteExpiredSessions(): Promise<void> {
    await this.dbService.deleteExpiredSessions();
  }

  // User-specific data queries
  async getUserMedications(userId: string): Promise<Medication[]> {
    return await this.dbService.getMedicationsByUserId(userId);
  }

  async getUserActiveMedications(userId: string): Promise<Medication[]> {
    return await this.dbService.getActiveMedicationsByUserId(userId);
  }

  async getUserMedicationLogs(userId: string, startDate?: Date, endDate?: Date): Promise<MedicationLog[]> {
    if (startDate && endDate) {
      return await this.dbService.getMedicationLogsByUserIdAndDateRange(userId, startDate, endDate);
    }
    return await this.dbService.getMedicationLogsByUserId(userId);
  }

  async getUserStats(userId: string): Promise<UserStats | null> {
    return await this.dbService.getUserStatsByUserId(userId);
  }

  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return await this.dbService.getAchievementsByUserId(userId);
  }

  async getUserUnlockedAchievements(userId: string): Promise<Achievement[]> {
    return await this.dbService.getUnlockedAchievementsByUserId(userId);
  }

  // User setup and onboarding
  async setupNewUser(userData: Omit<User, 'id' | 'createdAt' | 'updatedAt' | 'isActive'>): Promise<{
    user: UserModel;
    profile: UserProfileModel;
    preferences: UserPreferencesModel;
  }> {
    // Create user
    const user = await this.createUser(userData);
    
    // Create default profile
    const profile = await this.createUserProfile(user.id);
    
    // Create default preferences
    const preferences = await this.createUserPreferences(user.id);

    return { user, profile, preferences };
  }

  // Authentication helper methods
  async authenticateUser(email: string): Promise<UserModel | null> {
    const user = await this.getUserByEmail(email);
    if (!user || !user.isActive) {
      return null;
    }

    // Update last login
    const updatedUser = user.updateLastLogin();
    await this.updateUser(updatedUser);
    
    return updatedUser;
  }

  async validateUserSession(sessionId: string): Promise<{ user: UserModel; session: UserSession } | null> {
    const session = await this.getUserSession(sessionId);
    if (!session || session.expiresAt < new Date()) {
      return null;
    }

    const user = await this.getUserById(session.userId);
    if (!user || !user.isActive) {
      return null;
    }

    // Update session last active time
    const updatedSession = {
      ...session,
      lastActiveAt: new Date()
    };
    await this.updateUserSession(updatedSession);

    return { user, session: updatedSession };
  }

  // Data cleanup operations
  async deleteAllUserData(userId: string): Promise<void> {
    // Delete user profile
    await this.deleteUserProfile(userId);
    
    // Delete user preferences
    await this.deleteUserPreferences(userId);
    
    // Delete user sessions
    const sessions = await this.getUserSessions(userId);
    for (const session of sessions) {
      await this.deleteUserSession(session.id);
    }
    
    // Delete medications
    const medications = await this.getUserMedications(userId);
    for (const medication of medications) {
      await this.dbService.deleteMedication(medication.id);
    }
    
    // Delete medication logs
    const logs = await this.getUserMedicationLogs(userId);
    for (const log of logs) {
      await this.dbService.deleteMedicationLog(log.id);
    }
    
    // Delete user stats
    const userStats = await this.getUserStats(userId);
    if (userStats) {
      // Note: IndexedDBService doesn't have deleteUserStats method yet
      // This would need to be added to the service
    }
    
    // Delete achievements
    const achievements = await this.getUserAchievements(userId);
    for (const achievement of achievements) {
      await this.dbService.saveAchievement({
        ...achievement,
        userId,
        isUnlocked: false,
        unlockedAt: undefined
      });
    }
  }

  // Data export/import for user
  async exportUserData(userId: string): Promise<string> {
    const user = await this.getUserById(userId);
    const profile = await this.getUserProfile(userId);
    const preferences = await this.getUserPreferences(userId);
    const medications = await this.getUserMedications(userId);
    const logs = await this.getUserMedicationLogs(userId);
    const stats = await this.getUserStats(userId);
    const achievements = await this.getUserAchievements(userId);

    const userData = {
      user: user?.rawData,
      profile: profile?.rawData,
      preferences: preferences?.rawData,
      medications,
      logs,
      stats,
      achievements,
      exportDate: new Date().toISOString()
    };

    return JSON.stringify(userData, null, 2);
  }

  // User analytics and insights
  async getUserInsights(userId: string): Promise<{
    totalMedications: number;
    activeMedications: number;
    totalLogs: number;
    recentActivity: number;
    completionRate: number;
    streak: number;
  }> {
    const medications = await this.getUserMedications(userId);
    const activeMedications = medications.filter(med => med.isActive);
    const logs = await this.getUserMedicationLogs(userId);
    const stats = await this.getUserStats(userId);
    
    // Recent activity (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentLogs = await this.getUserMedicationLogs(userId, thirtyDaysAgo, new Date());
    
    // Calculate completion rate
    const takenLogs = logs.filter(log => log.status === 'taken').length;
    const completionRate = logs.length > 0 ? (takenLogs / logs.length) * 100 : 0;

    return {
      totalMedications: medications.length,
      activeMedications: activeMedications.length,
      totalLogs: logs.length,
      recentActivity: recentLogs.length,
      completionRate: Math.round(completionRate),
      streak: stats?.currentStreak || 0
    };
  }
}