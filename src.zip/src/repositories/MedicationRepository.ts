import { MedicationLog } from '@/types';
import { MedicationModel } from '@/models/Medication';
import { IndexedDBService } from '@/services/IndexedDBService';

export class MedicationRepository {
  private dbService: IndexedDBService;

  constructor() {
    this.dbService = IndexedDBService.getInstance();
  }

  // Medication operations
  async save(medication: MedicationModel): Promise<void> {
    await this.dbService.saveMedication(medication.rawData);
  }

  async findById(id: string): Promise<MedicationModel | null> {
    const data = await this.dbService.getMedication(id);
    return data ? new MedicationModel(data) : null;
  }

  async findAll(): Promise<MedicationModel[]> {
    const medications = await this.dbService.getAllMedications();
    return medications.map(med => new MedicationModel(med));
  }

  async findActive(): Promise<MedicationModel[]> {
    const medications = await this.dbService.getActiveMedications();
    return medications.map(med => new MedicationModel(med));
  }

  async update(medication: MedicationModel): Promise<void> {
    await this.dbService.saveMedication(medication.rawData);
  }

  async delete(id: string): Promise<void> {
    await this.dbService.deleteMedication(id);
    // Also delete related logs
    const logs = await this.dbService.getMedicationLogsByMedicationId(id);
    for (const log of logs) {
      await this.dbService.deleteMedicationLog(log.id);
    }
  }

  async searchByName(query: string): Promise<MedicationModel[]> {
    const allMedications = await this.findAll();
    return allMedications.filter(med => 
      med.name.toLowerCase().includes(query.toLowerCase()) ||
      (med.genericName && med.genericName.toLowerCase().includes(query.toLowerCase()))
    );
  }

  // Log operations
  async saveLog(log: MedicationLog): Promise<void> {
    await this.dbService.saveMedicationLog(log);
  }

  async findLogById(id: string): Promise<MedicationLog | null> {
    return await this.dbService.getMedicationLog(id);
  }

  async findAllLogs(): Promise<MedicationLog[]> {
    return await this.dbService.getAllMedicationLogs();
  }

  async findLogsByMedicationId(medicationId: string): Promise<MedicationLog[]> {
    return await this.dbService.getMedicationLogsByMedicationId(medicationId);
  }

  async findLogsByDateRange(startDate: Date, endDate: Date): Promise<MedicationLog[]> {
    return await this.dbService.getMedicationLogsByDateRange(startDate, endDate);
  }

  async updateLog(log: MedicationLog): Promise<void> {
    await this.dbService.saveMedicationLog(log);
  }

  async deleteLog(id: string): Promise<void> {
    await this.dbService.deleteMedicationLog(id);
  }

  // Helper methods for common queries
  async getTodaysLogs(): Promise<MedicationLog[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return await this.findLogsByDateRange(today, tomorrow);
  }

  async getLogsForPeriod(days: number): Promise<MedicationLog[]> {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    return await this.findLogsByDateRange(startDate, endDate);
  }

  async getMissedDoses(date: Date = new Date()): Promise<{ medication: MedicationModel; scheduledTimes: Date[] }[]> {
    const activeMedications = await this.findActive();
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setDate(dayEnd.getDate() + 1);
    
    const dayLogs = await this.findLogsByDateRange(dayStart, dayEnd);
    
    const missedDoses: { medication: MedicationModel; scheduledTimes: Date[] }[] = [];
    
    for (const medication of activeMedications) {
      const medicationLogs = dayLogs.filter(log => log.medicationId === medication.id);
      const missedTimes: Date[] = [];
      
      for (const timeString of medication.times) {
        const [hours, minutes] = timeString.split(':').map(Number);
        const scheduledTime = new Date(dayStart);
        scheduledTime.setHours(hours, minutes, 0, 0);
        
        // Check if this scheduled time has been logged as taken
        const hasLog = medicationLogs.some(log => 
          Math.abs(log.scheduledTime.getTime() - scheduledTime.getTime()) < 60000 && // Within 1 minute
          log.status === 'taken'
        );
        
        if (!hasLog && scheduledTime < new Date()) {
          missedTimes.push(scheduledTime);
        }
      }
      
      if (missedTimes.length > 0) {
        missedDoses.push({ medication, scheduledTimes: missedTimes });
      }
    }
    
    return missedDoses;
  }

  async getUpcomingDoses(hours: number = 24): Promise<{ medication: MedicationModel; scheduledTime: Date }[]> {
    const activeMedications = await this.findActive();
    const now = new Date();
    const endTime = new Date(now.getTime() + (hours * 60 * 60 * 1000));
    
    const upcomingDoses: { medication: MedicationModel; scheduledTime: Date }[] = [];
    
    for (const medication of activeMedications) {
      for (const timeString of medication.times) {
        const [hours, minutes] = timeString.split(':').map(Number);
        
        // Check today
        const todayDose = new Date(now);
        todayDose.setHours(hours, minutes, 0, 0);
        
        if (todayDose > now && todayDose <= endTime) {
          upcomingDoses.push({ medication, scheduledTime: todayDose });
        }
        
        // Check tomorrow if within range
        const tomorrowDose = new Date(todayDose);
        tomorrowDose.setDate(tomorrowDose.getDate() + 1);
        
        if (tomorrowDose > now && tomorrowDose <= endTime) {
          upcomingDoses.push({ medication, scheduledTime: tomorrowDose });
        }
      }
    }
    
    // Sort by scheduled time
    return upcomingDoses.sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());
  }

  async isDoseTaken(medicationId: string, scheduledTime: Date): Promise<boolean> {
    const logs = await this.findLogsByMedicationId(medicationId);
    return logs.some(log => 
      Math.abs(log.scheduledTime.getTime() - scheduledTime.getTime()) < 60000 && // Within 1 minute
      log.status === 'taken'
    );
  }

  async logMedicationTaken(medicationId: string, scheduledTime: Date, userId: string, actualTime: Date = new Date(), notes?: string): Promise<MedicationLog> {
    const log: MedicationLog = {
      id: crypto.randomUUID(),
      userId,
      medicationId,
      scheduledTime,
      actualTime,
      status: 'taken',
      notes,
      createdAt: new Date()
    };
    
    await this.saveLog(log);
    return log;
  }

  async logMedicationMissed(medicationId: string, scheduledTime: Date, userId: string, notes?: string): Promise<MedicationLog> {
    const log: MedicationLog = {
      id: crypto.randomUUID(),
      userId,
      medicationId,
      scheduledTime,
      status: 'missed',
      notes,
      createdAt: new Date()
    };
    
    await this.saveLog(log);
    return log;
  }

  // Analytics and statistics
  async getAdherenceRate(medicationId?: string, days: number = 30): Promise<number> {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    let logs = await this.findLogsByDateRange(startDate, endDate);
    
    if (medicationId) {
      logs = logs.filter(log => log.medicationId === medicationId);
    }
    
    if (logs.length === 0) return 0;
    
    const takenCount = logs.filter(log => log.status === 'taken').length;
    return (takenCount / logs.length) * 100;
  }

  async getStreakCount(): Promise<number> {
    const allLogs = await this.findAllLogs();
    const takenLogs = allLogs
      .filter(log => log.status === 'taken' && log.actualTime)
      .sort((a, b) => b.actualTime!.getTime() - a.actualTime!.getTime());
    
    if (takenLogs.length === 0) return 0;
    
    let streak = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    
    // Check each day backwards
    for (let i = 0; i < 365; i++) { // Max 365 days
      const dayLogs = takenLogs.filter(log => {
        const logDate = new Date(log.actualTime!);
        logDate.setHours(0, 0, 0, 0);
        return logDate.getTime() === currentDate.getTime();
      });
      
      if (dayLogs.length > 0) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    return streak;
  }

  async getTotalMedicationsTaken(): Promise<number> {
    const logs = await this.findAllLogs();
    return logs.filter(log => log.status === 'taken').length;
  }
}