import React, { useState, useEffect } from 'react';
import { MedicationModel } from '@/models/Medication';
import { MedicationRepository } from '@/repositories/MedicationRepository';

interface DueMedicationsCardProps {
  medications: MedicationModel[];
  onMedicationTaken: (medicationId: string, scheduledTime: Date) => Promise<void>;
}

interface DueMedication {
  medication: MedicationModel;
  scheduledTime: Date;
  isOverdue: boolean;
}

export const DueMedicationsCard: React.FC<DueMedicationsCardProps> = ({
  medications,
  onMedicationTaken
}) => {
  const [dueMedications, setDueMedications] = useState<DueMedication[]>([]);
  const [takingMedication, setTakingMedication] = useState<string | null>(null);
  const medicationRepo = new MedicationRepository();

  useEffect(() => {
    updateDueMedications();
    const interval = setInterval(updateDueMedications, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [medications]);

  const updateDueMedications = async () => {
    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);
    
    const due: DueMedication[] = [];

    // Get today's logs to check what's already been taken
    const todayLogs = await medicationRepo.getTodaysLogs();

    for (const medication of medications.filter(med => med.isActive)) {
      for (const timeString of medication.times) {
        const [hours, minutes] = timeString.split(':').map(Number);
        const scheduledTime = new Date(todayStart);
        scheduledTime.setHours(hours, minutes, 0, 0);

        // Only show if the scheduled time is in the past or within 15 minutes
        const timeDiff = scheduledTime.getTime() - now.getTime();
        const minutesUntil = timeDiff / (1000 * 60);

        if (minutesUntil <= 15) {
          // Check if this dose has already been logged as taken
          const hasBeenTaken = todayLogs.some(log =>
            log.medicationId === medication.id &&
            Math.abs(log.scheduledTime.getTime() - scheduledTime.getTime()) < 60000 && // Within 1 minute
            log.status === 'taken'
          );

          if (!hasBeenTaken) {
            due.push({
              medication,
              scheduledTime,
              isOverdue: timeDiff < 0
            });
          }
        }
      }
    }

    // Sort by scheduled time
    due.sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());
    setDueMedications(due);
  };

  const handleTakeMedication = async (dueMed: DueMedication) => {
    const key = `${dueMed.medication.id}-${dueMed.scheduledTime.getTime()}`;
    setTakingMedication(key);

    try {
      await onMedicationTaken(dueMed.medication.id, dueMed.scheduledTime);
      // Remove from due list
      setDueMedications(prev => prev.filter(d => 
        !(d.medication.id === dueMed.medication.id && 
          d.scheduledTime.getTime() === dueMed.scheduledTime.getTime())
      ));
    } catch (error) {
      console.error('Failed to mark medication as taken:', error);
    } finally {
      setTakingMedication(null);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getTimeStatus = (scheduledTime: Date, isOverdue: boolean) => {
    const now = new Date();
    const timeDiff = scheduledTime.getTime() - now.getTime();
    const minutesDiff = Math.abs(timeDiff / (1000 * 60));

    if (isOverdue) {
      if (minutesDiff < 60) {
        return { text: `${Math.floor(minutesDiff)}m overdue`, color: 'text-red-600' };
      } else {
        const hours = Math.floor(minutesDiff / 60);
        return { text: `${hours}h overdue`, color: 'text-red-600' };
      }
    } else {
      return { text: `in ${Math.floor(minutesDiff)}m`, color: 'text-orange-600' };
    }
  };

  if (dueMedications.length === 0) {
    return (
      <div className="card bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <div className="text-center py-6">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">✅</span>
          </div>
          <h3 className="text-lg font-semibold text-green-800 mb-2">All caught up!</h3>
          <p className="text-green-600 text-sm">No medications due right now.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="card bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-blue-900">
          💊 Medications Due
        </h3>
        <div className="flex items-center space-x-2">
          <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
            {dueMedications.length} due
          </span>
        </div>
      </div>

      <div className="space-y-4">
        {dueMedications.map((dueMed) => {
          const key = `${dueMed.medication.id}-${dueMed.scheduledTime.getTime()}`;
          const isLoading = takingMedication === key;
          const timeStatus = getTimeStatus(dueMed.scheduledTime, dueMed.isOverdue);

          return (
            <div
              key={key}
              className={`p-4 rounded-xl border transition-all duration-200 ${
                dueMed.isOverdue
                  ? 'bg-red-50 border-red-200 shadow-md'
                  : 'bg-white border-blue-200 hover:shadow-md'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: dueMed.medication.color }}
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900">
                      {dueMed.medication.name}
                    </h4>
                    <div className="flex items-center space-x-3 text-sm">
                      <span className="text-gray-600">
                        {formatTime(dueMed.scheduledTime)}
                      </span>
                      <span className={timeStatus.color}>
                        {timeStatus.text}
                      </span>
                      {dueMed.medication.dosage && (
                        <span className="text-gray-500">
                          {dueMed.medication.dosage}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleTakeMedication(dueMed)}
                  disabled={isLoading}
                  className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                    dueMed.isOverdue
                      ? 'bg-red-100 hover:bg-red-200 text-red-700'
                      : 'bg-blue-100 hover:bg-blue-200 text-blue-700'
                  } disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95`}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                      <span>Taking...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <span>✅</span>
                      <span>Take Now</span>
                    </div>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {dueMedications.some(d => d.isOverdue) && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-xl">
          <div className="flex items-center space-x-2 text-sm">
            <span className="text-red-600">⚠️</span>
            <span className="text-red-700 font-medium">
              You have overdue medications. Take them as soon as possible.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};