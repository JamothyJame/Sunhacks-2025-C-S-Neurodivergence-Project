import React, { useEffect, useRef, useState } from 'react';
import { MedicationModel } from '@/models/Medication';
import { MedicationAutocomplete } from '@/components/MedicationAutocomplete';
import { DailyMedService } from '@/services/DailyMedService';
import { DrugSearchResult } from '@/types';
import { sanitizeMedicationName } from '@/utils/sanitization';
import { getDefaultMedicationColor } from '@/config/AppConfig';
import { InlineColorPicker } from '@/components/ColorPicker';

interface AddMedicationFormProps {
  userId: string;
  onSave: (medication: MedicationModel) => Promise<void>;
  onCancel: () => void;
}

export const AddMedicationForm: React.FC<AddMedicationFormProps> = ({ userId, onSave, onCancel }) => {
  const dailyMedService = new DailyMedService();
  const [formData, setFormData] = useState({
    name: '',
    genericName: '',
    dosage: '',
    frequency: 1,
    times: ['08:00'],
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    notes: '',
    color: getDefaultMedicationColor(),
    reminderEnabled: true,
    // Inventory fields
    currentSupply: '',
    refillsRemaining: '',
    pillsPerDose: '1'
  });

  const [isLoading, setIsLoading] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  // Accessibility: close on Escape and focus trap
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onCancel();
      }
      if (e.key === 'Tab' && dialogRef.current) {
        const focusable = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (!dialogRef.current.contains(document.activeElement)) {
          first.focus();
          e.preventDefault();
        } else {
          if (e.shiftKey && document.activeElement === first) {
            last.focus();
            e.preventDefault();
          } else if (!e.shiftKey && document.activeElement === last) {
            first.focus();
            e.preventDefault();
          }
        }
      }
    };
    document.addEventListener('keydown', onKeyDown, true);
    // Set initial focus
    setTimeout(() => {
      const el = dialogRef.current?.querySelector<HTMLElement>('input, button, [tabindex]');
      el?.focus();
    }, 0);
    return () => document.removeEventListener('keydown', onKeyDown, true);
  }, [onCancel]);
  const [error, setError] = useState('');
  const [selectedMedication, setSelectedMedication] = useState<DrugSearchResult | null>(null);


  const handleFrequencyChange = (frequency: number) => {
    const newTimes = Array(frequency).fill(null).map((_, index) => {
      const hour = 8 + (index * Math.floor(16 / frequency));
      return `${hour.toString().padStart(2, '0')}:00`;
    });
    
    setFormData({
      ...formData,
      frequency,
      times: newTimes
    });
  };

  const handleTimeChange = (index: number, time: string) => {
    const newTimes = [...formData.times];
    newTimes[index] = time;
    setFormData({
      ...formData,
      times: newTimes
    });
  };

  const handleMedicationNameChange = (name: string, medication?: DrugSearchResult) => {
    const sanitizedName = sanitizeMedicationName(name);
    setFormData({
      ...formData,
      name: sanitizedName
    });
    setSelectedMedication(medication || null);
  };

  const handleGenericNameChange = (genericName: string) => {
    const sanitizedGenericName = sanitizeMedicationName(genericName);
    setFormData({
      ...formData,
      genericName: sanitizedGenericName
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.name.trim()) {
      setError('Medication name is required');
      return;
    }

    if (formData.times.some(time => !time)) {
      setError('All dose times must be specified');
      return;
    }

    // Enhanced inventory validation
    if (formData.currentSupply && parseInt(formData.currentSupply) < 0) {
      setError('Current supply must be a positive number');
      return;
    }

    if (formData.refillsRemaining && parseInt(formData.refillsRemaining) < 0) {
      setError('Refills remaining must be a positive number');
      return;
    }

    if (formData.pillsPerDose && parseInt(formData.pillsPerDose) <= 0) {
      setError('Pills per dose must be a positive number');
      return;
    }

    // Validate supply calculation makes sense
    if (formData.currentSupply && formData.pillsPerDose) {
      const supply = parseInt(formData.currentSupply);
      const pillsPerDose = parseInt(formData.pillsPerDose);
      const frequency = formData.frequency;
      const pillsPerDay = frequency * pillsPerDose;
      
      if (supply > 0 && pillsPerDay > supply && supply < pillsPerDose) {
        setError('Current supply is less than one dose. Please check your numbers.');
        return;
      }
    }

    setIsLoading(true);
    try {
      // Use the selected medication name if available, otherwise use the form input
      const medicationName = selectedMedication 
        ? dailyMedService.getMedicationName(selectedMedication)
        : formData.name.trim();
      
      const medication = MedicationModel.create({
        userId,
        name: medicationName,
        genericName: formData.genericName.trim() || undefined,
        dosage: formData.dosage.trim() || undefined,
        frequency: formData.frequency,
        times: formData.times,
        startDate: new Date(formData.startDate),
        endDate: formData.endDate ? new Date(formData.endDate) : undefined,
        notes: formData.notes.trim() || undefined,
        color: formData.color,
        isActive: true,
        reminderEnabled: formData.reminderEnabled,
        // Include inventory fields if provided
        currentSupply: formData.currentSupply ? parseInt(formData.currentSupply) : undefined,
        refillsRemaining: formData.refillsRemaining ? parseInt(formData.refillsRemaining) : undefined,
        pillsPerDose: formData.pillsPerDose ? parseInt(formData.pillsPerDose) : 1,
        supplyLastUpdated: formData.currentSupply ? new Date() : undefined
      });

      await onSave(medication);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save medication');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" role="presentation" aria-hidden={false}>
      <div
        ref={dialogRef}
        className="card-elevated max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-medication-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 id="add-medication-title" className="text-2xl font-bold text-gray-900">Add New Medication</h2>
            <p className="text-gray-600 mt-1">Set up tracking for your medication</p>
          </div>
          <button
            onClick={onCancel}
            aria-label="Close add medication"
            className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center transition-colors"
          >
            <span className="text-gray-600 text-xl">×</span>
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-xl mb-6">
            <div className="flex items-center space-x-2">
              <span className="text-lg">⚠️</span>
              <span className="font-medium">{error}</span>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                💊 Medication Name *
              </label>
              <MedicationAutocomplete
                value={formData.name}
                onChange={handleMedicationNameChange}
                onGenericNameChange={handleGenericNameChange}
                placeholder="Start typing medication name... (e.g., Lisinopril)"
                required
                className="input-field"
              />
              {selectedMedication && (
                <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-green-600">✅</span>
                    <span className="text-sm font-medium text-green-800">Medication verified by DailyMed</span>
                  </div>
                  {selectedMedication.pharm_classes.length > 0 && (
                    <div className="text-xs text-green-700">
                      <strong>Drug class:</strong> {selectedMedication.pharm_classes[0]}
                    </div>
                  )}
                  {selectedMedication.brand_name.length > 0 && selectedMedication.generic_medicine.length > 0 && (
                    <div className="text-xs text-green-700 mt-1">
                      <strong>Also known as:</strong> {selectedMedication.brand_name.join(', ')}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3" id="generic-name-label">
                🏷️ Generic Name <span className="text-gray-400 font-normal">(Optional)</span>
              </label>
              <input
                aria-labelledby="generic-name-label"
                type="text"
                value={formData.genericName}
                onChange={(e) => setFormData({ ...formData, genericName: e.target.value })}
                className="input-field"
                placeholder="e.g., ACE inhibitor"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                📏 Dosage <span className="text-gray-400 font-normal">(Optional)</span>
              </label>
              <input
                type="text"
                value={formData.dosage}
                onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                className="input-field"
                placeholder="e.g., 10mg, 2 tablets"
              />
            </div>

            <div>
              <InlineColorPicker
                value={formData.color}
                onChange={(color) => setFormData({ ...formData, color })}
                label="Color"
              />
            </div>
          </div>

          {/* Schedule */}
          <div className="border border-gray-200 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">⏰ Dosing Schedule</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                How many times per day?
              </label>
              <div className="flex space-x-2">
                {[1, 2, 3, 4].map((freq) => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => handleFrequencyChange(freq)}
                    className={`px-4 py-2 rounded-xl font-medium transition-all ${
                      formData.frequency === freq
                        ? 'bg-primary-100 text-primary-700 shadow-sm'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {freq}x daily
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {formData.times.map((time, index) => (
                <div key={index}>
                  <label className="block text-sm font-medium text-gray-600 mb-2" id={`dose-time-label-${index}`}>
                    Dose {index + 1}
                  </label>
                  <input
                    type="time"
                    aria-labelledby={`dose-time-label-${index}`}
                    value={time}
                    onChange={(e) => handleTimeChange(index, e.target.value)}
                    className="input-field"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                📅 Start Date *
              </label>
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                🏁 End Date <span className="text-gray-400 font-normal">(Optional)</span>
              </label>
              <input
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="input-field"
                min={formData.startDate}
              />
              <p className="text-xs text-gray-500 mt-1">
                Leave empty for ongoing medication
              </p>
            </div>
          </div>

          {/* Inventory Tracking */}
          <div className="border border-gray-200 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">💊 Inventory Tracking <span className="text-gray-400 font-normal text-sm">(Optional)</span></h3>
            <p className="text-sm text-gray-600 mb-4">
              Track your medication supply to get refill reminders and avoid running out.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Current Supply
                </label>
                <input
                  type="number"
                  value={formData.currentSupply}
                  onChange={(e) => setFormData({ ...formData, currentSupply: e.target.value })}
                  className="input-field"
                  placeholder="e.g., 30"
                  min="0"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Number of pills you currently have
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Refills Remaining
                </label>
                <input
                  type="number"
                  value={formData.refillsRemaining}
                  onChange={(e) => setFormData({ ...formData, refillsRemaining: e.target.value })}
                  className="input-field"
                  placeholder="e.g., 5"
                  min="0"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Refills left on prescription
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Pills per Dose
                </label>
                <input
                  type="number"
                  value={formData.pillsPerDose}
                  onChange={(e) => setFormData({ ...formData, pillsPerDose: e.target.value })}
                  className="input-field"
                  placeholder="1"
                  min="1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Number of pills taken per dose
                </p>
              </div>
            </div>
            
            {formData.currentSupply && (
              <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-blue-600">ℹ️</span>
                  <span className="text-sm font-medium text-blue-800">Supply Estimate</span>
                </div>
                <div className="text-sm text-blue-700">
                  {(() => {
                    const supply = parseInt(formData.currentSupply);
                    const pillsPerDose = parseInt(formData.pillsPerDose) || 1;
                    const frequency = formData.frequency;
                    const pillsPerDay = frequency * pillsPerDose;
                    const daysRemaining = Math.floor(supply / pillsPerDay);
                    
                    if (daysRemaining > 0) {
                      return `With your current supply, you have approximately ${daysRemaining} days of medication remaining.`;
                    } else {
                      return 'Please check your supply numbers - this doesn\'t provide enough for even one day.';
                    }
                  })()
                  }
                </div>
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              📝 Notes <span className="text-gray-400 font-normal">(Optional)</span>
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              className="input-field"
              placeholder="Additional information, instructions, or reminders..."
            />
          </div>

          {/* Reminder Toggle */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <h4 className="font-semibold text-gray-800">🔔 Enable Reminders</h4>
              <p className="text-sm text-gray-600">Get notified when it's time to take your medication</p>
            </div>
            <button
              type="button"
              onClick={() => setFormData({ ...formData, reminderEnabled: !formData.reminderEnabled })}
              className={`w-12 h-6 rounded-full transition-colors ${
                formData.reminderEnabled
                  ? 'bg-primary-500'
                  : 'bg-gray-300'
              }`}
            >
              <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                formData.reminderEnabled ? 'translate-x-6' : 'translate-x-0.5'
              }`} />
            </button>
          </div>

          {/* Actions */}
          <div className="flex space-x-4 pt-6">
            <button
              type="submit"
              disabled={isLoading}
              aria-busy={isLoading}
              aria-label={isLoading ? 'Saving medication' : 'Add medication'}
              className="flex-1 btn btn-primary py-3 text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <span className="flex items-center justify-center space-x-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Saving...</span>
                </span>
              ) : (
                <span className="flex items-center justify-center space-x-2">
                  <span>✨</span>
                  <span>Add Medication</span>
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={onCancel}
              aria-label="Cancel add medication"
              className="px-6 py-3 btn-secondary font-bold"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};