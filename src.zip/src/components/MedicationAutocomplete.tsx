import React, { useState, useEffect, useRef } from 'react';
import { DailyMedService } from '@/services/DailyMedService';
import { DrugSearchResult } from '@/types';

interface MedicationAutocompleteProps {
  value: string;
  onChange: (value: string, selectedMedication?: DrugSearchResult) => void;
  onGenericNameChange?: (genericName: string) => void;
  placeholder?: string;
  required?: boolean;
  className?: string;
}

export const MedicationAutocomplete: React.FC<MedicationAutocompleteProps> = ({
  value,
  onChange,
  onGenericNameChange,
  placeholder = "Start typing medication name...",
  required = false,
  className = "input-field"
}) => {
  const [suggestions, setSuggestions] = useState<DrugSearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [localValue, setLocalValue] = useState(value);
  const [hasSelectedMedication, setHasSelectedMedication] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const dailyMedService = new DailyMedService();

  // Sync local value with prop value
  useEffect(() => {
    setLocalValue(value);
    // Reset selection flag if value is cleared from parent
    if (value === '') {
      setHasSelectedMedication(false);
    }
  }, [value]);

  useEffect(() => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    if (localValue.length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      setIsLoading(false);
      return;
    }

    // Don't search if a medication has been selected and user isn't actively changing it
    if (hasSelectedMedication) {
      return;
    }

    setIsLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const results = await dailyMedService.searchDrugs(localValue, 8);
        setSuggestions(results);
        setShowSuggestions(true);
        setHighlightedIndex(-1);
      } catch (error) {
        console.error('Error fetching medication suggestions:', error);
        setSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    }, 300);

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [localValue, hasSelectedMedication]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setLocalValue(newValue);
    
    // Reset selection flag when user starts typing again
    if (hasSelectedMedication) {
      setHasSelectedMedication(false);
    }
    
    onChange(newValue);
  };

  const handleSelectSuggestion = (suggestion: DrugSearchResult) => {
    // Use the primary medication name (brand or generic) for the input field
    const medicationName = dailyMedService.getMedicationName(suggestion);
    
    // Update local value immediately
    setLocalValue(medicationName);
    
    // Mark that a medication has been selected
    setHasSelectedMedication(true);
    
    // Update the parent component's state with the selected medication name
    onChange(medicationName, suggestion);
    
    // Auto-populate generic name if available
    if (suggestion.generic_medicine.length > 0 && onGenericNameChange) {
      onGenericNameChange(suggestion.generic_medicine[0]);
    }
    
    // Hide suggestions and blur input
    setShowSuggestions(false);
    setHighlightedIndex(-1);
    
    // Blur input after state update
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.blur();
      }
    }, 10);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSuggestions || suggestions.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : 0
        );
        break;
      
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev > 0 ? prev - 1 : suggestions.length - 1
        );
        break;
      
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
          handleSelectSuggestion(suggestions[highlightedIndex]);
        }
        break;
      
      case 'Escape':
        setShowSuggestions(false);
        setHighlightedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  const handleBlur = () => {
    // Delay hiding suggestions to allow clicks
    setTimeout(() => {
      setShowSuggestions(false);
      setHighlightedIndex(-1);
    }, 150);
  };

  const handleFocus = () => {
    // Don't show suggestions if a medication has already been selected
    if (!hasSelectedMedication && suggestions.length > 0 && localValue.length >= 2) {
      setShowSuggestions(true);
    }
  };

  // Scroll highlighted item into view
  useEffect(() => {
    if (highlightedIndex >= 0 && suggestionRefs.current[highlightedIndex]) {
      suggestionRefs.current[highlightedIndex]?.scrollIntoView({
        block: 'nearest',
        behavior: 'smooth'
      });
    }
  }, [highlightedIndex]);

  return (
    <div className="relative">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={localValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          onFocus={handleFocus}
          className={`${className} pr-10`}
          placeholder={placeholder}
          required={required}
          autoComplete="off"
        />
        
        {/* Loading indicator */}
        {isLoading && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="w-4 h-4 border-2 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
        
        {/* Search icon when not loading */}
        {!isLoading && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            <span className="text-lg">🔍</span>
          </div>
        )}
      </div>

      {/* Suggestions dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto">
          {suggestions.map((suggestion, index) => (
            <div
              key={suggestion.setid}
              ref={el => { suggestionRefs.current[index] = el; }}
              onClick={() => handleSelectSuggestion(suggestion)}
              className={`px-4 py-3 cursor-pointer transition-colors border-b border-gray-100 last:border-b-0 ${
                index === highlightedIndex
                  ? 'bg-primary-50 text-primary-900'
                  : 'hover:bg-gray-50'
              }`}
            >
              <div className="font-medium text-gray-900">
                {dailyMedService.getMedicationName(suggestion)}
              </div>
              
              {/* Show additional information */}
              <div className="flex items-center space-x-2 mt-1 text-sm text-gray-600">
                {suggestion.generic_medicine.length > 0 && 
                 suggestion.generic_medicine[0] !== dailyMedService.getMedicationName(suggestion) && (
                  <span className="bg-gray-100 px-2 py-1 rounded text-xs">
                    Generic: {suggestion.generic_medicine[0]}
                  </span>
                )}
                
                {suggestion.brand_name.length > 0 && 
                 suggestion.brand_name[0] !== dailyMedService.getMedicationName(suggestion) && (
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                    Brand: {suggestion.brand_name[0]}
                  </span>
                )}
              </div>

              {/* Show pharmaceutical classes if available */}
              {suggestion.pharm_classes.length > 0 && (
                <div className="mt-1 text-xs text-gray-500 truncate">
                  {suggestion.pharm_classes.slice(0, 2).join(', ')}
                  {suggestion.pharm_classes.length > 2 && '...'}
                </div>
              )}
            </div>
          ))}
          
          {/* Powered by OpenFDA footer */}
          <div className="px-4 py-2 bg-gray-50 text-xs text-gray-500 text-center border-t border-gray-200">
            <span className="flex items-center justify-center space-x-1">
              <span>Powered by</span>
              <span className="font-medium">OpenFDA</span>
              <span className="text-blue-600">💊</span>
            </span>
          </div>
        </div>
      )}

      {/* No results message */}
      {showSuggestions && suggestions.length === 0 && !isLoading && localValue.length >= 2 && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg">
          <div className="px-4 py-3 text-gray-500 text-center">
            <div className="text-2xl mb-2">💊</div>
            <div className="text-sm">No medications found for "{localValue}"</div>
            <div className="text-xs mt-1 text-gray-400">Try a different spelling or search term</div>
          </div>
        </div>
      )}
    </div>
  );
};