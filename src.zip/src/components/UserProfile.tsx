import React, { useState } from 'react';
import { UserModel, UserProfileModel } from '@/models/UserModel';

interface UserProfileProps {
  user: UserModel;
  profile: UserProfileModel;
  onUpdateProfile: (updates: Partial<Parameters<UserProfileModel['update']>[0]>) => Promise<void>;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user, profile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    bio: profile.bio || '',
    emergencyContact: {
      name: profile.emergencyContact?.name || '',
      phone: profile.emergencyContact?.phone || '',
      relationship: profile.emergencyContact?.relationship || ''
    },
    medicalInfo: {
      allergies: profile.medicalInfo?.allergies || [],
      conditions: profile.medicalInfo?.conditions || [],
      primaryPhysician: {
        name: profile.medicalInfo?.primaryPhysician?.name || '',
        phone: profile.medicalInfo?.primaryPhysician?.phone || '',
        email: profile.medicalInfo?.primaryPhysician?.email || ''
      }
    }
  });
  const [newAllergy, setNewAllergy] = useState('');
  const [newCondition, setNewCondition] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onUpdateProfile({
        bio: formData.bio || undefined,
        emergencyContact: formData.emergencyContact.name ? formData.emergencyContact : undefined,
        medicalInfo: {
          allergies: formData.medicalInfo.allergies,
          conditions: formData.medicalInfo.conditions,
          primaryPhysician: formData.medicalInfo.primaryPhysician.name ? formData.medicalInfo.primaryPhysician : undefined
        }
      });
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  const addAllergy = () => {
    if (newAllergy.trim()) {
      setFormData({
        ...formData,
        medicalInfo: {
          ...formData.medicalInfo,
          allergies: [...formData.medicalInfo.allergies, newAllergy.trim()]
        }
      });
      setNewAllergy('');
    }
  };

  const removeAllergy = (index: number) => {
    setFormData({
      ...formData,
      medicalInfo: {
        ...formData.medicalInfo,
        allergies: formData.medicalInfo.allergies.filter((_, i) => i !== index)
      }
    });
  };

  const addCondition = () => {
    if (newCondition.trim()) {
      setFormData({
        ...formData,
        medicalInfo: {
          ...formData.medicalInfo,
          conditions: [...formData.medicalInfo.conditions, newCondition.trim()]
        }
      });
      setNewCondition('');
    }
  };

  const removeCondition = (index: number) => {
    setFormData({
      ...formData,
      medicalInfo: {
        ...formData.medicalInfo,
        conditions: formData.medicalInfo.conditions.filter((_, i) => i !== index)
      }
    });
  };

  return (
    <div className="card max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold text-primary-600">{user.initials}</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{user.fullName}</h1>
            <p className="text-gray-600">{user.email}</p>
            {user.age && <p className="text-gray-500">Age: {user.age}</p>}
          </div>
        </div>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="btn btn-primary"
        >
          {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      {!isEditing ? (
        <div className="space-y-6">
          {/* Profile Completion */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-800">Profile Completion</h3>
              <span className="text-sm text-gray-600">{profile.getCompletionPercentage()}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${profile.getCompletionPercentage()}%` }}
              ></div>
            </div>
          </div>

          {/* Bio */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">About</h3>
            <p className="text-gray-600">
              {profile.bio || 'No bio provided yet. Click "Edit Profile" to add one.'}
            </p>
          </div>

          {/* Emergency Contact */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Emergency Contact</h3>
            {profile.hasEmergencyContact() ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="font-medium text-red-800">{profile.emergencyContact?.name}</p>
                <p className="text-red-600">{profile.emergencyContact?.phone}</p>
                <p className="text-red-600 capitalize">{profile.emergencyContact?.relationship}</p>
              </div>
            ) : (
              <p className="text-gray-500">No emergency contact set. Consider adding one for safety.</p>
            )}
          </div>

          {/* Medical Information */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Medical Information</h3>
            
            {/* Allergies */}
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">Allergies</h4>
              {profile.hasAllergies() ? (
                <div className="flex flex-wrap gap-2">
                  {profile.medicalInfo?.allergies.map((allergy, index) => (
                    <span key={index} className="bg-warning-100 text-warning-800 px-3 py-1 rounded-full text-sm">
                      {allergy}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No allergies recorded.</p>
              )}
            </div>

            {/* Conditions */}
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">Medical Conditions</h4>
              {profile.hasConditions() ? (
                <div className="flex flex-wrap gap-2">
                  {profile.medicalInfo?.conditions.map((condition, index) => (
                    <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      {condition}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No medical conditions recorded.</p>
              )}
            </div>

            {/* Primary Physician */}
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Primary Physician</h4>
              {profile.hasPrimaryPhysician() ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="font-medium text-green-800">{profile.medicalInfo?.primaryPhysician?.name}</p>
                  <p className="text-green-600">{profile.medicalInfo?.primaryPhysician?.phone}</p>
                  {profile.medicalInfo?.primaryPhysician?.email && (
                    <p className="text-green-600">{profile.medicalInfo?.primaryPhysician?.email}</p>
                  )}
                </div>
              ) : (
                <p className="text-gray-500">No primary physician recorded.</p>
              )}
            </div>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Bio */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
            <textarea
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Tell us about yourself..."
            />
          </div>

          {/* Emergency Contact */}
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Emergency Contact</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                <input
                  type="text"
                  value={formData.emergencyContact.name}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: { ...formData.emergencyContact, name: e.target.value }
                  })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                <input
                  type="tel"
                  value={formData.emergencyContact.phone}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: { ...formData.emergencyContact, phone: e.target.value }
                  })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Relationship</label>
                <input
                  type="text"
                  value={formData.emergencyContact.relationship}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: { ...formData.emergencyContact, relationship: e.target.value }
                  })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="e.g., spouse, parent, friend"
                />
              </div>
            </div>
          </div>

          {/* Medical Information */}
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Medical Information</h3>
            
            {/* Allergies */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Allergies</label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={newAllergy}
                  onChange={(e) => setNewAllergy(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Add an allergy..."
                />
                <button
                  type="button"
                  onClick={addAllergy}
                  className="px-4 py-2 bg-warning-500 text-white rounded-lg hover:bg-warning-600"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.medicalInfo.allergies.map((allergy, index) => (
                  <span key={index} className="bg-warning-100 text-warning-800 px-3 py-1 rounded-full text-sm flex items-center gap-2">
                    {allergy}
                    <button
                      type="button"
                      onClick={() => removeAllergy(index)}
                      className="text-warning-600 hover:text-warning-800"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Conditions */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Medical Conditions</label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={newCondition}
                  onChange={(e) => setNewCondition(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Add a medical condition..."
                />
                <button
                  type="button"
                  onClick={addCondition}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.medicalInfo.conditions.map((condition, index) => (
                  <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center gap-2">
                    {condition}
                    <button
                      type="button"
                      onClick={() => removeCondition(index)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Primary Physician */}
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Primary Physician</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input
                    type="text"
                    value={formData.medicalInfo.primaryPhysician.name}
                    onChange={(e) => setFormData({
                      ...formData,
                      medicalInfo: {
                        ...formData.medicalInfo,
                        primaryPhysician: {
                          ...formData.medicalInfo.primaryPhysician,
                          name: e.target.value
                        }
                      }
                    })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                  <input
                    type="tel"
                    value={formData.medicalInfo.primaryPhysician.phone}
                    onChange={(e) => setFormData({
                      ...formData,
                      medicalInfo: {
                        ...formData.medicalInfo,
                        primaryPhysician: {
                          ...formData.medicalInfo.primaryPhysician,
                          phone: e.target.value
                        }
                      }
                    })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.medicalInfo.primaryPhysician.email}
                    onChange={(e) => setFormData({
                      ...formData,
                      medicalInfo: {
                        ...formData.medicalInfo,
                        primaryPhysician: {
                          ...formData.medicalInfo.primaryPhysician,
                          email: e.target.value
                        }
                      }
                    })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="btn btn-primary"
            >
              Save Changes
            </button>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="btn bg-gray-300 text-gray-700 hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
};