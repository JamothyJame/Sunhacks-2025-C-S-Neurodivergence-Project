import React from 'react';
import { MedicationModel } from '@/models/Medication';
import { ChatButton } from '@/components/Chat';

interface MedicationCardProps {
  medication: MedicationModel;
  onToggleActive?: (medicationId: string) => void;
  onToggleReminder?: (medicationId: string) => void;
  onEdit?: (medicationId: string) => void;
  onDelete?: (medicationId: string) => void;
}

export const MedicationCard: React.FC<MedicationCardProps> = ({
  medication,
  onToggleActive,
  onToggleReminder,
  onEdit,
  onDelete
}) => {
  const nextDose = medication.getNextDoseTime();
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getTimeUntilNextDose = (nextDoseTime: Date) => {
    const now = new Date();
    const diff = nextDoseTime.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `in ${hours}h ${minutes}m`;
    } else if (minutes > 0) {
      return `in ${minutes}m`;
    } else {
      return 'now';
    }
  };

  return (
    <div className={`card hover:shadow-lg transition-all duration-200 ${
      !medication.isActive ? 'opacity-60 bg-gray-50' : ''
    }`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div 
            className="w-4 h-4 rounded-full flex-shrink-0"
            style={{ backgroundColor: medication.color }}
          />
          <div>
            <h3 className="font-semibold text-gray-900 text-lg">{medication.name}</h3>
            {medication.genericName && (
              <p className="text-sm text-gray-500">{medication.genericName}</p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {/* Chat Button */}
          <ChatButton 
            medication={medication.rawData} 
            variant="icon"
          />
          
          {/* Reminder Toggle */}
          <button
            onClick={() => onToggleReminder?.(medication.id)}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
              medication.reminderEnabled
                ? 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
            }`}
            title={medication.reminderEnabled ? 'Reminders enabled' : 'Reminders disabled'}
          >
            <span className="text-sm">🔔</span>
          </button>
          
          {/* More Actions */}
          <div className="relative group">
            <button className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors">
              <span className="text-gray-600 text-lg">⋯</span>
            </button>
            <div className="absolute right-0 top-full mt-1 bg-white shadow-lg border border-gray-200 rounded-xl py-2 min-w-[150px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10">
              <button
                onClick={() => onEdit?.(medication.id)}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center space-x-2"
              >
                <span>✏️</span>
                <span>Edit</span>
              </button>
              <button
                onClick={() => onToggleActive?.(medication.id)}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center space-x-2"
              >
                <span>{medication.isActive ? '⏸️' : '▶️'}</span>
                <span>{medication.isActive ? 'Pause' : 'Resume'}</span>
              </button>
              <hr className="my-1 border-gray-200" />
              <button
                onClick={() => onDelete?.(medication.id)}
                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-2"
              >
                <span>🗑️</span>
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {/* Dosage */}
        {medication.dosage && (
          <div className="flex items-center space-x-2 text-sm">
            <span className="text-gray-500">Dosage:</span>
            <span className="font-medium text-gray-700">{medication.dosage}</span>
          </div>
        )}

        {/* Schedule */}
        <div>
          <div className="flex items-center space-x-2 text-sm mb-2">
            <span className="text-gray-500">Schedule:</span>
            <span className="font-medium text-gray-700">
              {medication.frequency}x daily
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {medication.times.map((time, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2 py-1 rounded-lg text-xs font-medium bg-gray-100 text-gray-700"
              >
                {new Date(`2000-01-01T${time}`).toLocaleTimeString('en-US', {
                  hour: 'numeric',
                  minute: '2-digit',
                  hour12: true
                })}
              </span>
            ))}
          </div>
        </div>

        {/* Inventory Status */}
        {medication.currentSupply !== undefined && (() => {
          const supplyStatus = medication.getSupplyStatus();
          const getStatusColor = (status: string) => {
            switch (status) {
              case 'out': return 'bg-red-100 text-red-800 border-red-200';
              case 'critical': return 'bg-orange-100 text-orange-800 border-orange-200';
              case 'low': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
              case 'adequate': return 'bg-green-100 text-green-800 border-green-200';
              default: return 'bg-gray-100 text-gray-600 border-gray-200';
            }
          };
          
          return (
            <div className={`p-3 rounded-lg border ${
              getStatusColor(supplyStatus.status)
            }`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">
                    {supplyStatus.status === 'out' ? '🚨' : 
                     supplyStatus.status === 'critical' ? '⚠️' : 
                     supplyStatus.status === 'low' ? '📊' : '✅'} 
                    Supply
                  </span>
                  <span className="text-xs font-medium">
                    {medication.currentSupply} {medication.currentSupply === 1 ? 'pill' : 'pills'}
                  </span>
                </div>
                {medication.refillsRemaining !== undefined && (
                  <span className="text-xs">
                    {medication.refillsRemaining} {medication.refillsRemaining === 1 ? 'refill' : 'refills'} left
                  </span>
                )}
              </div>
              
              <div className="text-sm">
                {supplyStatus.message}
              </div>
              
              {(supplyStatus.status === 'critical' || supplyStatus.status === 'low') && (
                <div className="mt-2 pt-2 border-t border-current border-opacity-20">
                  <div className="text-xs font-medium">
                    {medication.needsNewPrescriptionReminder() 
                      ? '🩺 Contact doctor for new prescription'
                      : '💊 Time to refill prescription'
                    }
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* Next Dose */}
        {medication.isActive && nextDose && (
          <div className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
            <div>
              <div className="text-sm font-medium text-blue-900">Next dose</div>
              <div className="text-lg font-bold text-blue-700">{formatTime(nextDose)}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-blue-600">{getTimeUntilNextDose(nextDose)}</div>
            </div>
          </div>
        )}

        {/* Notes */}
        {medication.notes && (
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 font-medium mb-1">Notes:</div>
            <div className="text-sm text-gray-700">{medication.notes}</div>
          </div>
        )}

        {/* Status */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center space-x-2">
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
              medication.isActive
                ? 'bg-green-100 text-green-800'
                : 'bg-gray-100 text-gray-600'
            }`}>
              {medication.isActive ? '✅ Active' : '⏸️ Paused'}
            </span>
          </div>
          <div className="text-xs text-gray-500">
            Started {medication.startDate.toLocaleDateString()}
          </div>
        </div>
      </div>
    </div>
  );
};