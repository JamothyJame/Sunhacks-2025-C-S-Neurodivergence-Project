import React, { useState, useRef } from 'react';
import { ColorOption, getMedicationColors, addCustomMedicationColor, getColorName } from '@/config/AppConfig';

interface ColorPickerProps {
  value: string;
  onChange: (color: string) => void;
  label?: string;
  showCustomPicker?: boolean;
  allowCustomColors?: boolean;
  className?: string;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({
  value,
  onChange,
  label = "Color",
  showCustomPicker = true,
  allowCustomColors = true,
  className = ""
}) => {
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customColorInput, setCustomColorInput] = useState('#');
  const colorInputRef = useRef<HTMLInputElement>(null);
  
  const colorOptions = getMedicationColors();
  const selectedColorName = getColorName(value);

  const handlePresetColorClick = (colorValue: string) => {
    onChange(colorValue);
  };

  const handleCustomColorSubmit = () => {
    const color = customColorInput.trim();
    
    // Validate hex color format
    const hexColorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    if (!hexColorRegex.test(color)) {
      alert('Please enter a valid hex color (e.g., #FF6B6B)');
      return;
    }

    // Add to custom colors if not already exists
    if (allowCustomColors) {
      const colorName = `Custom ${color.toUpperCase()}`;
      addCustomMedicationColor({
        name: colorName,
        value: color,
        category: 'custom'
      });
    }

    onChange(color);
    setCustomColorInput('#');
    setShowCustomInput(false);
  };

  const handleHtmlColorInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    const color = event.target.value;
    onChange(color);
    
    // Add to custom colors if it's a new color
    if (allowCustomColors && !colorOptions.find(c => c.value === color)) {
      const colorName = `Custom ${color.toUpperCase()}`;
      addCustomMedicationColor({
        name: colorName,
        value: color,
        category: 'custom'
      });
    }
  };

  const groupedColors = colorOptions.reduce((groups, color) => {
    const category = color.category || 'other';
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(color);
    return groups;
  }, {} as Record<string, ColorOption[]>);

  const categoryOrder = ['blue', 'green', 'purple', 'red', 'orange', 'pink', 'gray', 'custom', 'other'];
  const sortedCategories = categoryOrder.filter(cat => groupedColors[cat]);
  const remainingCategories = Object.keys(groupedColors).filter(cat => !categoryOrder.includes(cat));
  const allCategories = [...sortedCategories, ...remainingCategories];

  return (
    <div className={`space-y-3 ${className}`}>
      <label className="block text-sm font-semibold text-gray-700">
        🎨 {label}
      </label>
      
      {/* Selected Color Display */}
      <div className="flex items-center space-x-3 mb-4">
        <div 
          className="w-8 h-8 rounded-xl border-2 border-gray-200 shadow-sm"
          style={{ backgroundColor: value }}
          title={selectedColorName}
        />
        <span className="text-sm text-gray-600">
          {selectedColorName} <span className="text-gray-400">({value})</span>
        </span>
      </div>

      {/* Color Categories */}
      {allCategories.map(category => (
        <div key={category} className="space-y-2">
          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wide">
            {category === 'other' ? 'Other' : category}
          </h4>
          <div className="flex flex-wrap gap-2">
            {groupedColors[category].map((color) => (
              <button
                key={color.value}
                type="button"
                onClick={() => handlePresetColorClick(color.value)}
                className={`w-8 h-8 rounded-xl transition-all hover:scale-110 ${
                  value === color.value
                    ? 'ring-2 ring-offset-2 ring-gray-400 scale-110'
                    : 'hover:ring-1 hover:ring-gray-300'
                }`}
                style={{ backgroundColor: color.value }}
                title={color.name}
                aria-label={`Select ${color.name} color`}
              />
            ))}
          </div>
        </div>
      ))}

      {/* Custom Color Section */}
      {(showCustomPicker || allowCustomColors) && (
        <div className="border-t border-gray-200 pt-4 space-y-3">
          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wide">
            Custom Colors
          </h4>
          
          <div className="flex items-center space-x-3">
            {/* HTML Color Input */}
            {showCustomPicker && (
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={value}
                  onChange={handleHtmlColorInput}
                  className="w-10 h-10 rounded-lg border border-gray-300 cursor-pointer"
                  title="Pick custom color"
                />
                <span className="text-sm text-gray-600">Color picker</span>
              </div>
            )}
          </div>

          {/* Text Input for Hex Colors */}
          {allowCustomColors && (
            <div className="space-y-2">
              {!showCustomInput ? (
                <button
                  type="button"
                  onClick={() => setShowCustomInput(true)}
                  className="text-sm text-primary-600 hover:text-primary-700 font-medium"
                >
                  + Add hex color
                </button>
              ) : (
                <div className="flex items-center space-x-2">
                  <input
                    ref={colorInputRef}
                    type="text"
                    value={customColorInput}
                    onChange={(e) => setCustomColorInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleCustomColorSubmit();
                      } else if (e.key === 'Escape') {
                        setShowCustomInput(false);
                        setCustomColorInput('#');
                      }
                    }}
                    placeholder="#FF6B6B"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                  <button
                    type="button"
                    onClick={handleCustomColorSubmit}
                    className="px-3 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition-colors"
                  >
                    Add
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCustomInput(false);
                      setCustomColorInput('#');
                    }}
                    className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-300 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Usage Hint */}
          <p className="text-xs text-gray-500">
            💡 Tip: Custom colors are saved and can be reused for other medications
          </p>
        </div>
      )}
    </div>
  );
};

// Simplified version for inline use
export const InlineColorPicker: React.FC<Omit<ColorPickerProps, 'showCustomPicker' | 'allowCustomColors'>> = (props) => {
  return (
    <ColorPicker 
      {...props} 
      showCustomPicker={false} 
      allowCustomColors={false}
      className="space-y-2"
    />
  );
};