import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { LoadingOverlay, Skeleton } from '@/components/LoadingStates';
import { ChatMessage as ChatMessageType, MedicationConversation, ChatState } from '@/types/chat';
import { Medication } from '@/types';
import ChatService from '@/services/ChatService';
import { UserService } from '@/services/UserService';

interface ChatContainerProps {
  medication: Medication;
  onClose?: () => void;
  className?: string;
  maxHeight?: string;
}

export const ChatContainer: React.FC<ChatContainerProps> = ({
  medication,
  onClose,
  className = '',
  maxHeight = '600px'
}) => {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [conversation, setConversation] = useState<MedicationConversation | null>(null);
  const [chatState, setChatState] = useState<ChatState>({
    isLoading: false,
    error: null,
    isTyping: false,
    connectionStatus: 'connected'
  });
  const [isInitializing, setIsInitializing] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatService = ChatService.getInstance();
  const userService = UserService.getInstance();

  // Scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, chatState.isTyping]);

  // Initialize conversation and load history
  useEffect(() => {
    const initializeChat = async () => {
      try {
        setIsInitializing(true);
        const currentUser = await userService.getCurrentUser();
        
        if (!currentUser) {
          throw new Error('No user logged in');
        }

        // Get or create conversation
        const conv = await chatService.getOrCreateConversation(
          currentUser.user.id,
          medication
        );
        setConversation(conv);

        // Load conversation history
        const history = await chatService.getConversationHistory(conv.id);
        setMessages(history);

        // Initialize chat state
        const state = chatService.getChatState(conv.id);
        setChatState(state);

      } catch (error) {
        console.error('Failed to initialize chat:', error);
        setChatState(prev => ({
          ...prev,
          error: 'Failed to load conversation. Please try again.',
          connectionStatus: 'disconnected'
        }));
      } finally {
        setIsInitializing(false);
      }
    };

    initializeChat();
  }, [medication.id]);

  // Poll for chat state updates (for loading/typing indicators)
  useEffect(() => {
    if (!conversation) return;

    const pollInterval = setInterval(() => {
      const currentState = chatService.getChatState(conversation.id);
      setChatState(currentState);
    }, 500);

    return () => clearInterval(pollInterval);
  }, [conversation]);

  const handleSendMessage = async (message: string) => {
    if (!conversation || !message.trim()) return;

    try {
      // Optimistically add user message
      const userMessage: ChatMessageType = {
        id: `temp-${Date.now()}`,
        conversationId: conversation.id,
        role: 'user',
        content: message.trim(),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, userMessage]);

      // Send message and get AI response
      await chatService.sendMessage(
        conversation.id,
        message.trim(),
        medication
      );

      // Update messages with actual response
      const updatedHistory = await chatService.getConversationHistory(conversation.id);
      setMessages(updatedHistory);

    } catch (error) {
      console.error('Failed to send message:', error);
      // Reload messages to show error state
      const history = await chatService.getConversationHistory(conversation.id);
      setMessages(history);
    }
  };

  const handleRetryConnection = async () => {
    setChatState(prev => ({ ...prev, isLoading: true, error: null }));
    
    const isConnected = await chatService.testConnection();
    setChatState(prev => ({
      ...prev,
      isLoading: false,
      connectionStatus: isConnected ? 'connected' : 'disconnected',
      error: isConnected ? null : 'Unable to connect to AI assistant'
    }));
  };

  if (isInitializing) {
    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-200 ${className}`}>
        <div className="p-4 border-b border-gray-200">
          <Skeleton className="h-6 w-48" />
        </div>
        <div className="p-4 space-y-4">
          <Skeleton className="h-16 w-3/4" />
          <Skeleton className="h-16 w-1/2 ml-auto" />
          <Skeleton className="h-16 w-2/3" />
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50 rounded-t-lg">
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${chatState.connectionStatus === 'connected' ? 'bg-green-500' : 'bg-red-500'}`} />
          <div>
            <h3 className="font-medium text-gray-900">
              Chat about {medication.name}
            </h3>
            <p className="text-sm text-gray-500">
              {chatState.connectionStatus === 'connected' ? 'AI Assistant Available' : 'Connection Issues'}
            </p>
          </div>
        </div>
        
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-primary-500 rounded"
            aria-label="Close chat"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Error Banner */}
      {chatState.error && (
        <div className="bg-red-50 border-b border-red-200 p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <svg className="w-4 h-4 text-red-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span className="text-sm text-red-800">{chatState.error}</span>
            </div>
            <button
              onClick={handleRetryConnection}
              className="text-xs text-red-600 hover:text-red-800 font-medium"
              disabled={chatState.isLoading}
            >
              {chatState.isLoading ? 'Retrying...' : 'Retry'}
            </button>
          </div>
        </div>
      )}

      {/* Messages */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-1"
        style={{ maxHeight }}
      >
        {messages.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p className="text-lg font-medium mb-2">Start a conversation</p>
            <p className="text-sm">Ask questions about your medication, side effects, or usage tips.</p>
          </div>
        ) : (
          messages.map((message, index) => (
            <ChatMessage
              key={message.id}
              message={message}
              isLatest={index === messages.length - 1}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <ChatInput
        onSendMessage={handleSendMessage}
        isLoading={chatState.isLoading}
        isTyping={chatState.isTyping}
        disabled={chatState.connectionStatus === 'disconnected'}
        placeholder={`Ask about ${medication.name}...`}
      />

      {/* Loading Overlay */}
      {chatState.isLoading && !chatState.isTyping && (
        <LoadingOverlay isVisible={true} message="Initializing chat..." />
      )}
    </div>
  );
};