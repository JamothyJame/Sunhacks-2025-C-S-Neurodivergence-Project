import React, { useState, useRef, useEffect } from 'react';
import { LoadingDots } from '@/components/LoadingStates';

interface ChatInputProps {
  onSendMessage: (message: string) => Promise<void>;
  isLoading?: boolean;
  isTyping?: boolean;
  disabled?: boolean;
  placeholder?: string;
  maxLength?: number;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading = false,
  isTyping = false,
  disabled = false,
  placeholder = "Ask about your medication...",
  maxLength = 500
}) => {
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      const newHeight = Math.min(textarea.scrollHeight, 120); // Max 4-5 lines
      textarea.style.height = `${newHeight}px`;
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [message]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || isSubmitting || disabled || isLoading) return;

    const messageToSend = message.trim();
    setMessage('');
    setIsSubmitting(true);

    try {
      await onSendMessage(messageToSend);
    } catch (error) {
      // Error handling is done in the parent component
      console.error('Failed to send message:', error);
    } finally {
      setIsSubmitting(false);
    }

    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const isInputDisabled = disabled || isLoading || isSubmitting;
  const canSend = message.trim().length > 0 && !isInputDisabled;

  return (
    <div className="border-t border-gray-200 bg-white p-4">
      {/* Typing indicator */}
      {isTyping && (
        <div className="mb-3 flex items-center text-sm text-gray-600">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-2">
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <span>AI is thinking</span>
          <LoadingDots />
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex items-end space-x-3">
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            disabled={isInputDisabled}
            maxLength={maxLength}
            rows={1}
            className={`
              w-full resize-none rounded-lg border border-gray-300 px-4 py-3 pr-16
              text-sm leading-5 placeholder-gray-400 focus:border-primary-500 
              focus:outline-none focus:ring-1 focus:ring-primary-500
              ${isInputDisabled ? 'bg-gray-50 cursor-not-allowed' : 'bg-white'}
              transition-colors duration-200
            `}
            style={{ minHeight: '44px' }}
          />
          
          {/* Character count */}
          <div className="absolute bottom-2 right-2 text-xs text-gray-400">
            {message.length}/{maxLength}
          </div>
        </div>

        <button
          type="submit"
          disabled={!canSend}
          className={`
            flex-shrink-0 px-4 py-3 rounded-lg font-medium text-sm
            transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2
            ${canSend 
              ? 'bg-primary-500 text-white hover:bg-primary-600 focus:ring-primary-500 transform hover:scale-105' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }
          `}
          aria-label="Send message"
        >
          {isSubmitting ? (
            <LoadingDots />
          ) : (
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          )}
        </button>
      </form>

      {/* Help text */}
      <div className="mt-2 text-xs text-gray-500">
        Press Enter to send, Shift + Enter for new line
      </div>
    </div>
  );
};