import React, { useState } from 'react';
import { Medication } from '@/types';
import { ChatContainer } from './ChatContainer';

interface ChatButtonProps {
  medication: Medication;
  className?: string;
  variant?: 'icon' | 'full';
}

export const ChatButton: React.FC<ChatButtonProps> = ({
  medication,
  className = '',
  variant = 'icon'
}) => {
  const [showChat, setShowChat] = useState(false);

  const handleToggleChat = () => {
    setShowChat(!showChat);
  };

  return (
    <>
      {/* Chat Button */}
      {variant === 'icon' ? (
        <button
          onClick={handleToggleChat}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-600 hover:from-blue-200 hover:to-indigo-200 hover:text-blue-700 ${className}`}
          title={`Chat about ${medication.name}`}
          aria-label={`Open chat about ${medication.name}`}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        </button>
      ) : (
        <button
          onClick={handleToggleChat}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:from-blue-600 hover:to-indigo-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${className}`}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <span>Ask AI</span>
        </button>
      )}

      {/* Chat Modal */}
      {showChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-2xl h-[80vh] max-h-[600px] relative">
            <ChatContainer
              medication={medication}
              onClose={() => setShowChat(false)}
              className="h-full"
              maxHeight="calc(100% - 120px)"
            />
          </div>
        </div>
      )}
    </>
  );
};