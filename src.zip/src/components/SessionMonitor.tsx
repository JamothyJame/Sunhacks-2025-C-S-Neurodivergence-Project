import React, { useEffect, useState } from 'react';
import { UserService } from '@/services/UserService';
import { createLogger } from '@/services/LoggingService';

const logger = createLogger('SessionMonitor');

interface SessionMonitorProps {
  onSessionExpired?: () => void;
  onSessionWarning?: (timeLeft: number) => void;
}

export const SessionMonitor: React.FC<SessionMonitorProps> = ({
  onSessionExpired,
  onSessionWarning,
}) => {
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [showWarning, setShowWarning] = useState(false);
  const userService = UserService.getInstance();

  // Warning thresholds (in milliseconds)
  const WARNING_TIME = 5 * 60 * 1000; // 5 minutes
  const URGENT_TIME = 1 * 60 * 1000; // 1 minute

  useEffect(() => {
    if (!userService.isAuthenticated()) {
      return;
    }

    const checkSession = () => {
      const timeLeftMs = userService.getSessionTimeLeftMs();
      
      if (timeLeftMs === null) {
        logger.warn('Unable to get session time left');
        return;
      }

      setTimeLeft(timeLeftMs);

      if (timeLeftMs <= 0) {
        logger.info('Session expired, signing out user');
        setShowWarning(false);
        onSessionExpired?.();
        userService.signOutUser();
      } else if (timeLeftMs <= URGENT_TIME && !showWarning) {
        logger.warn('Session expiring soon', { timeLeftMs });
        setShowWarning(true);
        onSessionWarning?.(timeLeftMs);
      } else if (timeLeftMs <= WARNING_TIME && !showWarning) {
        logger.info('Session warning threshold reached', { timeLeftMs });
        setShowWarning(true);
        onSessionWarning?.(timeLeftMs);
      } else if (timeLeftMs > WARNING_TIME && showWarning) {
        // Session was refreshed
        setShowWarning(false);
      }
    };

    // Check immediately
    checkSession();

    // Check every 30 seconds
    const interval = setInterval(checkSession, 30000);

    return () => clearInterval(interval);
  }, [userService, showWarning, onSessionExpired, onSessionWarning]);

  const handleExtendSession = async () => {
    const currentSessionId = userService.getCurrentSessionId();
    if (currentSessionId) {
      logger.info('Attempting to refresh session');
      const newSession = await userService.refreshSession(currentSessionId);
      if (newSession) {
        logger.info('Session refreshed successfully');
        setShowWarning(false);
        userService.saveSessionToStorage();
      } else {
        logger.error('Failed to refresh session');
        onSessionExpired?.();
      }
    }
  };

  const handleSignOut = () => {
    logger.info('User manually signed out from session warning');
    setShowWarning(false);
    userService.signOutUser();
    onSessionExpired?.();
  };

  const formatTimeLeft = (ms: number): string => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    }
    return `${seconds}s`;
  };

  if (!showWarning || !timeLeft) {
    return null;
  }

  const isUrgent = timeLeft <= URGENT_TIME;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-yellow-50 border-b border-yellow-200 px-4 py-3">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className={`text-2xl ${isUrgent ? 'animate-pulse' : ''}`}>
            {isUrgent ? '🚨' : '⚠️'}
          </span>
          <div>
            <div className={`font-semibold ${isUrgent ? 'text-red-800' : 'text-yellow-800'}`}>
              {isUrgent ? 'Session Expiring Soon!' : 'Session Warning'}
            </div>
            <div className={`text-sm ${isUrgent ? 'text-red-700' : 'text-yellow-700'}`}>
              Your session will expire in {formatTimeLeft(timeLeft)}
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={handleExtendSession}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              isUrgent 
                ? 'bg-red-600 hover:bg-red-700 text-white' 
                : 'bg-yellow-600 hover:bg-yellow-700 text-white'
            }`}
          >
            Extend Session
          </button>
          <button
            onClick={handleSignOut}
            className="px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

// Hook for using session monitoring in components
export const useSessionMonitor = () => {
  const [isSessionExpiring, setIsSessionExpiring] = useState(false);
  const [sessionTimeLeft, setSessionTimeLeft] = useState<number | null>(null);

  const handleSessionWarning = (timeLeft: number) => {
    setIsSessionExpiring(true);
    setSessionTimeLeft(timeLeft);
  };

  const handleSessionExpired = () => {
    setIsSessionExpiring(false);
    setSessionTimeLeft(null);
  };

  return {
    isSessionExpiring,
    sessionTimeLeft,
    handleSessionWarning,
    handleSessionExpired,
  };
};