import React from 'react';

/**
 * Loading States Component
 * Provides consistent loading indicators throughout the application
 */

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'secondary' | 'white' | 'gray';
}

export const Spinner: React.FC<SpinnerProps> = ({ 
  size = 'md', 
  color = 'primary' 
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6', 
    lg: 'w-8 h-8'
  };

  const colorClasses = {
    primary: 'border-primary-500 border-t-transparent',
    secondary: 'border-secondary-500 border-t-transparent',
    white: 'border-white border-t-transparent',
    gray: 'border-gray-400 border-t-transparent'
  };

  return (
    <div 
      className={`${sizeClasses[size]} ${colorClasses[color]} border-2 rounded-full animate-spin`}
      role="status"
      aria-label="Loading"
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
};

interface LoadingDotsProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'secondary' | 'gray';
}

export const LoadingDots: React.FC<LoadingDotsProps> = ({ 
  size = 'md', 
  color = 'primary' 
}) => {
  const sizeClasses = {
    sm: 'w-1 h-1',
    md: 'w-2 h-2',
    lg: 'w-3 h-3'
  };

  const colorClasses = {
    primary: 'bg-primary-500',
    secondary: 'bg-secondary-500',
    gray: 'bg-gray-400'
  };

  return (
    <div className="flex justify-center items-center space-x-1" role="status" aria-label="Loading">
      <div className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full animate-bounce`}></div>
      <div 
        className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full animate-bounce`}
        style={{ animationDelay: '0.1s' }}
      ></div>
      <div 
        className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full animate-bounce`}
        style={{ animationDelay: '0.2s' }}
      ></div>
      <span className="sr-only">Loading...</span>
    </div>
  );
};

interface LoadingCardProps {
  title?: string;
  message?: string;
  showIcon?: boolean;
  variant?: 'simple' | 'medication' | 'profile';
}

export const LoadingCard: React.FC<LoadingCardProps> = ({
  title = "Loading...",
  message = "Please wait while we load your data",
  showIcon = true,
  variant = 'simple'
}) => {
  const getIcon = () => {
    switch (variant) {
      case 'medication':
        return '💊';
      case 'profile':
        return '👤';
      default:
        return '⏳';
    }
  };

  return (
    <div className="card text-center py-8">
      {showIcon && (
        <div className="relative mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-3xl flex items-center justify-center mx-auto">
            <span className="text-3xl">{getIcon()}</span>
          </div>
          <div className="absolute inset-0 w-16 h-16 border-4 border-primary-200 border-t-primary-500 rounded-3xl animate-spin mx-auto"></div>
        </div>
      )}
      
      <h3 className="text-lg font-semibold text-gray-800 mb-2">{title}</h3>
      <p className="text-gray-600 text-sm mb-6">{message}</p>
      
      <LoadingDots size="md" color="primary" />
    </div>
  );
};

interface LoadingOverlayProps {
  isVisible: boolean;
  title?: string;
  message?: string;
  variant?: 'fullscreen' | 'modal';
}

export const LoadingOverlay: React.FC<LoadingOverlayProps> = ({
  isVisible,
  title = "Processing...",
  message = "Please wait",
  variant = 'modal'
}) => {
  if (!isVisible) return null;

  const baseClasses = variant === 'fullscreen' 
    ? "fixed inset-0 z-50 bg-white/90 backdrop-blur-sm"
    : "absolute inset-0 z-10 bg-white/90 backdrop-blur-sm rounded-xl";

  return (
    <div className={`${baseClasses} flex items-center justify-center`}>
      <div className="text-center">
        <div className="relative mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-600 rounded-3xl flex items-center justify-center mx-auto shadow-lg">
            <span className="text-white text-2xl">⚡</span>
          </div>
          <div className="absolute inset-0 w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-3xl animate-spin mx-auto"></div>
        </div>
        
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600">{message}</p>
      </div>
    </div>
  );
};

interface SkeletonProps {
  width?: string;
  height?: string;
  className?: string;
}

export const Skeleton: React.FC<SkeletonProps> = ({
  width = "100%",
  height = "1rem",
  className = ""
}) => {
  return (
    <div 
      className={`bg-gray-200 rounded animate-pulse ${className}`}
      style={{ width, height }}
      role="status"
      aria-label="Loading content"
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
};

export const MedicationSkeleton: React.FC = () => {
  return (
    <div className="card">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Skeleton width="3rem" height="3rem" className="rounded-2xl" />
          <div>
            <Skeleton width="8rem" height="1.25rem" className="mb-2" />
            <Skeleton width="6rem" height="0.875rem" />
          </div>
        </div>
        <Skeleton width="2rem" height="2rem" className="rounded-lg" />
      </div>
      
      <div className="space-y-3">
        <div className="flex justify-between">
          <Skeleton width="4rem" height="0.875rem" />
          <Skeleton width="3rem" height="0.875rem" />
        </div>
        <div className="flex justify-between">
          <Skeleton width="5rem" height="0.875rem" />
          <Skeleton width="4rem" height="0.875rem" />
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex justify-between">
          <Skeleton width="4rem" height="2rem" className="rounded-lg" />
          <Skeleton width="3rem" height="2rem" className="rounded-lg" />
        </div>
      </div>
    </div>
  );
};

export const ProfileSkeleton: React.FC = () => {
  return (
    <div className="card">
      <div className="flex items-center space-x-4 mb-6">
        <Skeleton width="4rem" height="4rem" className="rounded-2xl" />
        <div>
          <Skeleton width="10rem" height="1.5rem" className="mb-2" />
          <Skeleton width="8rem" height="1rem" />
        </div>
      </div>
      
      <div className="space-y-4">
        <div>
          <Skeleton width="4rem" height="0.875rem" className="mb-2" />
          <Skeleton width="100%" height="2.5rem" className="rounded-lg" />
        </div>
        <div>
          <Skeleton width="4rem" height="0.875rem" className="mb-2" />
          <Skeleton width="100%" height="2.5rem" className="rounded-lg" />
        </div>
        <div>
          <Skeleton width="4rem" height="0.875rem" className="mb-2" />
          <Skeleton width="100%" height="2.5rem" className="rounded-lg" />
        </div>
      </div>
      
      <div className="mt-6 pt-6 border-t border-gray-100">
        <Skeleton width="8rem" height="2.5rem" className="rounded-lg" />
      </div>
    </div>
  );
};

interface LoadingButtonProps {
  isLoading: boolean;
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  loadingText?: string;
  variant?: 'primary' | 'secondary' | 'danger';
}

export const LoadingButton: React.FC<LoadingButtonProps> = ({
  isLoading,
  children,
  onClick,
  disabled = false,
  className = "",
  loadingText = "Loading...",
  variant = 'primary'
}) => {
  const baseClasses = "inline-flex items-center justify-center px-4 py-2 rounded-lg font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variantClasses = {
    primary: "bg-primary-600 hover:bg-primary-700 text-white",
    secondary: "bg-gray-200 hover:bg-gray-300 text-gray-900", 
    danger: "bg-red-600 hover:bg-red-700 text-white"
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled || isLoading}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      {isLoading ? (
        <>
          <Spinner size="sm" color="white" />
          <span className="ml-2">{loadingText}</span>
        </>
      ) : (
        children
      )}
    </button>
  );
};

interface InlineLoadingProps {
  text?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const InlineLoading: React.FC<InlineLoadingProps> = ({
  text = "Loading...",
  size = 'sm'
}) => {
  return (
    <div className="inline-flex items-center space-x-2 text-gray-600">
      <Spinner size={size} color="gray" />
      <span className={`${size === 'sm' ? 'text-sm' : size === 'lg' ? 'text-lg' : 'text-base'}`}>
        {text}
      </span>
    </div>
  );
};

interface ProgressBarProps {
  progress: number; // 0-100
  label?: string;
  showPercentage?: boolean;
  color?: 'primary' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  label,
  showPercentage = true,
  color = 'primary',
  size = 'md',
  animated = false
}) => {
  const colorClasses = {
    primary: 'from-primary-500 to-primary-600',
    success: 'from-green-500 to-green-600',
    warning: 'from-yellow-500 to-yellow-600',
    danger: 'from-red-500 to-red-600'
  };

  const sizeClasses = {
    sm: 'h-2',
    md: 'h-3',
    lg: 'h-4'
  };

  const clampedProgress = Math.min(100, Math.max(0, progress));

  return (
    <div>
      {(label || showPercentage) && (
        <div className="flex justify-between text-sm text-gray-600 mb-1">
          {label && <span>{label}</span>}
          {showPercentage && <span>{Math.round(clampedProgress)}%</span>}
        </div>
      )}
      <div className={`w-full bg-gray-200 rounded-full ${sizeClasses[size]}`}>
        <div
          className={`bg-gradient-to-r ${colorClasses[color]} ${sizeClasses[size]} rounded-full transition-all duration-300 ${animated ? 'animate-pulse' : ''}`}
          style={{ width: `${clampedProgress}%` }}
          role="progressbar"
          aria-valuenow={clampedProgress}
          aria-valuemin={0}
          aria-valuemax={100}
        />
      </div>
    </div>
  );
};

// Loading state indicators for specific contexts
export const LoadingStates = {
  Spinner,
  LoadingDots,
  LoadingCard,
  LoadingOverlay,
  Skeleton,
  MedicationSkeleton,
  ProfileSkeleton,
  LoadingButton,
  InlineLoading,
  ProgressBar
};