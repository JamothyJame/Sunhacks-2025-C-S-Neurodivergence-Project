import React, { useState } from 'react';

interface AuthenticationFormProps {
  onSignUp: (userData: {
    email: string;
    firstName: string;
    lastName: string;
    dateOfBirth?: Date;
  }) => Promise<{ success: boolean; error?: string }>;
  onSignIn: (email: string) => Promise<{ success: boolean; error?: string }>;
  isLoading?: boolean;
}

export const AuthenticationForm: React.FC<AuthenticationFormProps> = ({
  onSignUp,
  onSignIn,
  isLoading = false
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    dateOfBirth: ''
  });
  const [error, setError] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.email) {
      setError('Email is required');
      return;
    }

    if (mode === 'signup') {
      if (!formData.firstName || !formData.lastName) {
        setError('First name and last name are required');
        return;
      }

      const userData = {
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        dateOfBirth: formData.dateOfBirth ? new Date(formData.dateOfBirth) : undefined
      };

      const result = await onSignUp(userData);
      if (!result.success) {
        setError(result.error || 'Failed to create account');
      }
    } else {
      const result = await onSignIn(formData.email);
      if (!result.success) {
        setError(result.error || 'Failed to sign in');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      email: '',
      firstName: '',
      lastName: '',
      dateOfBirth: ''
    });
    setError('');
  };

  const switchMode = () => {
    setMode(mode === 'signin' ? 'signup' : 'signin');
    resetForm();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="card-elevated max-w-md w-full relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary-100 to-purple-100 rounded-full transform translate-x-16 -translate-y-16 opacity-50"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-br from-blue-100 to-green-100 rounded-full transform -translate-x-12 translate-y-12 opacity-50"></div>
        
        {/* Header */}
        <div className="text-center mb-8 relative z-10">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
            <span className="text-white text-3xl">💊</span>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">MedTracker</h1>
          <p className="text-gray-600 mt-3 text-lg">
            {mode === 'signin' 
              ? 'Welcome back! 😊 Ready to continue your health journey?'
              : 'Join thousands taking control of their health! 🎆'
            }
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-xl mb-6 relative z-10">
            <div className="flex items-center space-x-2">
              <span className="text-lg">⚠️</span>
              <span className="font-medium">{error}</span>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
          {/* Email */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              📧 Email Address
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="input-field"
              placeholder="your.email@example.com"
              required
            />
          </div>

          {/* First Name and Last Name (Sign Up only) */}
          {mode === 'signup' && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    👤 First Name
                  </label>
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="input-field"
                    placeholder="John"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    📝 Last Name
                  </label>
                  <input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="input-field"
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>

              {/* Date of Birth (Optional) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  🎂 Date of Birth <span className="text-gray-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="input-field"
                />
                <p className="text-xs text-gray-500 mt-2 flex items-start space-x-1">
                  <span>💡</span>
                  <span>Helps us provide personalized medication reminders and health insights.</span>
                </p>
              </div>
            </>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full btn btn-primary py-4 text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
          >
            {isLoading ? (
              <span className="flex items-center justify-center space-x-2">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Please wait...</span>
              </span>
            ) : (
              <span className="flex items-center justify-center space-x-2">
                <span>{mode === 'signin' ? '🚀' : '✨'}</span>
                <span>{mode === 'signin' ? 'Sign In' : 'Create Account'}</span>
              </span>
            )}
          </button>
        </form>

        {/* Switch Mode */}
        <div className="text-center mt-8 relative z-10">
          <p className="text-gray-600">
            {mode === 'signin' 
              ? "New to MedTracker? " 
              : "Already have an account? "
            }
            <button
              type="button"
              onClick={switchMode}
              className="text-primary-600 hover:text-primary-700 font-semibold transition-colors duration-200 underline decoration-2 underline-offset-2"
            >
              {mode === 'signin' ? 'Create Account' : 'Sign In'}
            </button>
          </p>
        </div>

        {/* Demo Note */}
        <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl relative z-10">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-blue-600 text-lg">📱</span>
            </div>
            <div>
              <h4 className="font-semibold text-blue-900 mb-1">Demo Application</h4>
              <p className="text-sm text-blue-800 leading-relaxed">
                This is a demo app that stores data locally in your browser using IndexedDB. 
                No real authentication required - just enter any email to get started!
              </p>
            </div>
          </div>
        </div>

        {/* Features Preview */}
        <div className="mt-8 text-center relative z-10">
          <h3 className="text-lg font-bold text-gray-800 mb-6">🎆 What you'll unlock:</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-200">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-green-600">💊</span>
              </div>
              <span className="text-sm font-medium text-gray-700">Smart Tracking</span>
            </div>
            <div className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-blue-600">🔔</span>
              </div>
              <span className="text-sm font-medium text-gray-700">Reminders</span>
            </div>
            <div className="p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border border-purple-200">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-purple-600">🏆</span>
              </div>
              <span className="text-sm font-medium text-gray-700">Achievements</span>
            </div>
            <div className="p-3 bg-gradient-to-br from-orange-50 to-yellow-50 rounded-xl border border-orange-200">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-orange-600">📈</span>
              </div>
              <span className="text-sm font-medium text-gray-700">Insights</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};