// User types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: Date;
  timezone: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  lastLoginAt?: Date;
}

export interface UserProfile {
  userId: string;
  avatar?: string;
  bio?: string;
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  medicalInfo?: {
    allergies: string[];
    conditions: string[];
    primaryPhysician?: {
      name: string;
      phone: string;
      email?: string;
    };
  };
  updatedAt: Date;
}

export interface UserPreferences {
  userId: string;
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  timeFormat: '12h' | '24h';
  dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
  notifications: {
    medication: boolean;
    achievements: boolean;
    reminders: boolean;
    email: boolean;
    push: boolean;
    throttleHours: number; // Hours between supply notifications for same medication
    refillReminderDays: number; // Days ahead to remind about refills
  };
  dashboard: {
    defaultView: 'calendar' | 'list' | 'cards';
    showStats: boolean;
    showAchievements: boolean;
    compactMode: boolean;
  };
  privacy: {
    shareStats: boolean;
    allowAnalytics: boolean;
  };
  updatedAt: Date;
}

export interface UserSession {
  id: string;
  userId: string;
  deviceInfo: {
    platform: string;
    browser?: string;
    isMobile: boolean;
  };
  createdAt: Date;
  expiresAt: Date;
  lastActiveAt: Date;
}

// Core medication types
export interface Medication {
  id: string;
  userId: string;
  name: string;
  genericName?: string;
  dosage?: string;
  frequency: number;
  times: string[];
  startDate: Date;
  endDate?: Date;
  notes?: string;
  color: string;
  isActive: boolean;
  reminderEnabled: boolean;
  // Inventory tracking fields
  currentSupply?: number; // Number of pills/doses currently available
  refillsRemaining?: number; // Number of refills left on prescription
  pillsPerDose?: number; // How many pills constitute one dose (default 1)
  supplyLastUpdated?: Date; // When the supply count was last updated
  createdAt: Date;
  updatedAt: Date;
}

// Medication log entry for tracking taken doses
export interface MedicationLog {
  id: string;
  userId: string;
  medicationId: string;
  scheduledTime: Date;
  actualTime?: Date;
  status: 'taken' | 'missed' | 'pending';
  notes?: string;
  createdAt: Date;
}

// Gamification types
export interface UserStats {
  id: string;
  userId: string;
  level: number;
  experience: number;
  totalPoints: number;
  currentStreak: number;
  longestStreak: number;
  totalMedicationsTaken: number;
  adherenceRate: number;
  updatedAt: Date;
}

export interface Achievement {
  id: string;
  userId: string;
  name: string;
  description: string;
  icon: string;
  points: number;
  requirements: {
    type: 'streak' | 'total_taken' | 'adherence_rate' | 'days_active';
    value: number;
  };
  isUnlocked: boolean;
  unlockedAt?: Date;
}

// DailyMed API types
export interface DrugSearchResult {
  setid: string;
  title: string;
  generic_medicine: string[];
  brand_name: string[];
  pharm_classes: string[];
  application_number: string[];
}

export interface DrugDetails {
  setid: string;
  title: string;
  generic_name?: string;
  brand_names: string[];
  active_ingredients: string[];
  dosage_forms: string[];
  routes: string[];
  marketing_start_date?: string;
  labeler_name?: string;
  ndc_numbers?: string[];
}

// Notification types
export interface NotificationSettings {
  enabled: boolean;
  reminderMinutesBefore: number;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

// Schedule types
export interface MedicationSchedule {
  medicationId: string;
  times: string[]; // Array of time strings like "08:00", "12:00", "20:00"
  frequency: number; // Times per day
  startDate: Date;
  endDate?: Date;
  isActive: boolean;
}

// App state types
export interface AppState {
  currentUser: User | null;
  userProfile: UserProfile | null;
  userPreferences: UserPreferences | null;
  medications: Medication[];
  logs: MedicationLog[];
  userStats: UserStats | null;
  achievements: Achievement[];
  notifications: NotificationSettings;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
}
