export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isError?: boolean;
  errorMessage?: string;
}

export interface MedicationConversation {
  id: string;
  userId: string;
  medicationId: string;
  medicationName: string;
  title: string; // Auto-generated from first message or user-set
  createdAt: Date;
  updatedAt: Date;
  messageCount: number;
  isActive: boolean;
}

export interface ChatState {
  isLoading: boolean;
  error: string | null;
  isTyping: boolean;
  connectionStatus: 'connected' | 'disconnected' | 'testing';
}

export type ChatError = {
  type: 'network' | 'api' | 'validation' | 'rate_limit';
  message: string;
  retryable: boolean;
};