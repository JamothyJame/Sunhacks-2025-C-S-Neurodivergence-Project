import { Medication as MedicationType, MedicationLog } from '@/types';
import { generateUUID } from '@/utils/uuid';

export class MedicationModel {
  private data: MedicationType;

  constructor(data: MedicationType) {
    this.data = data;
  }

  // Getters
  get id(): string { return this.data.id; }
  get userId(): string { return this.data.userId; }
  get name(): string { return this.data.name; }
  get genericName(): string | undefined { return this.data.genericName; }
  get dosage(): string | undefined { return this.data.dosage; }
  get frequency(): number { return this.data.frequency; }
  get times(): string[] { return this.data.times; }
  get startDate(): Date { return this.data.startDate; }
  get endDate(): Date | undefined { return this.data.endDate; }
  get notes(): string | undefined { return this.data.notes; }
  get color(): string { return this.data.color; }
  get isActive(): boolean { return this.data.isActive; }
  get reminderEnabled(): boolean { return this.data.reminderEnabled; }
  get currentSupply(): number | undefined { return this.data.currentSupply; }
  get refillsRemaining(): number | undefined { return this.data.refillsRemaining; }
  get pillsPerDose(): number { return this.data.pillsPerDose || 1; }
  get supplyLastUpdated(): Date | undefined { return this.data.supplyLastUpdated; }
  get createdAt(): Date { return this.data.createdAt; }
  get updatedAt(): Date { return this.data.updatedAt; }

  // Get the raw data
  get rawData(): MedicationType {
    return { ...this.data };
  }

  // Business logic methods
  isTimeForDose(currentTime: Date): boolean {
    const currentTimeString = `${currentTime.getHours().toString().padStart(2, '0')}:${currentTime.getMinutes().toString().padStart(2, '0')}`;
    return this.data.times.includes(currentTimeString);
  }

  getNextDoseTime(): Date | null {
    const now = new Date();
    const currentTimeMinutes = now.getHours() * 60 + now.getMinutes();
    
    for (const time of this.data.times) {
      const [hours, minutes] = time.split(':').map(Number);
      const timeMinutes = hours * 60 + minutes;
      
      if (timeMinutes > currentTimeMinutes) {
        const nextDose = new Date(now);
        nextDose.setHours(hours, minutes, 0, 0);
        return nextDose;
      }
    }
    
    // If no more doses today, get the first dose tomorrow
    if (this.data.times.length > 0) {
      const [hours, minutes] = this.data.times[0].split(':').map(Number);
      const nextDose = new Date(now);
      nextDose.setDate(nextDose.getDate() + 1);
      nextDose.setHours(hours, minutes, 0, 0);
      return nextDose;
    }
    
    return null;
  }

  shouldShowReminder(currentTime: Date, reminderMinutes: number = 15): boolean {
    if (!this.data.reminderEnabled || !this.data.isActive) return false;
    
    const nextDose = this.getNextDoseTime();
    if (!nextDose) return false;
    
    const timeDiff = nextDose.getTime() - currentTime.getTime();
    const minutesDiff = timeDiff / (1000 * 60);
    
    return minutesDiff <= reminderMinutes && minutesDiff > 0;
  }

  isOverdue(currentTime: Date, logs: MedicationLog[]): boolean {
    if (!this.data.isActive) return false;
    
    const todayStart = new Date(currentTime);
    todayStart.setHours(0, 0, 0, 0);
    
    for (const time of this.data.times) {
      const [hours, minutes] = time.split(':').map(Number);
      const scheduledTime = new Date(todayStart);
      scheduledTime.setHours(hours, minutes, 0, 0);
      
      if (scheduledTime < currentTime) {
        // Check if there's a log entry for this scheduled time
        const hasLog = logs.some(log => 
          log.medicationId === this.data.id &&
          Math.abs(log.scheduledTime.getTime() - scheduledTime.getTime()) < 60000 && // Within 1 minute
          log.status === 'taken'
        );
        
        if (!hasLog) return true;
      }
    }
    
    return false;
  }

  getScheduledDosesForDate(date: Date): Date[] {
    if (!this.data.isActive) return [];
    
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    // Check if the medication was active on this date
    const startDate = new Date(this.data.startDate);
    startDate.setHours(0, 0, 0, 0);
    
    if (targetDate < startDate) return [];
    
    if (this.data.endDate) {
      const endDate = new Date(this.data.endDate);
      endDate.setHours(23, 59, 59, 999);
      if (targetDate > endDate) return [];
    }
    
    // Create scheduled dose times for the date
    const doses: Date[] = [];
    for (const time of this.data.times) {
      const [hours, minutes] = time.split(':').map(Number);
      const scheduledTime = new Date(targetDate);
      scheduledTime.setHours(hours, minutes, 0, 0);
      doses.push(scheduledTime);
    }
    
    return doses;
  }

  calculateAdherenceRate(logs: MedicationLog[], days: number = 30): number {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const relevantLogs = logs.filter(log => 
      log.medicationId === this.data.id && 
      log.scheduledTime >= cutoffDate
    );
    
    if (relevantLogs.length === 0) return 0;
    
    const takenCount = relevantLogs.filter(log => log.status === 'taken').length;
    return (takenCount / relevantLogs.length) * 100;
  }

  // Inventory tracking methods
  getDaysRemainingFromSupply(): number | null {
    if (this.data.currentSupply === undefined || this.data.currentSupply <= 0) {
      return null;
    }
    
    const pillsPerDay = this.data.frequency * this.pillsPerDose;
    
    // Guard against division by zero or invalid values
    if (pillsPerDay <= 0) {
      console.warn(`Invalid medication configuration: frequency=${this.data.frequency}, pillsPerDose=${this.pillsPerDose}`);
      return null;
    }
    
    return Math.floor(this.data.currentSupply / pillsPerDay);
  }

  needsRefillReminder(daysAhead: number = 3): boolean {
    const daysRemaining = this.getDaysRemainingFromSupply();
    return daysRemaining !== null && daysRemaining <= daysAhead && daysRemaining >= 0;
  }

  needsNewPrescriptionReminder(daysAhead: number = 5): boolean {
    const daysRemaining = this.getDaysRemainingFromSupply();
    return (
      daysRemaining !== null && 
      daysRemaining <= daysAhead && 
      daysRemaining >= 0 &&
      (this.data.refillsRemaining === undefined || this.data.refillsRemaining <= 0)
    );
  }

  getSupplyStatus(): {
    status: 'adequate' | 'low' | 'critical' | 'out' | 'unknown';
    daysRemaining: number | null;
    message: string;
  } {
    const daysRemaining = this.getDaysRemainingFromSupply();
    
    if (daysRemaining === null) {
      return {
        status: 'unknown',
        daysRemaining: null,
        message: 'Supply information not available'
      };
    }
    
    if (daysRemaining <= 0) {
      return {
        status: 'out',
        daysRemaining,
        message: 'Out of medication'
      };
    }
    
    if (daysRemaining <= 3) {
      const needsNewRx = this.needsNewPrescriptionReminder(5);
      return {
        status: 'critical',
        daysRemaining,
        message: needsNewRx 
          ? `${daysRemaining} days left - Contact doctor for new prescription`
          : `${daysRemaining} days left - Time to refill`
      };
    }
    
    if (daysRemaining <= 7) {
      return {
        status: 'low',
        daysRemaining,
        message: `${daysRemaining} days remaining`
      };
    }
    
    return {
      status: 'adequate',
      daysRemaining,
      message: `${daysRemaining} days remaining`
    };
  }

  consumeDose(): MedicationModel {
    if (this.data.currentSupply === undefined || this.data.currentSupply <= 0) {
      return this; // No supply to consume
    }
    
    const newSupply = Math.max(0, this.data.currentSupply - this.pillsPerDose);
    return this.update({
      currentSupply: newSupply,
      supplyLastUpdated: new Date()
    });
  }

  updateSupply(newSupply: number, refillsUsed: number = 0): MedicationModel {
    const updates: Partial<MedicationType> = {
      currentSupply: Math.max(0, newSupply),
      supplyLastUpdated: new Date()
    };
    
    if (refillsUsed > 0 && this.data.refillsRemaining !== undefined) {
      updates.refillsRemaining = Math.max(0, this.data.refillsRemaining - refillsUsed);
    }
    
    return this.update(updates);
  }

  // Update methods
  update(updates: Partial<MedicationType>): MedicationModel {
    const updatedData = {
      ...this.data,
      ...updates,
      updatedAt: new Date()
    };
    return new MedicationModel(updatedData);
  }

  toggleActive(): MedicationModel {
    return this.update({ isActive: !this.data.isActive });
  }

  toggleReminder(): MedicationModel {
    return this.update({ reminderEnabled: !this.data.reminderEnabled });
  }

  // Static factory methods
  static create(data: Omit<MedicationType, 'id' | 'createdAt' | 'updatedAt'>): MedicationModel {
    const now = new Date();
    const medication: MedicationType = {
      ...data,
      id: generateUUID(),
      createdAt: now,
      updatedAt: now
    };
    return new MedicationModel(medication);
  }

  static fromJSON(json: string): MedicationModel {
    const data = JSON.parse(json);
    return new MedicationModel({
      ...data,
      startDate: new Date(data.startDate),
      endDate: data.endDate ? new Date(data.endDate) : undefined,
      createdAt: new Date(data.createdAt),
      updatedAt: new Date(data.updatedAt)
    });
  }

  toJSON(): string {
    return JSON.stringify(this.data);
  }
}