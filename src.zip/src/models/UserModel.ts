import { User, UserProfile, UserPreferences } from '@/types';

export class UserModel {
  private data: User;

  constructor(data: User) {
    this.data = data;
  }

  // Getters
  get id(): string { return this.data.id; }
  get email(): string { return this.data.email; }
  get firstName(): string { return this.data.firstName; }
  get lastName(): string { return this.data.lastName; }
  get dateOfBirth(): Date | undefined { return this.data.dateOfBirth; }
  get timezone(): string { return this.data.timezone; }
  get isActive(): boolean { return this.data.isActive; }
  get createdAt(): Date { return this.data.createdAt; }
  get updatedAt(): Date { return this.data.updatedAt; }
  get lastLoginAt(): Date | undefined { return this.data.lastLoginAt; }

  // Get the raw data
  get rawData(): User {
    return { ...this.data };
  }

  // Business logic methods
  get fullName(): string {
    return `${this.data.firstName} ${this.data.lastName}`.trim();
  }

  get initials(): string {
    const firstInitial = this.data.firstName.charAt(0).toUpperCase();
    const lastInitial = this.data.lastName.charAt(0).toUpperCase();
    return `${firstInitial}${lastInitial}`;
  }

  get age(): number | null {
    if (!this.data.dateOfBirth) return null;
    
    const today = new Date();
    const birthDate = new Date(this.data.dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  }

  isEmailValid(): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(this.data.email);
  }

  daysSinceRegistration(): number {
    const today = new Date();
    const createdDate = new Date(this.data.createdAt);
    const timeDiff = today.getTime() - createdDate.getTime();
    return Math.floor(timeDiff / (1000 * 60 * 60 * 24));
  }

  daysSinceLastLogin(): number | null {
    if (!this.data.lastLoginAt) return null;
    
    const today = new Date();
    const lastLoginDate = new Date(this.data.lastLoginAt);
    const timeDiff = today.getTime() - lastLoginDate.getTime();
    return Math.floor(timeDiff / (1000 * 60 * 60 * 24));
  }

  isRecentlyActive(days: number = 7): boolean {
    const daysSinceLogin = this.daysSinceLastLogin();
    return daysSinceLogin !== null && daysSinceLogin <= days;
  }

  getTimezoneOffset(): number {
    // Get timezone offset in minutes from UTC
    try {
      const date = new Date();
      const userTimezone = Intl.DateTimeFormat(undefined, {
        timeZone: this.data.timezone,
        timeZoneName: 'longOffset'
      }).formatToParts(date);
      
      const offsetPart = userTimezone.find(part => part.type === 'timeZoneName');
      if (offsetPart && offsetPart.value) {
        const match = offsetPart.value.match(/GMT([+-]\d{2}):(\d{2})/);
        if (match) {
          const hours = parseInt(match[1]);
          const minutes = parseInt(match[2]);
          return hours * 60 + (hours < 0 ? -minutes : minutes);
        }
      }
    } catch (error) {
      console.warn('Unable to calculate timezone offset:', error);
    }
    return 0;
  }

  getCurrentTimeInUserTimezone(): Date {
    const now = new Date();
    try {
      return new Date(now.toLocaleString('en-US', { timeZone: this.data.timezone }));
    } catch (error) {
      console.warn('Unable to convert to user timezone:', error);
      return now;
    }
  }

  // Update methods
  update(updates: Partial<User>): UserModel {
    const updatedData = {
      ...this.data,
      ...updates,
      updatedAt: new Date()
    };
    return new UserModel(updatedData);
  }

  updateLastLogin(): UserModel {
    return this.update({ lastLoginAt: new Date() });
  }

  deactivate(): UserModel {
    return this.update({ isActive: false });
  }

  activate(): UserModel {
    return this.update({ isActive: true });
  }

  // Static factory methods
  static create(data: Omit<User, 'id' | 'createdAt' | 'updatedAt' | 'isActive'>): UserModel {
    const now = new Date();
    const user: User = {
      ...data,
      id: crypto.randomUUID(),
      isActive: true,
      createdAt: now,
      updatedAt: now
    };
    return new UserModel(user);
  }

  static fromJSON(json: string): UserModel {
    const data = JSON.parse(json);
    return new UserModel({
      ...data,
      dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth) : undefined,
      createdAt: new Date(data.createdAt),
      updatedAt: new Date(data.updatedAt),
      lastLoginAt: data.lastLoginAt ? new Date(data.lastLoginAt) : undefined
    });
  }

  toJSON(): string {
    return JSON.stringify(this.data);
  }
}

export class UserProfileModel {
  private data: UserProfile;

  constructor(data: UserProfile) {
    this.data = data;
  }

  // Getters
  get userId(): string { return this.data.userId; }
  get avatar(): string | undefined { return this.data.avatar; }
  get bio(): string | undefined { return this.data.bio; }
  get emergencyContact() { return this.data.emergencyContact; }
  get medicalInfo() { return this.data.medicalInfo; }
  get updatedAt(): Date { return this.data.updatedAt; }

  // Get the raw data
  get rawData(): UserProfile {
    return { ...this.data };
  }

  // Business logic methods
  hasEmergencyContact(): boolean {
    return !!this.data.emergencyContact && 
           !!this.data.emergencyContact.name && 
           !!this.data.emergencyContact.phone;
  }

  hasMedicalInfo(): boolean {
    return !!this.data.medicalInfo && 
           (this.data.medicalInfo.allergies.length > 0 || 
            this.data.medicalInfo.conditions.length > 0 ||
            !!this.data.medicalInfo.primaryPhysician);
  }

  hasAllergies(): boolean {
    return !!this.data.medicalInfo && this.data.medicalInfo.allergies.length > 0;
  }

  hasConditions(): boolean {
    return !!this.data.medicalInfo && this.data.medicalInfo.conditions.length > 0;
  }

  hasPrimaryPhysician(): boolean {
    return !!this.data.medicalInfo?.primaryPhysician?.name;
  }

  getCompletionPercentage(): number {
    let completed = 0;
    const total = 5; // bio, avatar, emergency contact, allergies, conditions

    if (this.data.bio) completed++;
    if (this.data.avatar) completed++;
    if (this.hasEmergencyContact()) completed++;
    if (this.hasAllergies()) completed++;
    if (this.hasConditions()) completed++;

    return Math.round((completed / total) * 100);
  }

  // Update methods
  update(updates: Partial<UserProfile>): UserProfileModel {
    const updatedData = {
      ...this.data,
      ...updates,
      updatedAt: new Date()
    };
    return new UserProfileModel(updatedData);
  }

  // Static factory methods
  static create(userId: string, data: Partial<Omit<UserProfile, 'userId' | 'updatedAt'>> = {}): UserProfileModel {
    const profile: UserProfile = {
      userId,
      ...data,
      updatedAt: new Date()
    };
    return new UserProfileModel(profile);
  }

  static fromJSON(json: string): UserProfileModel {
    const data = JSON.parse(json);
    return new UserProfileModel({
      ...data,
      updatedAt: new Date(data.updatedAt)
    });
  }

  toJSON(): string {
    return JSON.stringify(this.data);
  }
}

export class UserPreferencesModel {
  private data: UserPreferences;

  constructor(data: UserPreferences) {
    this.data = data;
  }

  // Getters
  get userId(): string { return this.data.userId; }
  get theme() { return this.data.theme; }
  get language(): string { return this.data.language; }
  get timeFormat() { return this.data.timeFormat; }
  get dateFormat() { return this.data.dateFormat; }
  get notifications() { return this.data.notifications; }
  get dashboard() { return this.data.dashboard; }
  get privacy() { return this.data.privacy; }
  get updatedAt(): Date { return this.data.updatedAt; }

  // Get the raw data
  get rawData(): UserPreferences {
    return { ...this.data };
  }

  // Business logic methods
  shouldShowNotification(type: keyof UserPreferences['notifications']): boolean {
    const value = this.data.notifications[type];
    return typeof value === 'boolean' ? value : true;
  }

  formatTime(date: Date): string {
    const options: Intl.DateTimeFormatOptions = {
      hour: 'numeric',
      minute: '2-digit',
      hour12: this.data.timeFormat === '12h'
    };
    return date.toLocaleTimeString(this.data.language, options);
  }

  formatDate(date: Date): string {
    let formatString = this.data.dateFormat;
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return formatString
      .replace('YYYY', year.toString())
      .replace('MM', month)
      .replace('DD', day);
  }

  isDarkMode(): boolean {
    if (this.data.theme === 'dark') return true;
    if (this.data.theme === 'light') return false;
    
    // System preference
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  // Update methods
  update(updates: Partial<UserPreferences>): UserPreferencesModel {
    const updatedData = {
      ...this.data,
      ...updates,
      updatedAt: new Date()
    };
    return new UserPreferencesModel(updatedData);
  }

  // Static factory methods
  static createDefault(userId: string): UserPreferencesModel {
    const preferences: UserPreferences = {
      userId,
      theme: 'system',
      language: 'en-US',
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      timeFormat: '12h',
      dateFormat: 'MM/DD/YYYY',
      notifications: {
        medication: true,
        achievements: true,
        reminders: true,
        email: false,
        push: true,
        throttleHours: 24,
        refillReminderDays: 3
      },
      dashboard: {
        defaultView: 'cards',
        showStats: true,
        showAchievements: true,
        compactMode: false
      },
      privacy: {
        shareStats: false,
        allowAnalytics: true
      },
      updatedAt: new Date()
    };
    return new UserPreferencesModel(preferences);
  }

  static fromJSON(json: string): UserPreferencesModel {
    const data = JSON.parse(json);
    return new UserPreferencesModel({
      ...data,
      updatedAt: new Date(data.updatedAt)
    });
  }

  toJSON(): string {
    return JSON.stringify(this.data);
  }
}