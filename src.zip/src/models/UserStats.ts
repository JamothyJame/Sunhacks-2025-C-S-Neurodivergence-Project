import { UserStats as UserStatsType, MedicationLog } from '@/types';

export class UserStatsModel {
  private data: UserStatsType;

  constructor(data: UserStatsType) {
    this.data = data;
  }

  // Getters
  get id(): string { return this.data.id; }
  get userId(): string { return this.data.userId; }
  get level(): number { return this.data.level; }
  get experience(): number { return this.data.experience; }
  get totalPoints(): number { return this.data.totalPoints; }
  get currentStreak(): number { return this.data.currentStreak; }
  get longestStreak(): number { return this.data.longestStreak; }
  get totalMedicationsTaken(): number { return this.data.totalMedicationsTaken; }
  get adherenceRate(): number { return this.data.adherenceRate; }
  get updatedAt(): Date { return this.data.updatedAt; }

  get rawData(): UserStatsType {
    return { ...this.data };
  }

  // Gamification calculations
  getExperienceForNextLevel(): number {
    return this.calculateExperienceRequired(this.data.level + 1);
  }

  getExperienceProgress(): number {
    const currentLevelExp = this.calculateExperienceRequired(this.data.level);
    const nextLevelExp = this.calculateExperienceRequired(this.data.level + 1);
    const progress = (this.data.experience - currentLevelExp) / (nextLevelExp - currentLevelExp);
    return Math.max(0, Math.min(1, progress));
  }

  private calculateExperienceRequired(level: number): number {
    // Exponential growth: each level requires 100 * (level^1.5) experience
    return Math.floor(100 * Math.pow(level, 1.5));
  }

  // Points and level management
  addPoints(points: number): UserStatsModel {
    const newExperience = this.data.experience + points;
    const newTotalPoints = this.data.totalPoints + points;
    let newLevel = this.data.level;

    // Check for level up
    while (newExperience >= this.calculateExperienceRequired(newLevel + 1)) {
      newLevel++;
    }

    return new UserStatsModel({
      ...this.data,
      experience: newExperience,
      totalPoints: newTotalPoints,
      level: newLevel,
      updatedAt: new Date()
    });
  }

  // Streak management
  updateStreak(logs: MedicationLog[]): UserStatsModel {
    const streak = this.calculateCurrentStreak(logs);
    const longestStreak = Math.max(this.data.longestStreak, streak);

    return new UserStatsModel({
      ...this.data,
      currentStreak: streak,
      longestStreak,
      updatedAt: new Date()
    });
  }

  private calculateCurrentStreak(logs: MedicationLog[]): number {
    const today = new Date();
    const sortedLogs = logs
      .filter(log => log.status === 'taken')
      .sort((a, b) => b.actualTime!.getTime() - a.actualTime!.getTime());

    if (sortedLogs.length === 0) return 0;

    let streak = 0;
    let currentDate = new Date(today);
    currentDate.setHours(0, 0, 0, 0);

    // Check each day backwards
    for (let i = 0; i < 365; i++) { // Max 365 days
      const dayLogs = sortedLogs.filter(log => {
        const logDate = new Date(log.actualTime!);
        logDate.setHours(0, 0, 0, 0);
        return logDate.getTime() === currentDate.getTime();
      });

      if (dayLogs.length > 0) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }

    return streak;
  }

  // Adherence rate calculation
  updateAdherenceRate(logs: MedicationLog[], totalScheduledDoses: number): UserStatsModel {
    const recentLogs = logs.filter(log => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return log.scheduledTime >= thirtyDaysAgo;
    });

    const takenCount = recentLogs.filter(log => log.status === 'taken').length;
    const adherenceRate = totalScheduledDoses > 0 ? (takenCount / totalScheduledDoses) * 100 : 0;

    return new UserStatsModel({
      ...this.data,
      adherenceRate: Math.round(adherenceRate * 100) / 100, // Round to 2 decimal places
      updatedAt: new Date()
    });
  }

  // Update total medications taken
  updateTotalMedicationsTaken(logs: MedicationLog[]): UserStatsModel {
    const totalTaken = logs.filter(log => log.status === 'taken').length;

    return new UserStatsModel({
      ...this.data,
      totalMedicationsTaken: totalTaken,
      updatedAt: new Date()
    });
  }

  // Comprehensive update based on all logs
  updateFromLogs(logs: MedicationLog[], totalScheduledDoses: number): UserStatsModel {
    return this
      .updateStreak(logs)
      .updateAdherenceRate(logs, totalScheduledDoses)
      .updateTotalMedicationsTaken(logs);
  }

  // Achievement checks
  meetsStreakRequirement(days: number): boolean {
    return this.data.currentStreak >= days;
  }

  meetsTotalTakenRequirement(count: number): boolean {
    return this.data.totalMedicationsTaken >= count;
  }

  meetsAdherenceRequirement(percentage: number): boolean {
    return this.data.adherenceRate >= percentage;
  }

  meetsDaysActiveRequirement(days: number): boolean {
    const daysSinceCreation = Math.floor(
      (new Date().getTime() - this.data.updatedAt.getTime()) / (1000 * 60 * 60 * 24)
    );
    return daysSinceCreation >= days;
  }

  // Level rewards
  getLevelRewards(): { points: number; title: string } {
    const rewards = [
      { level: 1, points: 50, title: 'Beginner' },
      { level: 5, points: 100, title: 'Committed' },
      { level: 10, points: 200, title: 'Dedicated' },
      { level: 15, points: 300, title: 'Expert' },
      { level: 20, points: 500, title: 'Master' },
      { level: 30, points: 750, title: 'Champion' },
      { level: 50, points: 1000, title: 'Legend' }
    ];

    const reward = rewards.find(r => r.level === this.data.level);
    return reward || { points: 0, title: 'Newcomer' };
  }

  // Static factory methods
  static create(userId: string): UserStatsModel {
    const stats: UserStatsType = {
      id: crypto.randomUUID(),
      userId,
      level: 1,
      experience: 0,
      totalPoints: 0,
      currentStreak: 0,
      longestStreak: 0,
      totalMedicationsTaken: 0,
      adherenceRate: 0,
      updatedAt: new Date()
    };
    return new UserStatsModel(stats);
  }

  static fromJSON(json: string): UserStatsModel {
    const data = JSON.parse(json);
    return new UserStatsModel({
      ...data,
      updatedAt: new Date(data.updatedAt)
    });
  }

  toJSON(): string {
    return JSON.stringify(this.data);
  }
}