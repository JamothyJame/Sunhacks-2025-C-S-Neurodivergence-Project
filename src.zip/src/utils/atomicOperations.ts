/**
 * Atomic Operations Utility
 * Provides mechanisms to prevent race conditions in database operations
 */

/**
 * Simple semaphore implementation for preventing concurrent operations
 */
class Semaphore {
  private permits: number;
  private waitQueue: (() => void)[] = [];

  constructor(initialPermits: number) {
    this.permits = initialPermits;
  }

  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return Promise.resolve();
    }

    return new Promise<void>((resolve) => {
      this.waitQueue.push(resolve);
    });
  }

  release(): void {
    this.permits++;
    if (this.waitQueue.length > 0) {
      const resolve = this.waitQueue.shift()!;
      this.permits--;
      resolve();
    }
  }
}

/**
 * Mutex implementation for exclusive access
 */
class Mutex {
  private semaphore = new Semaphore(1);

  async acquire(): Promise<void> {
    return this.semaphore.acquire();
  }

  release(): void {
    this.semaphore.release();
  }

  async withLock<T>(operation: () => Promise<T>): Promise<T> {
    await this.acquire();
    try {
      return await operation();
    } finally {
      this.release();
    }
  }
}

/**
 * Global mutex instances for different resources
 */
const mutexes = new Map<string, Mutex>();

/**
 * Get or create a mutex for a specific resource
 */
function getMutex(resourceId: string): Mutex {
  if (!mutexes.has(resourceId)) {
    mutexes.set(resourceId, new Mutex());
  }
  return mutexes.get(resourceId)!;
}

/**
 * Execute an operation with exclusive access to a resource
 */
export async function withMutex<T>(
  resourceId: string,
  operation: () => Promise<T>
): Promise<T> {
  const mutex = getMutex(resourceId);
  return mutex.withLock(operation);
}

/**
 * Optimistic locking implementation using timestamps
 */
export interface VersionedRecord {
  id: string;
  version: number;
  updatedAt: Date;
}

export class OptimisticLockError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OptimisticLockError';
  }
}

/**
 * Update a record with optimistic locking
 */
export async function updateWithOptimisticLock<T extends VersionedRecord>(
  currentRecord: T,
  updateFn: (record: T) => T,
  saveFn: (record: T) => Promise<T>,
  getFreshRecordFn: (id: string) => Promise<T | null>
): Promise<T> {
  // Get fresh record to check version
  const freshRecord = await getFreshRecordFn(currentRecord.id);
  
  if (!freshRecord) {
    throw new OptimisticLockError('Record no longer exists');
  }

  // Check if record was modified since we last read it
  if (freshRecord.version !== currentRecord.version) {
    throw new OptimisticLockError(
      'Record was modified by another operation. Please refresh and try again.'
    );
  }

  // Apply updates and increment version
  const updatedRecord = updateFn({
    ...freshRecord,
    version: freshRecord.version + 1,
    updatedAt: new Date()
  });

  // Save the updated record
  return await saveFn(updatedRecord);
}

/**
 * Retry mechanism with exponential backoff
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 100,
  backoffFactor: number = 2
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      
      // Don't retry if it's the last attempt
      if (attempt === maxRetries) {
        break;
      }

      // Don't retry for certain error types
      if (error instanceof OptimisticLockError) {
        throw error;
      }

      // Calculate delay with exponential backoff
      const delay = baseDelayMs * Math.pow(backoffFactor, attempt);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError!;
}

/**
 * Debounce function calls to prevent rapid successive calls
 */
const debounceTimers = new Map<string, NodeJS.Timeout>();

export function debounce<T extends any[]>(
  key: string,
  func: (...args: T) => Promise<void>,
  delayMs: number = 500
): (...args: T) => void {
  return (...args: T) => {
    // Clear existing timer
    const existingTimer = debounceTimers.get(key);
    if (existingTimer) {
      clearTimeout(existingTimer);
    }

    // Set new timer
    const timer = setTimeout(() => {
      debounceTimers.delete(key);
      func(...args).catch(console.error);
    }, delayMs);

    debounceTimers.set(key, timer);
  };
}

/**
 * Queue for sequential execution of operations
 */
class OperationQueue {
  private queue: (() => Promise<any>)[] = [];
  private processing = false;

  async add<T>(operation: () => Promise<T>): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.queue.push(async () => {
        try {
          const result = await operation();
          resolve(result);
        } catch (error) {
          reject(error);
        }
      });

      this.processQueue();
    });
  }

  private async processQueue(): Promise<void> {
    if (this.processing || this.queue.length === 0) {
      return;
    }

    this.processing = true;

    while (this.queue.length > 0) {
      const operation = this.queue.shift()!;
      try {
        await operation();
      } catch (error) {
        console.error('Queue operation failed:', error);
      }
    }

    this.processing = false;
  }
}

/**
 * Global operation queues for different resources
 */
const operationQueues = new Map<string, OperationQueue>();

/**
 * Get or create an operation queue for a specific resource
 */
function getOperationQueue(resourceId: string): OperationQueue {
  if (!operationQueues.has(resourceId)) {
    operationQueues.set(resourceId, new OperationQueue());
  }
  return operationQueues.get(resourceId)!;
}

/**
 * Execute operation in a sequential queue for a resource
 */
export async function withQueue<T>(
  resourceId: string,
  operation: () => Promise<T>
): Promise<T> {
  const queue = getOperationQueue(resourceId);
  return queue.add(operation);
}

/**
 * Combine multiple atomic operations into a single transaction-like operation
 */
export async function atomic<T>(
  operations: (() => Promise<any>)[],
  rollbackOperations?: (() => Promise<any>)[]
): Promise<T[]> {
  const results: any[] = [];
  const completedOperations: number[] = [];

  try {
    for (let i = 0; i < operations.length; i++) {
      const result = await operations[i]();
      results.push(result);
      completedOperations.push(i);
    }
    return results;
  } catch (error) {
    // Rollback completed operations in reverse order
    if (rollbackOperations && rollbackOperations.length >= completedOperations.length) {
      for (let i = completedOperations.length - 1; i >= 0; i--) {
        const rollbackIndex = completedOperations[i];
        try {
          await rollbackOperations[rollbackIndex]();
        } catch (rollbackError) {
          console.error(`Rollback operation ${rollbackIndex} failed:`, rollbackError);
        }
      }
    }
    throw error;
  }
}

/**
 * Clean up resources on app shutdown
 */
export function cleanup(): void {
  // Clear all debounce timers
  debounceTimers.forEach((timer) => {
    clearTimeout(timer);
  });
  debounceTimers.clear();

  // Clear mutex and queue maps
  mutexes.clear();
  operationQueues.clear();
}