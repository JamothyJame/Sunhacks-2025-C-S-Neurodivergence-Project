/**
 * Input Sanitization Utility
 * Provides comprehensive input sanitization to prevent XSS vulnerabilities
 */

/**
 * HTML entities for encoding dangerous characters
 */
const HTML_ENTITIES: Record<string, string> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#x27;',
  '/': '&#x2F;',
  '`': '&#96;',
  '=': '&#61;'
};

/**
 * Characters that are potentially dangerous in different contexts
 */
const DANGEROUS_CHARS = /[&<>"'`=/]/g;
const SCRIPT_TAGS = /<script[\s\S]*?>[\s\S]*?<\/script>/gi;
const ON_EVENT_HANDLERS = /on\w+\s*=/gi;
const JAVASCRIPT_URLS = /javascript:/gi;
const DATA_URLS = /data:/gi;
const VBSCRIPT_URLS = /vbscript:/gi;

/**
 * Sanitize HTML string by encoding dangerous characters
 */
export function sanitizeHTML(input: string): string {
  if (typeof input !== 'string') {
    return String(input);
  }

  return input.replace(DANGEROUS_CHARS, match => HTML_ENTITIES[match] || match);
}

/**
 * Remove potentially dangerous HTML tags and attributes
 */
export function stripDangerousHTML(input: string): string {
  if (typeof input !== 'string') {
    return String(input);
  }

  return input
    .replace(SCRIPT_TAGS, '') // Remove script tags
    .replace(ON_EVENT_HANDLERS, '') // Remove event handlers
    .replace(JAVASCRIPT_URLS, '') // Remove javascript: URLs
    .replace(DATA_URLS, '') // Remove data: URLs
    .replace(VBSCRIPT_URLS, ''); // Remove vbscript: URLs
}

/**
 * Sanitize user text input (medication names, notes, etc.)
 */
export function sanitizeText(input: string, maxLength: number = 1000): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim() // Remove leading/trailing whitespace
    .slice(0, maxLength) // Limit length
    .replace(/[\r\n]/g, ' ') // Replace newlines with spaces
    .replace(/\s+/g, ' ') // Normalize multiple spaces
    .replace(DANGEROUS_CHARS, match => HTML_ENTITIES[match] || match); // Encode dangerous chars
}

/**
 * Sanitize medication name input
 */
export function sanitizeMedicationName(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim()
    .slice(0, 200) // Medication names shouldn't be too long
    .replace(/[<>]/g, '') // Remove angle brackets completely
    .replace(/['"]/g, '') // Remove quotes
    .replace(/\s+/g, ' '); // Normalize spaces
}

/**
 * Sanitize dosage input
 */
export function sanitizeDosage(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim()
    .slice(0, 50) // Dosages should be short
    .replace(/[<>"']/g, '') // Remove dangerous HTML chars
    .replace(/[^\w\s.,/()-]/g, ''); // Allow only alphanumeric, spaces, and common dosage chars
}

/**
 * Sanitize notes/comments input
 */
export function sanitizeNotes(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim()
    .slice(0, 500) // Limit note length
    .replace(SCRIPT_TAGS, '') // Remove script tags
    .replace(ON_EVENT_HANDLERS, '') // Remove event handlers
    .replace(/[<>]/g, match => HTML_ENTITIES[match]); // Encode angle brackets
}

/**
 * Sanitize email input
 */
export function sanitizeEmail(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim()
    .toLowerCase()
    .slice(0, 254) // RFC 5321 limit
    .replace(/[<>"']/g, ''); // Remove dangerous chars
}

/**
 * Sanitize name input (first name, last name)
 */
export function sanitizeName(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .trim()
    .slice(0, 50) // Names shouldn't be too long
    .replace(/[<>"']/g, '') // Remove dangerous HTML chars
    .replace(/[^\w\s'-]/g, ''); // Allow only letters, spaces, hyphens, apostrophes
}

/**
 * Sanitize numeric input
 */
export function sanitizeNumber(input: string | number, allowDecimals: boolean = true): number | null {
  if (typeof input === 'number') {
    return isNaN(input) ? null : input;
  }

  if (typeof input !== 'string') {
    return null;
  }

  // Remove any non-numeric characters except decimal point if allowed
  const sanitized = allowDecimals 
    ? input.replace(/[^\d.-]/g, '')
    : input.replace(/[^\d-]/g, '');

  const number = parseFloat(sanitized);
  return isNaN(number) ? null : number;
}

/**
 * Sanitize time input (HH:MM format)
 */
export function sanitizeTime(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  // Only allow digits and colon
  const sanitized = input.replace(/[^\d:]/g, '');
  
  // Validate format
  const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  if (!timeRegex.test(sanitized)) {
    return '';
  }

  return sanitized;
}

/**
 * Sanitize URL input
 */
export function sanitizeURL(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  const trimmed = input.trim();
  
  // Block dangerous protocols
  if (JAVASCRIPT_URLS.test(trimmed) || 
      DATA_URLS.test(trimmed) || 
      VBSCRIPT_URLS.test(trimmed)) {
    return '';
  }

  return trimmed.slice(0, 2048); // URL length limit
}

/**
 * Sanitize JSON input before parsing
 */
export function sanitizeJSON(input: string): string {
  if (typeof input !== 'string') {
    return '{}';
  }

  // Remove potential script injections
  return input
    .replace(SCRIPT_TAGS, '')
    .replace(ON_EVENT_HANDLERS, '')
    .replace(JAVASCRIPT_URLS, '')
    .slice(0, 1048576); // 1MB limit for JSON
}

/**
 * Deep sanitize an object recursively
 */
export function deepSanitizeObject(obj: any, maxDepth: number = 10): any {
  if (maxDepth <= 0) {
    return null;
  }

  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj === 'string') {
    return sanitizeText(obj);
  }

  if (typeof obj === 'number' || typeof obj === 'boolean') {
    return obj;
  }

  if (obj instanceof Date) {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj
      .slice(0, 1000) // Limit array size
      .map(item => deepSanitizeObject(item, maxDepth - 1));
  }

  if (typeof obj === 'object') {
    const sanitized: any = {};
    const keys = Object.keys(obj).slice(0, 100); // Limit number of keys
    
    for (const key of keys) {
      const sanitizedKey = sanitizeText(key, 100);
      if (sanitizedKey) {
        sanitized[sanitizedKey] = deepSanitizeObject(obj[key], maxDepth - 1);
      }
    }
    
    return sanitized;
  }

  return null;
}

/**
 * Validate and sanitize form data
 */
export function sanitizeFormData(formData: Record<string, any>): Record<string, any> {
  const sanitized: Record<string, any> = {};

  for (const [key, value] of Object.entries(formData)) {
    const sanitizedKey = sanitizeText(key, 50);
    
    if (!sanitizedKey) continue;

    switch (sanitizedKey.toLowerCase()) {
      case 'name':
      case 'firstname':
      case 'lastname':
        sanitized[sanitizedKey] = sanitizeName(String(value));
        break;
        
      case 'email':
        sanitized[sanitizedKey] = sanitizeEmail(String(value));
        break;
        
      case 'medicationname':
      case 'genericname':
        sanitized[sanitizedKey] = sanitizeMedicationName(String(value));
        break;
        
      case 'dosage':
        sanitized[sanitizedKey] = sanitizeDosage(String(value));
        break;
        
      case 'notes':
      case 'comment':
      case 'description':
        sanitized[sanitizedKey] = sanitizeNotes(String(value));
        break;
        
      case 'frequency':
      case 'supply':
      case 'refills':
      case 'pillsperdose':
        sanitized[sanitizedKey] = sanitizeNumber(value, false);
        break;
        
      case 'times':
        if (Array.isArray(value)) {
          sanitized[sanitizedKey] = value
            .map(time => sanitizeTime(String(time)))
            .filter(time => time !== '');
        }
        break;
        
      default:
        if (typeof value === 'string') {
          sanitized[sanitizedKey] = sanitizeText(value);
        } else {
          sanitized[sanitizedKey] = deepSanitizeObject(value, 5);
        }
    }
  }

  return sanitized;
}

/**
 * Remove all potentially dangerous content (nuclear option)
 */
export function stripAllHTML(input: string): string {
  if (typeof input !== 'string') {
    return '';
  }

  return input
    .replace(/<[^>]*>/g, '') // Remove all HTML tags
    .replace(/&\w+;/g, '') // Remove HTML entities
    .replace(/[<>"'&]/g, '') // Remove remaining dangerous chars
    .trim();
}