type AsyncFn<T> = () => Promise<T>;

class RequestDeduplicator {
  private inFlight = new Map<string, Promise<any>>();

  run<T>(key: string, fn: AsyncFn<T>): Promise<T> {
    if (this.inFlight.has(key)) {
      return this.inFlight.get(key) as Promise<T>;
    }
    const promise = fn().finally(() => {
      // Only clear after microtask to allow awaiting callers to get the same promise
      setTimeout(() => this.inFlight.delete(key), 0);
    });
    this.inFlight.set(key, promise as Promise<any>);
    return promise;
  }

  clear(key?: string) {
    if (key) {
      this.inFlight.delete(key);
    } else {
      this.inFlight.clear();
    }
  }
}

export const requestDeduplicator = new RequestDeduplicator();