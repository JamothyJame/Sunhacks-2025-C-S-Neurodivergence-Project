/**
 * Date Utilities
 * Standardized date handling throughout the MedTracker application
 * Uses ISO 8601 format for consistency and timezone safety
 */

/**
 * Standard date format for the application - ISO 8601
 */
export const DATE_FORMAT = 'ISO';
export const TIME_FORMAT_12H = '12h';
export const TIME_FORMAT_24H = '24h';

/**
 * Get current date in ISO string format
 */
export function getCurrentDateISO(): string {
  return new Date().toISOString();
}

/**
 * Get current date as Date object
 */
export function getCurrentDate(): Date {
  return new Date();
}

/**
 * Parse date from various formats to Date object
 * Handles ISO strings, timestamps, and existing Date objects
 */
export function parseDate(input: string | number | Date | null | undefined): Date | null {
  if (!input) {
    return null;
  }

  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }

  if (typeof input === 'string') {
    const parsed = new Date(input);
    return isNaN(parsed.getTime()) ? null : parsed;
  }

  if (typeof input === 'number') {
    const parsed = new Date(input);
    return isNaN(parsed.getTime()) ? null : parsed;
  }

  return null;
}

/**
 * Convert date to ISO string format
 */
export function formatDateToISO(date: Date | string | null | undefined): string | null {
  const parsed = parseDate(date);
  return parsed ? parsed.toISOString() : null;
}

/**
 * Create date from date and time components
 */
export function createDateFromTimeString(timeString: string, baseDate?: Date): Date {
  const base = baseDate || new Date();
  const [hours, minutes] = timeString.split(':').map(Number);
  
  const date = new Date(base);
  date.setHours(hours, minutes, 0, 0);
  
  return date;
}

/**
 * Extract time string (HH:MM) from Date object
 */
export function extractTimeString(date: Date | string): string {
  const parsed = parseDate(date);
  if (!parsed) return '00:00';
  
  const hours = parsed.getHours().toString().padStart(2, '0');
  const minutes = parsed.getMinutes().toString().padStart(2, '0');
  
  return `${hours}:${minutes}`;
}

/**
 * Format date for display based on user preferences
 */
export function formatDateForDisplay(
  date: Date | string | null,
  format: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD' = 'MM/DD/YYYY',
  timezone?: string
): string {
  const parsed = parseDate(date);
  if (!parsed) return '';

  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    timeZone: timezone
  };

  const formatted = parsed.toLocaleDateString('en-US', options);
  const [month, day, year] = formatted.split('/');

  switch (format) {
    case 'DD/MM/YYYY':
      return `${day}/${month}/${year}`;
    case 'YYYY-MM-DD':
      return `${year}-${month}-${day}`;
    case 'MM/DD/YYYY':
    default:
      return formatted;
  }
}

/**
 * Format time for display based on user preferences
 */
export function formatTimeForDisplay(
  date: Date | string | null,
  format: '12h' | '24h' = '12h',
  timezone?: string
): string {
  const parsed = parseDate(date);
  if (!parsed) return '';

  const options: Intl.DateTimeFormatOptions = {
    hour: '2-digit',
    minute: '2-digit',
    hour12: format === '12h',
    timeZone: timezone
  };

  return parsed.toLocaleTimeString('en-US', options);
}

/**
 * Format datetime for display
 */
export function formatDateTimeForDisplay(
  date: Date | string | null,
  dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD' = 'MM/DD/YYYY',
  timeFormat: '12h' | '24h' = '12h',
  timezone?: string
): string {
  const dateStr = formatDateForDisplay(date, dateFormat, timezone);
  const timeStr = formatTimeForDisplay(date, timeFormat, timezone);
  
  return dateStr && timeStr ? `${dateStr} ${timeStr}` : '';
}

/**
 * Get start of day in timezone
 */
export function getStartOfDay(date: Date | string, timezone?: string): Date {
  const parsed = parseDate(date) || new Date();
  
  if (timezone) {
    // Create date at start of day in the specified timezone
    const dateStr = formatDateForDisplay(parsed, 'YYYY-MM-DD', timezone);
    return new Date(`${dateStr}T00:00:00.000Z`);
  }
  
  const startOfDay = new Date(parsed);
  startOfDay.setHours(0, 0, 0, 0);
  return startOfDay;
}

/**
 * Get end of day in timezone
 */
export function getEndOfDay(date: Date | string, timezone?: string): Date {
  const parsed = parseDate(date) || new Date();
  
  if (timezone) {
    // Create date at end of day in the specified timezone
    const dateStr = formatDateForDisplay(parsed, 'YYYY-MM-DD', timezone);
    return new Date(`${dateStr}T23:59:59.999Z`);
  }
  
  const endOfDay = new Date(parsed);
  endOfDay.setHours(23, 59, 59, 999);
  return endOfDay;
}

/**
 * Add days to a date
 */
export function addDays(date: Date | string, days: number): Date {
  const parsed = parseDate(date) || new Date();
  const result = new Date(parsed);
  result.setDate(result.getDate() + days);
  return result;
}

/**
 * Add hours to a date
 */
export function addHours(date: Date | string, hours: number): Date {
  const parsed = parseDate(date) || new Date();
  const result = new Date(parsed);
  result.setHours(result.getHours() + hours);
  return result;
}

/**
 * Add minutes to a date
 */
export function addMinutes(date: Date | string, minutes: number): Date {
  const parsed = parseDate(date) || new Date();
  const result = new Date(parsed);
  result.setMinutes(result.getMinutes() + minutes);
  return result;
}

/**
 * Calculate difference in days between two dates
 */
export function daysBetween(date1: Date | string, date2: Date | string): number {
  const d1 = parseDate(date1);
  const d2 = parseDate(date2);
  
  if (!d1 || !d2) return 0;
  
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Calculate difference in hours between two dates
 */
export function hoursBetween(date1: Date | string, date2: Date | string): number {
  const d1 = parseDate(date1);
  const d2 = parseDate(date2);
  
  if (!d1 || !d2) return 0;
  
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.floor(diffTime / (1000 * 60 * 60));
}

/**
 * Check if two dates are on the same day
 */
export function isSameDay(date1: Date | string, date2: Date | string, timezone?: string): boolean {
  const d1 = parseDate(date1);
  const d2 = parseDate(date2);
  
  if (!d1 || !d2) return false;
  
  if (timezone) {
    const format1 = formatDateForDisplay(d1, 'YYYY-MM-DD', timezone);
    const format2 = formatDateForDisplay(d2, 'YYYY-MM-DD', timezone);
    return format1 === format2;
  }
  
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
}

/**
 * Check if date is today
 */
export function isToday(date: Date | string, timezone?: string): boolean {
  return isSameDay(date, new Date(), timezone);
}

/**
 * Check if date is in the past
 */
export function isPast(date: Date | string): boolean {
  const parsed = parseDate(date);
  if (!parsed) return false;
  
  return parsed.getTime() < Date.now();
}

/**
 * Check if date is in the future
 */
export function isFuture(date: Date | string): boolean {
  const parsed = parseDate(date);
  if (!parsed) return false;
  
  return parsed.getTime() > Date.now();
}

/**
 * Get relative time description (e.g., "2 hours ago", "in 3 days")
 */
export function getRelativeTime(date: Date | string): string {
  const parsed = parseDate(date);
  if (!parsed) return '';
  
  const now = new Date();
  const diffMs = parsed.getTime() - now.getTime();
  const diffMinutes = Math.floor(Math.abs(diffMs) / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  const isPast = diffMs < 0;
  const suffix = isPast ? 'ago' : 'from now';
  
  if (diffMinutes < 1) {
    return 'just now';
  } else if (diffMinutes < 60) {
    return `${diffMinutes} minute${diffMinutes !== 1 ? 's' : ''} ${suffix}`;
  } else if (diffHours < 24) {
    return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ${suffix}`;
  } else {
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ${suffix}`;
  }
}

/**
 * Validate time string format (HH:MM)
 */
export function isValidTimeString(timeString: string): boolean {
  const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  return timeRegex.test(timeString);
}

/**
 * Get timezone offset in minutes
 */
export function getTimezoneOffset(timezone?: string): number {
  if (!timezone) {
    return new Date().getTimezoneOffset();
  }
  
  // This is a simplified approach - in production you might want to use a library like date-fns-tz
  try {
    const now = new Date();
    const localTime = now.getTime();
    const localOffset = now.getTimezoneOffset() * 60000;
    const utcTime = localTime + localOffset;
    
    const targetTime = new Date(utcTime + (getTimezoneOffsetMinutes(timezone) * 60000));
    return targetTime.getTimezoneOffset();
  } catch {
    return new Date().getTimezoneOffset();
  }
}

/**
 * Helper function to get timezone offset in minutes
 */
function getTimezoneOffsetMinutes(timezone: string): number {
  // Common timezone mappings - in production, use a proper timezone library
  const timezoneOffsets: Record<string, number> = {
    'America/New_York': -300, // EST/EDT
    'America/Chicago': -360,  // CST/CDT
    'America/Denver': -420,   // MST/MDT
    'America/Los_Angeles': -480, // PST/PDT
    'Europe/London': 0,       // GMT/BST
    'Europe/Paris': 60,       // CET/CEST
    'Asia/Tokyo': 540,        // JST
    'Asia/Shanghai': 480,     // CST
    'Australia/Sydney': 600,  // AEST/AEDT
  };
  
  return timezoneOffsets[timezone] || 0;
}

/**
 * Migrate date field from any format to ISO string
 */
export function migrateDateToISO(value: any): string | null {
  const parsed = parseDate(value);
  return parsed ? parsed.toISOString() : null;
}

/**
 * Batch migrate object with date fields to ISO format
 */
export function migrateDatesInObject<T extends Record<string, any>>(
  obj: T,
  dateFields: (keyof T)[]
): T {
  const migrated = { ...obj };
  
  for (const field of dateFields) {
    if (migrated[field] !== null && migrated[field] !== undefined) {
      const migatedDate = migrateDateToISO(migrated[field]);
      if (migatedDate) {
        migrated[field] = migatedDate as T[keyof T];
      }
    }
  }
  
  return migrated;
}