import { useState, useEffect, useCallback } from 'react';
import { sanitizeFormData } from '@/utils/sanitization';
import { ErrorService, ValidationRule, ValidationError } from '@/services/ErrorService';

export interface FormFieldError {
  field: string;
  message: string;
  severity: 'error' | 'warning' | 'info';
}

export interface FormValidationState {
  isValid: boolean;
  isSubmitting: boolean;
  errors: FormFieldError[];
  touched: Set<string>;
  hasBeenSubmitted: boolean;
}

export interface UseFormValidationOptions {
  validateOnChange?: boolean;
  validateOnBlur?: boolean;
  debounceMs?: number;
  sanitizeInputs?: boolean;
}

export const useFormValidation = <T extends Record<string, any>>(
  initialData: T,
  validationRules: ValidationRule[],
  options: UseFormValidationOptions = {}
) => {
  const {
    validateOnChange = true,
    validateOnBlur = true,
    debounceMs = 300,
    sanitizeInputs = true
  } = options;

  const [data, setData] = useState<T>(initialData);
  const [validationState, setValidationState] = useState<FormValidationState>({
    isValid: false,
    isSubmitting: false,
    errors: [],
    touched: new Set(),
    hasBeenSubmitted: false
  });

  const errorService = ErrorService.getInstance();

  // Debounce validation
  const [validationTimeout, setValidationTimeout] = useState<NodeJS.Timeout | null>(null);

  const validateField = useCallback((fieldName: string, value: any): FormFieldError[] => {
    const fieldRules = validationRules.filter(rule => rule.field === fieldName);
    const fieldErrors: FormFieldError[] = [];

    for (const rule of fieldRules) {
      try {
        errorService.validateInput({ [fieldName]: value }, [rule]);
      } catch (error) {
        if (error instanceof ValidationError) {
          fieldErrors.push({
            field: fieldName,
            message: error.userMessage,
            severity: 'error'
          });
        }
      }
    }

    // Custom field-specific validations
    if (fieldName === 'currentSupply' && value) {
      const supply = parseInt(value);
      if (supply > 10000) {
        fieldErrors.push({
          field: fieldName,
          message: 'Supply seems unusually high. Please double-check this number.',
          severity: 'warning'
        });
      }
    }

    if (fieldName === 'times' && Array.isArray(value)) {
      const times = value.filter(Boolean);
      const uniqueTimes = new Set(times);
      if (times.length !== uniqueTimes.size) {
        fieldErrors.push({
          field: fieldName,
          message: 'Duplicate medication times detected.',
          severity: 'warning'
        });
      }
    }

    return fieldErrors;
  }, [validationRules, errorService]);

  const validateAllFields = useCallback((): FormFieldError[] => {
    const allErrors: FormFieldError[] = [];

    // Validate individual fields
    Object.keys(data).forEach(fieldName => {
      const fieldErrors = validateField(fieldName, data[fieldName]);
      allErrors.push(...fieldErrors);
    });

    // Cross-field validations
    if (data.endDate && data.startDate) {
      const startDate = new Date(data.startDate);
      const endDate = new Date(data.endDate);
      
      if (endDate <= startDate) {
        allErrors.push({
          field: 'endDate',
          message: 'End date must be after start date.',
          severity: 'error'
        });
      }
    }

    // Supply vs frequency validation
    if (data.currentSupply && data.frequency && data.pillsPerDose) {
      const supply = parseInt(data.currentSupply);
      const frequency = parseInt(data.frequency);
      const pillsPerDose = parseInt(data.pillsPerDose);
      const daysRemaining = Math.floor(supply / (frequency * pillsPerDose));

      if (daysRemaining < 1) {
        allErrors.push({
          field: 'currentSupply',
          message: 'Current supply is less than one day. Please verify your numbers.',
          severity: 'error'
        });
      } else if (daysRemaining > 365) {
        allErrors.push({
          field: 'currentSupply',
          message: 'Supply calculation shows more than a year remaining. Please verify.',
          severity: 'warning'
        });
      }
    }

    return allErrors;
  }, [data, validateField]);

  const debouncedValidation = useCallback((fieldName?: string) => {
    if (validationTimeout) {
      clearTimeout(validationTimeout);
    }

    const timeout = setTimeout(() => {
      let errors: FormFieldError[] = [];
      
      if (fieldName) {
        // Validate specific field
        const fieldErrors = validateField(fieldName, data[fieldName]);
        const otherErrors = validationState.errors.filter(error => error.field !== fieldName);
        errors = [...otherErrors, ...fieldErrors];
      } else {
        // Validate all fields
        errors = validateAllFields();
      }

      const hasErrors = errors.some(error => error.severity === 'error');

      setValidationState(prev => ({
        ...prev,
        errors,
        isValid: !hasErrors && validationState.hasBeenSubmitted
      }));
    }, debounceMs);

    setValidationTimeout(timeout);
  }, [data, validateField, validateAllFields, validationState.errors, validationState.hasBeenSubmitted, validationTimeout, debounceMs]);

  // Update field value
  const updateField = useCallback((fieldName: string, value: any) => {
    let processedValue = value;

    // Sanitize input if enabled
    if (sanitizeInputs) {
      const sanitizedData = sanitizeFormData({ [fieldName]: value });
      processedValue = sanitizedData[fieldName] || value;
    }

    setData(prev => ({
      ...prev,
      [fieldName]: processedValue
    }));

    // Mark field as touched
    setValidationState(prev => ({
      ...prev,
      touched: new Set([...prev.touched, fieldName])
    }));

    // Validate on change if enabled
    if (validateOnChange && (validationState.touched.has(fieldName) || validationState.hasBeenSubmitted)) {
      debouncedValidation(fieldName);
    }
  }, [errorService, sanitizeInputs, validateOnChange, validationState.touched, validationState.hasBeenSubmitted, debouncedValidation]);

  // Handle field blur
  const onFieldBlur = useCallback((fieldName: string) => {
    setValidationState(prev => ({
      ...prev,
      touched: new Set([...prev.touched, fieldName])
    }));

    // Validate on blur if enabled
    if (validateOnBlur) {
      debouncedValidation(fieldName);
    }
  }, [validateOnBlur, debouncedValidation]);

  // Get field props for easy integration with form components
  const getFieldProps = useCallback((fieldName: string) => {
    const fieldErrors = validationState.errors.filter(error => error.field === fieldName);
    const hasError = fieldErrors.some(error => error.severity === 'error');
    const hasWarning = fieldErrors.some(error => error.severity === 'warning');
    const isTouched = validationState.touched.has(fieldName);

    return {
      value: data[fieldName] || '',
      onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        updateField(fieldName, e.target.value);
      },
      onBlur: () => onFieldBlur(fieldName),
      className: `input-field ${
        isTouched || validationState.hasBeenSubmitted
          ? hasError
            ? 'border-red-500 focus:border-red-500 focus:ring-red-200'
            : hasWarning
            ? 'border-yellow-500 focus:border-yellow-500 focus:ring-yellow-200'
            : 'border-green-500 focus:border-green-500 focus:ring-green-200'
          : ''
      }`,
      'aria-invalid': hasError,
      'aria-describedby': fieldErrors.length > 0 ? `${fieldName}-error` : undefined
    };
  }, [data, validationState, updateField, onFieldBlur]);

  // Get error message for a field
  const getFieldError = useCallback((fieldName: string): FormFieldError | null => {
    const fieldErrors = validationState.errors.filter(error => error.field === fieldName);
    return fieldErrors.find(error => error.severity === 'error') || 
           fieldErrors.find(error => error.severity === 'warning') || 
           fieldErrors.find(error => error.severity === 'info') || 
           null;
  }, [validationState.errors]);

  // Submit form with validation
  const handleSubmit = useCallback(async (onSubmit: (data: T) => Promise<void>) => {
    setValidationState(prev => ({
      ...prev,
      isSubmitting: true,
      hasBeenSubmitted: true
    }));

    try {
      // Final validation
      const errors = validateAllFields();
      const hasErrors = errors.some(error => error.severity === 'error');

      setValidationState(prev => ({
        ...prev,
        errors,
        isValid: !hasErrors
      }));

      if (hasErrors) {
        throw new ValidationError('Please fix the errors in the form before submitting.');
      }

      // Submit the form
      await onSubmit(data);

      // Reset form state on successful submission
      setValidationState(prev => ({
        ...prev,
        isValid: true,
        errors: [],
        touched: new Set()
      }));

    } catch (error) {
      if (error instanceof ValidationError) {
        errorService.handleError(error);
      } else {
        errorService.handleError(error as Error, { formData: data });
      }
    } finally {
      setValidationState(prev => ({
        ...prev,
        isSubmitting: false
      }));
    }
  }, [data, validateAllFields, errorService]);

  // Reset form
  const resetForm = useCallback(() => {
    setData(initialData);
    setValidationState({
      isValid: false,
      isSubmitting: false,
      errors: [],
      touched: new Set(),
      hasBeenSubmitted: false
    });
  }, [initialData]);

  // Validate all fields when data changes (but only if form has been submitted)
  useEffect(() => {
    if (validationState.hasBeenSubmitted) {
      debouncedValidation();
    }
  }, [data, validationState.hasBeenSubmitted, debouncedValidation]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (validationTimeout) {
        clearTimeout(validationTimeout);
      }
    };
  }, [validationTimeout]);

  return {
    data,
    validationState,
    updateField,
    getFieldProps,
    getFieldError,
    handleSubmit,
    resetForm,
    validateField,
    validateAllFields
  };
};