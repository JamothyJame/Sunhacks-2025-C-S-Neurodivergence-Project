/**
 * Application Configuration
 * Central configuration for MedTracker application settings
 */

export interface ColorOption {
  name: string;
  value: string;
  category?: string;
}

export interface ThemeConfig {
  name: string;
  displayName: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

export interface NotificationConfig {
  defaultReminderMinutes: number;
  maxActiveNotifications: number;
  cleanupIntervalMinutes: number;
  defaultThrottleHours: number;
  defaultRefillReminderDays: number;
}

export interface DatabaseConfig {
  maxRetries: number;
  retryDelay: number;
  maxBufferSize: number;
}

export interface AppConfig {
  // Application metadata
  appName: string;
  version: string;
  
  // Medication colors
  medicationColors: ColorOption[];
  
  // Themes
  themes: ThemeConfig[];
  
  // Default user preferences
  defaultUserPreferences: {
    theme: 'light' | 'dark' | 'system';
    timeFormat: '12h' | '24h';
    dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
    timezone: string;
    notifications: {
      enabled: boolean;
      reminderMinutes: number;
      throttleHours: number;
      refillReminderDays: number;
    };
  };
  
  // Notification settings
  notifications: NotificationConfig;
  
  // Database settings
  database: DatabaseConfig;
  
  // Gamification settings
  gamification: {
    pointsPerDose: number;
    experiencePerLevel: number;
    streakBonusMultiplier: number;
  };
  
  // UI settings
  ui: {
    maxRecentMedications: number;
    defaultPageSize: number;
    animationDuration: number;
  };
}

/**
 * Default application configuration
 */
export const defaultConfig: AppConfig = {
  appName: 'MedTracker',
  version: '1.0.2',
  
  medicationColors: [
    { name: 'Sky Blue', value: '#0ea5e9', category: 'blue' },
    { name: 'Emerald', value: '#10b981', category: 'green' },
    { name: 'Violet', value: '#8b5cf6', category: 'purple' },
    { name: 'Rose', value: '#f43f5e', category: 'red' },
    { name: 'Amber', value: '#f59e0b', category: 'orange' },
    { name: 'Pink', value: '#ec4899', category: 'pink' },
    { name: 'Indigo', value: '#6366f1', category: 'purple' },
    { name: 'Teal', value: '#14b8a6', category: 'green' },
    { name: 'Slate', value: '#64748b', category: 'gray' },
    { name: 'Crimson', value: '#dc2626', category: 'red' },
    { name: 'Lime', value: '#65a30d', category: 'green' },
    { name: 'Fuchsia', value: '#d946ef', category: 'purple' }
  ],
  
  themes: [
    {
      name: 'light',
      displayName: 'Light Theme',
      colors: {
        primary: '#0ea5e9',
        secondary: '#64748b',
        accent: '#10b981'
      }
    },
    {
      name: 'dark',
      displayName: 'Dark Theme',
      colors: {
        primary: '#38bdf8',
        secondary: '#94a3b8',
        accent: '#34d399'
      }
    },
    {
      name: 'system',
      displayName: 'System Default',
      colors: {
        primary: '#0ea5e9',
        secondary: '#64748b',
        accent: '#10b981'
      }
    }
  ],
  
  defaultUserPreferences: {
    theme: 'system',
    timeFormat: '12h',
    dateFormat: 'MM/DD/YYYY',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    notifications: {
      enabled: true,
      reminderMinutes: 15,
      throttleHours: 24,
      refillReminderDays: 3
    }
  },
  
  notifications: {
    defaultReminderMinutes: 15,
    maxActiveNotifications: 100,
    cleanupIntervalMinutes: 5,
    defaultThrottleHours: 24,
    defaultRefillReminderDays: 3
  },
  
  database: {
    maxRetries: 2,
    retryDelay: 1000,
    maxBufferSize: 1000
  },
  
  gamification: {
    pointsPerDose: 10,
    experiencePerLevel: 100,
    streakBonusMultiplier: 1.5
  },
  
  ui: {
    maxRecentMedications: 5,
    defaultPageSize: 20,
    animationDuration: 300
  }
};

/**
 * Configuration service for managing app settings
 */
class ConfigService {
  private static instance: ConfigService;
  private config: AppConfig = { ...defaultConfig };
  private customColors: ColorOption[] = [];

  private constructor() {
    this.loadCustomColors();
  }

  static getInstance(): ConfigService {
    if (!ConfigService.instance) {
      ConfigService.instance = new ConfigService();
    }
    return ConfigService.instance;
  }

  /**
   * Get the current configuration
   */
  getConfig(): AppConfig {
    return { ...this.config };
  }

  /**
   * Update configuration
   */
  updateConfig(updates: Partial<AppConfig>): void {
    this.config = {
      ...this.config,
      ...updates
    };
  }

  /**
   * Get medication colors (including custom colors)
   */
  getMedicationColors(): ColorOption[] {
    return [...this.config.medicationColors, ...this.customColors];
  }

  /**
   * Add a custom color
   */
  addCustomColor(color: ColorOption): void {
    // Check if color already exists
    const existingColor = this.customColors.find(c => c.value === color.value);
    if (!existingColor) {
      this.customColors.push({
        ...color,
        category: color.category || 'custom'
      });
      this.saveCustomColors();
    }
  }

  /**
   * Remove a custom color
   */
  removeCustomColor(colorValue: string): void {
    this.customColors = this.customColors.filter(c => c.value !== colorValue);
    this.saveCustomColors();
  }

  /**
   * Get colors by category
   */
  getColorsByCategory(category: string): ColorOption[] {
    return this.getMedicationColors().filter(color => color.category === category);
  }

  /**
   * Get available color categories
   */
  getColorCategories(): string[] {
    const categories = new Set(this.getMedicationColors().map(color => color.category || 'other'));
    return Array.from(categories).sort();
  }

  /**
   * Get default color (first in the list)
   */
  getDefaultMedicationColor(): string {
    return this.config.medicationColors[0]?.value || '#0ea5e9';
  }

  /**
   * Validate if a color is in the available list
   */
  isValidMedicationColor(colorValue: string): boolean {
    return this.getMedicationColors().some(color => color.value === colorValue);
  }

  /**
   * Get color name by value
   */
  getColorName(colorValue: string): string {
    const color = this.getMedicationColors().find(c => c.value === colorValue);
    return color?.name || 'Custom Color';
  }

  /**
   * Reset to default colors
   */
  resetToDefaultColors(): void {
    this.customColors = [];
    this.saveCustomColors();
  }

  /**
   * Load custom colors from localStorage
   */
  private loadCustomColors(): void {
    try {
      const stored = localStorage.getItem('medtracker_custom_colors');
      if (stored) {
        this.customColors = JSON.parse(stored);
      }
    } catch (error) {
      console.warn('Failed to load custom colors:', error);
      this.customColors = [];
    }
  }

  /**
   * Save custom colors to localStorage
   */
  private saveCustomColors(): void {
    try {
      localStorage.setItem('medtracker_custom_colors', JSON.stringify(this.customColors));
    } catch (error) {
      console.warn('Failed to save custom colors:', error);
    }
  }

  /**
   * Get theme by name
   */
  getTheme(themeName: string): ThemeConfig | null {
    return this.config.themes.find(theme => theme.name === themeName) || null;
  }

  /**
   * Get all available themes
   */
  getThemes(): ThemeConfig[] {
    return [...this.config.themes];
  }

  /**
   * Export configuration as JSON
   */
  exportConfig(): string {
    return JSON.stringify({
      config: this.config,
      customColors: this.customColors
    }, null, 2);
  }

  /**
   * Import configuration from JSON
   */
  importConfig(jsonConfig: string): boolean {
    try {
      const imported = JSON.parse(jsonConfig);
      if (imported.config) {
        this.config = { ...defaultConfig, ...imported.config };
      }
      if (imported.customColors) {
        this.customColors = imported.customColors;
        this.saveCustomColors();
      }
      return true;
    } catch (error) {
      console.error('Failed to import configuration:', error);
      return false;
    }
  }
}

// Export singleton instance
export const configService = ConfigService.getInstance();

// Export commonly used functions
export const getMedicationColors = () => configService.getMedicationColors();
export const getDefaultMedicationColor = () => configService.getDefaultMedicationColor();
export const addCustomMedicationColor = (color: ColorOption) => configService.addCustomColor(color);
export const getColorName = (value: string) => configService.getColorName(value);